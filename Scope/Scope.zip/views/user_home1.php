<?php 
$focoins = $this->session->userdata('forcoins');
?>
<style>
body {
background-image: url(<?php echo base_url('assets/images/blured.jpg'); ?>);
}
</style>
<div class="row">
	<div class="col-xs-6 col-xs-offset-3">
		<img src="<?php echo base_url('assets/images/welcome.png'); ?>" style="width:100%; margin-top:20px;"/>
	</div>
</div>
<div class="row" style="margin-top:0px;">
	<div class="col-xs-4" style="text-align:right;">
		<a href="<?php echo base_url('/home/content/1'); ?>"><img src="<?php echo base_url('assets/images/c1.png'); ?>" style="width:65%; margin-top:50px;"/></a>
	</div>
	<div class="col-xs-4" style="text-align:center;">
		<a href="<?php echo base_url('/home/content/2'); ?>"><img src="<?php echo base_url('assets/images/c2.png'); ?>" style="width:65%; margin-top:50px;"/></a>
	</div>
	<div class="col-xs-4" style="text-align:left;">
		<a href="<?php echo base_url('/home/content/3'); ?>"><img src="<?php echo base_url('assets/images/c3.png'); ?>" style="width:65%; margin-top:50px;"/></a>
	</div>
	<!--
	<div class="col-xs-3" style="text-align:left;">
		<a href="<?php echo base_url('/pdcampaign'); ?>">
			<img src="<?php echo base_url('assets/images/pdcampus.png');?>"  style="width:58%; margin-top:50px;"/>
		</a>
	</div>
	-->
</div>
           <?php if($this->session->userdata('username')){ ?>
		<style type="text/css">
			.navigation{
				height:120px;
			}
		</style>
				<style>
		.v-al-container{
			width: 1170px;
            margin-right: auto;
            margin-left: auto;
		}
		.black_overlay{
			display: block;
			position: absolute;
			top: 0%;
			left: 0%;
			width: 100%;
			height: 100%;
			background-color: black;
			z-index:1001;
			-moz-opacity: 0.8;
			opacity:.80;
			filter: alpha(opacity=80);
		}
		.white_content {
			display: block;
position: absolute;
top: 25%;
left: 33%;
width: 35%;
height: 40%;
padding: 16px;
border: 5px solid rgba(142, 142, 142, 0.59);
background-color: white;
z-index: 1002;
overflow: auto;

		}
		.aclos {
		background: rgba(195, 195, 195, 0.8);
z-index: 1001;
color: #000;
position: absolute;
top: 43px;
left: 50%;
font-size: 15px;
line-height: 26px;
text-align: center;
width: 50px;
height: 23px;
overflow: hidden;
margin-left: -25px;
filter: alpha(opacity=0);
-webkit-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
-moz-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
-webkit-transition: opacity 0.3s linear 1.2s;
-moz-transition: opacity 0.3s linear 1.2s;
-o-transition: opacity 0.3s linear 1.2s;
-ms-transition: opacity 0.3s linear 1.2s;
transition: opacity 0.3s linear 1.2s;
top: 220px;
		}
	</style>
	
		<?php }  ?>
		<?php if($this->session->userdata('username') && $focoins ==1){ ?>
		<div style="width:100%;height:100%">
	    <div id="light" class="white_content"> <a class="aclos" href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">Close</a>
		<p style=" margin: 0px; font-size: 25px;margin-left: 40px; ">
		<br/>Congratulation , you have <br/><span style=" color: #F4B213; font-size: 40px; font-weight: bold; margin-left: 155px;">5</span><br/>  coins for your registration.
		</p>
		</div>
		<div id="fade" class="black_overlay"></div>
		</div>
		<?php } ?>