			<!-- Main content -->
              <div class="col-md-8">
			 <!-- Contact -->
                <div class="contact">
                  <h1>Contact us</h1>
                  <div class="container-fluid">
                <div class="row-fluid" >
                   
                     <div class="" id="box">                      
                                <form class="form-horizontal" action="<?php echo base_url('home/addcontact'); ?>" method="POST" id="contact_form">
                                    <fieldset>
                                        <!-- Form Name -->
                                        <!-- Text input-->

                                        <div class="form-group">
                                            <div class="col-md-6">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                                    <input name="name" placeholder="Name" class="form-control" type="text">
                                                </div>
                                            </div>
                                        </div>


                                  
                                        <!-- Text input-->
                                        <div class="form-group">
                                            <div class="col-md-6">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                                    <input name="email" placeholder="E-Mail Address" class="form-control" type="text">
                                                </div>
                                            </div>
                                        </div>


                                        <!-- Text input-->

                                        <div class="form-group">
                                            <div class="col-md-6">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                                                    <input name="tel" placeholder="Phone" class="form-control" type="text">
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Text input-->

                                        <div class="form-group">
                                            <div class="col-md-6 inputGroupContainer">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                                    <textarea class="form-control" name="msg" placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">

                                            <div class="col-md-12">
                                                <input type="hidden" name="typeid" id="typeid" value="2" />
                                                <button type="submit" class="btn btn-warning pull-left">Send <span class="glyphicon glyphicon-send"></span></button>
                                            </div>
                                        </div>

                                    </fieldset>
                                </form>
                    </div> 
</div>
                  
                </div>
				<!-- End contact -->
              </div>
                  </div>
			  <!-- End Main content -->
			  
			  <!-- Sidebar left  -->
              <div class="col-md-4">
			  <!-- Box Siderbar -->
           <div class="contact">
                  <h1>Contact Info</h1>
               
                      <div class="add-contact">
                      <div class="row">
                        <div class="col-md-12">
                             <h6> Address: </h6>
                        
                          <div class="infotext">
                            EGYPT<br />
                            CAIRO<br />
                            133, Road 70 parallel to Road 90 North<br />
                            5th settlement<br />
                            New Cairo, 11835<br />
                          
                    </div>    
                            
                        </div>
                       
                      </div>
                    </div>
               
               
                  </div>
				<!-- End Box Siderbar -->
              </div>
			  <!-- End Sidebar left  -->