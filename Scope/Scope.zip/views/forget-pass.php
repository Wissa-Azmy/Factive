<?php
$flag = 0;
if (isset($new_pass)) {
	// echo $new_pass;
	if ($new_pass) {
	    if ($new_pass=='notactive') {
	        $flag = 3;
	    }else{
	        $flag = 1;
	    }
		
	} else {
		$flag = 2;
	}
}
?>

 <div class="col-md-12">
			 <!-- Contact -->			 	
                <div class="contact">
                    <br>
                  <h2 class="text-center"> Forget Password</h2>
                  <div class="contact-bor">
                    <div class="text-center">                      
                	<br>
                      <form action="<?php echo base_url('/users/forgetPassword'); ?>" method="post" role="form" id="login-form">
                     <?php if ($flag == 1) { ?>
					<div class="alert alert-success" style="width: 260px;text-align: center;margin: auto;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						<?php echo $this->lang->line('APasswordHasBeenSentTo'); ?> <b><?php echo $email; ?></b>
					</div><br>
					<?php } else if($flag == 2) { ?>
					<div class="alert alert-danger" style="width: 260px;text-align: center;margin: auto;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						Email <b><?php echo $email; ?></b> <?php echo $this->lang->line('hasnotbeenregisteredindatabase'); ?>
					</div><br>
					<?php } else if($flag == 3) { ?>
					<div class="alert alert-danger" style="width: 260px;text-align: center;margin: auto;">
						<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
						Email <b><?php echo $email; ?></b> <?php echo $this->lang->line('isnotactivated'); ?>
					</div><br>
					<?php } ?>
				
                      <input class="login-inner" type="email" name="email" placeholder="<?php echo $this->lang->line('EMail'); ?>..." title="<?php echo $this->lang->line('EMail'); ?>" required ><br>
                        <?php echo $this->lang->line('Typeyouremail'); ?>      
                  <br>
                
                  <button class="button-send-inner" type="submit"><?php echo $this->lang->line('Sendnewpassword'); ?></button><br>
                    <br>
              
                  </form>
                 
                    </div>
                   
                   
                  </div>
                  
                </div>
				<!-- End contact -->
              </div>
			  <!-- End Main content -->
			  
			<!-- End Sidebar left  -->
			