              <div class="col-md-12">
			 <!-- Contact -->
                <div class="contact">
                    <br>
                  <h2 class="text-center"> Change Password</h2>
                  <div class="contact-bor">
                    <div class="text-center">                      
                 
                      <form action="<?php echo base_url('/users/changePassword'); ?>" method="post" role="form" onsubmit="return validateForm()" id="registerrr" enctype="multipart/form-data"  >
                     
                     <input name="oldFromPassword" class="login-inner" type="password" placeholder="<?php echo $this->lang->line('Oldpassowrd'); ?>" 	title="<?php echo $this->lang->line('Oldpassowrd'); ?>" required />
                          <br>      	
                      <input name="newPassword1" class="login-inner" type="password" id="password" placeholder="<?php echo $this->lang->line('Newpassword'); ?>"
                            	title="<?php echo $this->lang->line('Newpassword'); ?>" required />
                      <br>
                      <input name="newPassword2" class="login-inner" type="password"  id="confPassword" placeholder="Retype Password" data-placement="top" data-content="<?php echo $this->lang -> line('ReTypePassword'); ?>" data-trigger="manual" required />
                       
                  <br>
                
                  <button class="button-send-inner" type="submit">Save</button><br>
                    
                  </form>
                 
                    </div>
                   
                   
                  </div>
                  
                </div>
				<!-- End contact -->
              </div>