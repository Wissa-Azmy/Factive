<link href='<?php echo base_url();?>assets/fullcalendar/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/fullcalendar/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='<?php echo base_url();?>assets/fullcalendar/lib/moment.min.js'></script>
<script src='<?php echo base_url();?>assets/fullcalendar/lib/jquery.min.js'></script>
<script src='<?php echo base_url();?>assets/fullcalendar/fullcalendar.min.js'></script>

<script>

	$(document).ready(function() {

		$('#calendar').fullCalendar({
			/*defaultDate: '2016-09-12',*/
			<?php  if ($defaultdate){  
			 echo "defaultDate: '".$defaultdate."',";
             } ?>
			editable: false,
			eventLimit: true, // allow "more" link when too many events
			events: <?php echo $events;?>
		});
		
	});

</script>
<style>

	#calendar {
		max-width: 900px;
		margin: 0 auto;
	}

</style>
<br>
<div id='calendar'></div>
<br>