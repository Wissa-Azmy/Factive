		<!-- Main content -->
              <div class="col-md-8">
			 <!-- Contact -->
                <div class="contact">
                  <h1>Help Desk</h1>
                 <div class="panel-group" id="accordion">
                  <?php foreach($helpdesks as $x=> $helpdesk){ ?>
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $helpdesk->id;?>">
                        <?php echo $helpdesk->question;?></a>
                      </h4>
                    </div>
                    <div id="collapse<?php echo $helpdesk->id;?>" class="panel-collapse collapse">
                      <div class="panel-body"><?php echo $helpdesk->answer;?></div>
                    </div>
                  </div>
                 <?php }?>
  
</div>
                  
                </div>
				<!-- End contact -->
              </div>
			  <!-- End Main content -->
			  
			  <!-- Sidebar left  -->
              <div class="col-md-4 pull-right ">
			  <!-- Box Siderbar -->
                <div class="box-siderbar-container pull-right">
				<!-- sidebar-box our-box -->
                    
                     <div class="contact">
                         <h1>Inquiry</h1></div>
                                 <form class="form-horizontal" action="<?php echo base_url('home/addcontact'); ?>" method="POST" id="contact_form">
                                    <fieldset>
                                        <!-- Form Name -->
                                        <!-- Text input-->
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                                    <input name="name" placeholder="Name" class="form-control" type="text" required>
                                                </div>
                                            </div>
                                        </div>
                                  
                                        <!-- Text input-->
                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                                    <input name="email" placeholder="E-Mail Address" class="form-control" type="text" required>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Text input-->

                                        <div class="form-group">
                                            <div class="col-md-12">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                                                    <input name="tel" placeholder="Phone" class="form-control" type="text" required>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Text input-->
                                        <div class="form-group">
                                            <div class="col-md-12 inputGroupContainer">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                                    <textarea class="form-control" name="msg" placeholder="Message" required></textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-md-12">
                                            <input type="hidden" name="typeid" id="typeid" value="1" />
                                                <button type="submit" class="btn btn-warning pull-left">Send <span class="glyphicon glyphicon-send"></span></button>
                                            </div>
                                        </div>

                                    </fieldset>
                                </form>
				 <!-- End sidebar-box our-box -->
		
                </div>
				<!-- End Box Siderbar -->
              </div>
			  <!-- End Sidebar left  -->
			  