    <!-- BEGIN HEADER -->
    <header>
        
         <!-- Bannber -->
      <div class="row-fluid">
        <div class="span12">
          <section class="pic-cat">
            <img width="100%" height="200" alt="" src="<?php echo base_url();?>assets/img/pic-cat.jpg">
          </section>
        </div>
      </div>
	  <!-- End Bannber -->
      <div class="container">
        <div class="top-header">
		<!-- Logo -->
          <div class="realestate-logo pull-left"><a href="index.html" title=""> <img alt="" src="<?php echo base_url();?>assets/img/logo.png"></a></div>
		<!-- End Logo -->
		
		<!-- Menu --> 
          <div class="menu-navbar">
            <div class="navbar">
              <ul class="nav pull-left" id="navmenu">
                <li><a href="<?php echo base_url();?>" title="">Home</a></li>
                <li><a href="#" title="">The district</a></li>
                  
                  
                  <li><a href="#" title="">The Beacon</a></li> 
                  
                   <li><a href="#" title="">The Square</a></li>
                  
                   <li><a href="#" title="">Astragram</a></li>
                  
                  
                   <li><a href="<?php echo base_url();?>home/news" title="">News</a></li>
                  
                   <li><a href="<?php echo base_url();?>home/calendar" title="">Calendar</a></li>
                  
                  
                <li><a href="<?php echo base_url();?>home/helpdesks" title="">Help Desk</a></li>
                                  
                <li><a href="<?php echo base_url();?>home/contacts" title="">Contact us</a></li>
                </ul>
                
                
                
               
            </div>
          </div>
		<!-- End Menu -->   
		
        </div>
      </div>
	 
    </header>
	<!-- END HEADER -->