    <!-- BEGIN HEADER -->
    <header>
        
         <!-- Bannber -->
      <div class="row-fluid">
        <div class="span12">
          <section class="pic-cat">
            <img width="100%" height="200" alt="" src="<?php echo base_url();?>assets/img/pic-cat.jpg">
          </section>
        </div>
      </div>
	  <!-- End Bannber -->
      <div class="container">
        <div class="top-header">
		<!-- Logo -->
          <div class="realestate-logo pull-left"><a href="index.html" title=""> <img alt="" src="<?php echo base_url();?>assets/img/logo.png"></a></div>
		<!-- End Logo -->
		
		<!-- Menu --> 
          <div class="menu-navbar">
            <div class="navbar">
              <ul class="nav pull-left" id="navmenu">
                <li class="active"><a href="<?php echo base_url();?>" title="">Home</a></li>
                
                <li><a href="<?php echo base_url();?>home/helpdesks" title="">Help Desk</a></li>
                 
               
                 
                <li><a href="<?php echo base_url();?>home/contacts" title="">Contact us</a></li>
                </ul>                
                <?php if($page!='login'){ ?>
                 <form action="<?php echo base_url('/users/login'); ?>" method="post" role="form" id="login-form">
                  <ul class="nav pull-right">
                      <li class="login-arrangment">
                      <input type="text" class="keywordfind" type="email" name="email" placeholder="<?php echo $this->lang->line('EMail'); ?>..." title="<?php echo $this->lang->line('EMail'); ?>" required><br>
                      <input type="checkbox" name="remember" value="1" id="remember"/>Remember me
                        
                      </li>
                  
                   <li class="login-arrangment">
                      <input type="password" name="password" placeholder="<?php echo $this->lang->line('Password'); ?>" title="<?php echo $this->lang->line('Password'); ?>..." required class="keywordfind"><br>
                      <span><a href="<?php echo base_url('/users/forget'); ?>" class="forget" >Forget Password?</a></span>
                   </li>
                  
                  <li class="login-arrangment">                  
                        <button class="button-send" type="submit">Signin</button><br>
                      <span><a href="<?php echo base_url('users/register'); ?>" class="forget" style="margin-left: 5px;">First time here ? Signup Now</a></span>                  
                  </li>                  
              </ul> 
              </form>
              <?php }?>
            </div>
          </div>
		<!-- End Menu -->   
		
        </div>
      </div>
	 
    </header>
	<!-- END HEADER -->