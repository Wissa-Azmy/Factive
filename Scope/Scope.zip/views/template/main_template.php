<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>NE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Your styles -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="<?php echo base_url();?>assets/css/bootstrap-responsive.css" rel="stylesheet" media="screen">
    <link href="<?php echo base_url();?>assets/css/flexslider/flexslider.css" rel="stylesheet" media="screen">
    <link href="<?php echo base_url();?>assets/css/tabber/tabber.css" rel="stylesheet" media="screen">
    <link href="<?php echo base_url();?>assets/css/styles.css" rel="stylesheet" media="screen">
    <link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,700,100,200,300' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="<?php echo base_url();?>assets/vendors/jquery/jquery-1.11.1.min.js"></script>
      <link rel="icon" type="image/png" href="<?php echo base_url();?>assets/img/favicon.png">
    <!-- HTML5 shim, for Ie6-8 support of HTML5 elements -->
    <!--[if lt Ie 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
  </head>
  <body>
    <!-- BEGIN HEADER -->
    <?php if($this -> session -> userdata('userid')){ 
            $this->load->view('template/header_after_login.php');
        }else{
            $this->load->view('template/header_before_login.php');
        }
    ?>
	<!-- END HEADER -->

    <!--BEGIN CONTENT -->
    <div class="main-content">
    <?php if($this -> session -> userdata('userid')){ 
            $this->load->view('template/menu-after.php');
        }
    ?>
      <div class="properties">
        <div class="container">
          <div class="gird_sidebar">
          <?php if( isset($showMessage) && ($showMessage==true) ) { ?>
			<br><div id="messagesGrid" class="row">
				<div class="alert <?php if( $type=='Error'){ echo 'alert-danger'; }else{ echo 'alert-success'; } ?>" style="text-align: center;">
					<b><?php if( $type=='Error'){ echo $this->lang->line('ErrorOccurred'); 'Error Occurred ...'; }else{ echo 'Action Done Successfully ...'; } ?></b>
					<br />
					<?php echo $messageToBeShow; ?>
				</div>
			</div>
			<?php } ?>
            <div class="row">
			<!-- Main content -->
             <?php 
                // Loading Page
                
                $this->load->view($page);
                ?>
            
            </div>
          </div>
        </div>
      </div>
    </div>
	<!-- END CONTENT -->
	
	<!-- BEGIN FOOTER -->
    <footer>
      <div class="footer-container">
        <div class="container">
		<!-- Footer box -->
  
		<!-- End footer box -->
          <div class="footer-bottom">
            <div class="row">
              <div class="span12">
                <p>Copyright © 2016 NE City. </p>
              </div>
             
          </div>
        </div>
      </div>
    </footer>
    <div id='bttop'>BACK TO TOP</div>
	<!-- End footer -->
    <!-- Always latest version of jQuery-->
    
    
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <!-- Some scripts that are used in almost every page -->
    <script src="<?php echo base_url();?>assets/js/tinynav/tinynav.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/tabber/tabber.js"></script>
    <!-- Load template main javascript file -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/main.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
  </body>
</html>

