            <div class="menu-navbar menu-after">
            <div class="navbar container">
              <ul class="nav pull-right">
                
                    <li class="dropdown">
                  <a class="active dropdown-toggle" data-target="#" data-toggle="dropdown" href="#">
                     <!-- <span class="small-num">11</span>  --> <i class="glyphicon glyphicon-bell"></i> </a>
                 <!-- 
                  <ul class="dropdown-menu" style="display: none;">
                    <li><a href="#">notification 1</a></li>
                      <li><a href="#">notification 2</a></li>
                  </ul>
                   -->
                  <div class="clearfix"></div>
                </li>
                  
                   <li class="dropdown">
                  <a class="active" data-target="#" data-toggle="dropdown" href="#">
                      <i class="glyphicon glyphicon-comment"></i> </a>
                  
                  <div class="clearfix"></div>
                </li>
                  
                  
                   <li class="dropdown">
                        <a class="active dropdown-toggle" data-target="#" data-toggle="dropdown" href="#">
                        <i class="glyphicon glyphicon-search"></i></a>
                  
                  
                  <ul class="dropdown-menu" style="display: none;">
                    <li class="search-width" >
                      
                       <div class="">
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Search for...">
                              <span class="input-group-btn">
                                <button class="btn btn-default" type="button">Go!</button>
                              </span>
                            </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                      
                      </li>
                  </ul>
                  <div class="clearfix"></div>
                  
                  </li>
                  
                   <li class="dropdown">
                  <a class="active dropdown-toggle" data-target="#" data-toggle="dropdown" href="#">Welcome user </a>
                  <ul class="dropdown-menu" style="display: none;">
                    <li><a href="<?php echo base_url('users/updateProfile'); ?>"><?php echo $this->lang->line('ViewEditProfile'); ?></a></li>
                    <li><a href="<?php echo base_url('users/changePassword'); ?>"><?php echo $this->lang->line('ChangePassword'); ?></a></li>
                  </ul>
                  <div class="clearfix"></div>
                </li>
                  
                 
                <li><a href="<?php echo base_url('users/logout'); ?>" title=""><?php echo $this->lang->line('CheckOut'); ?></a></li>
                </ul>
                
                
                
               
            </div>
          </div>