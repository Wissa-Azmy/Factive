
              <div class="col-md-12">
			 <!-- Contact -->
                <div class="contact">
                 
                  <div class="contact-bor">
                   
                   
                    <div class="add-contact">
                      <div class="row">
                        <div class="col-md-6">
                            <br>
                             <h2> <?php echo $news->title;?></h2>
                          <h6><?php if ($news->newdate != '0000-00-00 00:00:00'){echo date('m/d/Y',strtotime($news->newdate));}?></h6>
                          <div class="infotext">
                          <?php echo $news->desc;?>
                    </div>
                            
                            
                        </div>
                        <div class="col-md-6 pull-right">
                          <br/>
                               <section class="slider-detail">
                               <?php $images= json_decode($news->images);
                        if(!empty($images) OR $news->img_url){ ?> 
                    <div id="pic-detail" class="flexslider">
                      <ul class="slides">
                        <?php if ($news->img_url){?>
                        <li>
                          <img alt=""  width="620" height="388" src="<?php echo base_url().$news->img_url;?>" />
                        </li>
                        <?php }?>
                        <?php $images= json_decode($news->images);if(!empty($images)){  
                        	
                        	foreach($images as $x => $image){
                        		
                        		//echo "array".$image['image'];
                        	if ((is_array($image)) OR (is_object($image))) {
                        		//echo "yes";
                        		$imagesource=$image->image;
                        		$comment=$image->comment;
                        	}else{
                        		$imagesource=$image;
                        		$comment='';
                        	}
                        	?>                        	
                            <li>
                             <img alt=""  width="620" height="388" src="<?php echo base_url().$imagesource;?>" />
                            </li>                       
                        <?php }} ?>                       
                        
                      </ul>
                    </div>
                    <?php }?>
                     <?php $images= json_decode($news->images);
                        if(!empty($images)){ ?> 
                    <div id="pic-control" class="flexslider">
                      <ul class="slides">       
                          <?php if ($news->img_url){?>                
                                <li>
                                  <img alt="" src="<?php echo base_url().$news->img_url;?>" />
                                </li>
                            <?php }?>
                        	<?php
                        	foreach($images as $x => $image){
                        		
                        		//echo "array".$image['image'];
                        	if ((is_array($image)) OR (is_object($image))) {
                        		//echo "yes";
                        		$imagesource=$image->image;
                        		$comment=$image->comment;
                        	}else{
                        		$imagesource=$image;
                        		$comment='';
                        	}
                        	?>   
                            <li>
                              <img alt="" src="<?php echo base_url().$imagesource;?>" />
                            </li>                            
                       
                        <?php } ?>
                        
                                              
                      </ul>
                    </div>
                    <?php }?>
                  </section>
                        </div>
                      </div>
                    </div>
                  </div>
                    
                    
               
                  
                </div>
				<!-- End contact -->
              </div>
              
              
      <script src="<?php echo base_url();?>assets/js/flexflider/jquery.flexslider-min.js"></script>
      <script src="<?php echo base_url();?>assets/js/colorbox/jquery.colorbox.js"></script>
      <script type="text/javascript">
      /* <![CDATA[ */
      jQuery(function($){
          $('#pic-control').flexslider({
              animation: "slide",
              controlNav: false,

              animationLoop: false,
              slideshow: false,
              itemWidth: 50,
              itemMargin: 5,
              maxItems: 4,
              asNavFor: '#pic-detail'
          });

          $('#pic-detail').flexslider({
              controlNav: false,
              directionNav: true,
              animationLoop: false,
              slideshow: true,
              sync: "#pic-control",
              start: function(slider){
                  $('body').removeClass('loading');
              }
          });

          $(".detailbox").colorbox({rel:'detailbox'});
      });
      /* ]]> */
      </script>