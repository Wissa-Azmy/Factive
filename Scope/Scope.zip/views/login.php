               
                    <?php
                if (isset($not_exist)) {
                ?>
                
                 <div class="col-md-12">
                 <br/>
                	<div class="col-xs-6 col-xs-offset-3 alert alert-danger" style="text-align:center;">
                		<button type="button" class="close" data-dismiss="alert">
                			<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                		</button>
                		<b><?php echo $this->lang->line('Invalidemailorpassword'); ?></b>
                		<br/>
                		<?php echo $this->lang->line('ifyouforgetpasswordyoucan'); ?> <a href="<?php echo base_url('/users/forget'); ?>" class="alert-link"><?php echo $this->lang->line('resetyourpassword'); ?></a>.
                	</div>
                </div>
                <?php } ?>
              <div class="col-md-12">
			 <!-- Contact -->
                <div class="contact">
                    <br>
                  <h2 class="text-center"> login</h2>
                  <div class="contact-bor">
                    <div class="text-center">                      
                 
                      <form action="<?php echo base_url('/users/login'); ?>" method="post" role="form" id="login-form">
                     
                      <input class="login-inner" type="email" name="email" placeholder="<?php echo $this->lang->line('EMail'); ?>..." title="<?php echo $this->lang->line('EMail'); ?>" required ><br>
                         
                      
                      <input type="password" name="password" placeholder="<?php echo $this->lang->line('Password'); ?>..." title="<?php echo $this->lang->line('Password'); ?>" required class="login-inner"><br>
                          
                          
                         <div class="checkbox">
                      <label>
                        <input type="checkbox" name="remember" value="1" id="remember" />
                        Remember me
                      </label>
                    </div> 
               
                  <br>
                
                  <button class="button-send-inner" type="submit">Signin</button><br>
                    
                  <br>
                      <a href="<?php echo base_url('/users/forget'); ?>" class="forget-inner" >Forget Password?</a>
                  </form>
                 
                    </div>
                   
                   
                  </div>
                  
                </div>
				<!-- End contact -->
              </div>
			  <!-- End Main content -->
			  
			<!-- End Sidebar left  -->