<style>
<!--
.pic {
	height: 130px;
	/*width:calc(100% - 20px);*/
	width: 85%;
	width: 130px;
	border: 5px solid #fff;
	box-shadow: 0px 0px 5px #999;
	position: relative;
	overflow: hidden;
	    margin: auto;
}

.photo {
	position: absolute;
	top: 0%;
	left: 0%;
	width: 100%;
	height: 100%;
}

#upload {
	position: absolute;
	top: 0px;
	left: 0px;
	width: 100%;
	height: 100%;
	opacity: 0;
	background: #fff;
	cursor: pointer;
}

.link-upload {
	z-index: 10;
	/*height:20px;*/
	cursor: pointer;
	padding: 5px;
	color: #fff;
	text-align: center;
	font-size: 11px;
	background: rgba(0,0,0,0.5);
	position: absolute;
	bottom: 0px;
	width: 100%;
}

.link-upload:hover {
	font-weight:bold;
}

-->
</style>
	<div class="alert alert-success" style="display:none;">
		<button type="button" class="close" data-dismiss="alert">
			<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
		</button>s
		<?php echo $this->lang -> line('YouHaveSuccessfullyRegistered'); ?>
	</div>

	<?php if(validation_errors()) {
	?>
	<br>n
	<div class="alert alert-danger" style="display:;">
		<button type="button" class="close" data-dismiss="alert">
			<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
		</button>
		<b><?php echo $this->lang -> line('ErrorOccurred'); ?></b>
		<?php
        if (validation_errors())
            echo "<ul>";
        echo validation_errors('<li>', '</li>');
        echo "</ul>";
		?>
	</div>
	<?php  } ?>
                  <div class="contact">
                <h1 class="text-center">Rigestration</h1>
                      
                </div>
                   
                
              <div class="col-md-8">
			 <!-- Contact -->
                <div class="contact">
                  
                  <div class="container-fluid">
                <div class="row-fluid" >
                   
                      
                     <div class="" id="box">                
                                                  
                    <form action="<?php echo base_url('/users/updateProfile'); ?>" method="post" role="form" id="register-form" class="form-horizontal" enctype="multipart/form-data">
                                <fieldset>
                                        <!-- Form Name -->
                                        <!-- Text input-->
                        <div class="form-group">
                             <div class="col-md-12">
                              <div class="col-md-6">
                                                <p class="text-right rig-style"></p>
                                                
                                            </div>
                               <div class="input-group col-md-6">
                                    <div class="pic">
            							<div class="link-upload">
            								<?php echo $this->lang -> line('UploadPicture'); ?>
            								<input type="file" name="userfile" id="upload" />
            								<!--input type="file" name="userfile" id="upload"-->
            							</div>
            							<img src="<?php echo base_url('uploaded/profile/' . $avatar); ?>" id="imgpreview" alt="" class="photo" style="cursor: pointer;"
            								onclick="document.getElementById('upload').click();"/>
            						</div>
                                 </div>
                             </div>
                        </div>
                                        <div class="form-group">
                                           
                                            <div class="col-md-12">
                                               <div class="col-md-6">
                                                <p class="text-right rig-style">first name</p>
                                                
                                            </div>
                                                
                                                <div class="input-group col-md-6">    
                                                    <input class="form-control rig-inp"  type="text" placeholder="<?php echo $this->lang -> line('FirstName'); ?>" name="fname" title="<?php echo $this->lang -> line('FirstName'); ?>" required value="<?php if (!empty($fname)) {echo $fname;} ?>" />                                                
                                                </div>
                                            </div>
                                        </div>


                                  
                                        <!-- Text input-->
                                          <div class="form-group">
                                           
                                            <div class="col-md-12">
                                                
                                                
                                                 <div class="col-md-6">
                                            <p class="text-right rig-style">last name</p>
                                            
                                            
                                            </div>
                                                
                                                <div class="input-group col-md-6">
                                                    <input class="form-control rig-inp" type="text" placeholder="<?php echo $this->lang -> line('LastName'); ?>" name="lname" title="<?php echo $this->lang -> line('LastName'); ?>" required value="<?php if (!empty($lname)) {echo $lname;} ?>" />
                                                  </div>
                                            </div>
                                        </div>
                                        <!-- Text input-->

                                         <div class="form-group">
                                            <div class="col-md-12">
                                                 <div class="col-md-6">
                                            <p class="text-right rig-style">Country</p>
                                            </div>
                                            <div class="input-group col-md-6">
                                                <input name="country" class="form-control" type="text" placeholder="<?php echo $this->lang->line('Country'); ?>" readonly="readonly"	title="<?php echo $this->lang->line('Country'); ?>"	value="<?php echo $country; ?>" />  							
                                                </div>
                                            </div>
                                        </div>


                                        <!-- Text input-->

                                                <div class="form-group">
                                           
                                            <div class="col-md-12">
                                                
                                                
                                                 <div class="col-md-6">
                                            <p class="text-right rig-style">Gender</p>
                                            
                                            
                                            </div>
                                                
                                                <div class="input-group col-md-6">
                                                    <div class="col-md-4">
                                                    <div class="checkbox">
                                                      <label>
                                                        <input type="radio" value="male" name="gender" <?php
                										 if (empty($gender) || $gender == 'male') {echo 'checked'; } ?> title="<?php echo $this->lang -> line('Male'); ?>" />
                										<?php echo $this->lang -> line('Male'); ?> </label>
                                                      </label>
                                                    </div> 
                                                    </div>
                                                   <div class="input-group col-md-3">                                                    
                                                        <div class="checkbox">
                                                          <label>
                                                            <input  type="radio" value="female" name="gender" <?php
                        										if (!empty($gender) AND ($gender == 'female')) {echo 'checked';} ?> title="<?php echo $this->lang -> line('Female'); ?>" />
                        										<?php echo $this->lang -> line('Female'); ?> </label>
                                                          </label>
                                                        </div> 
                                                    </div> 
                                                
                                                </div>
                                                
                                            </div>
                                        </div>
                                                                                
                                         <div class="form-group">
                                              <div class="col-md-12">
                                                  <div class="col-md-6">
                                            <p class="text-right rig-style">Birthday</p>
                                                                                        
                                            </div>
                                                
                                                <div class="col-md-6">
                                                <div class="col-md-4" style="padding-right: 10px;padding-left: 10px;">
                                                   		<select class="form-control rig-inp"  id="month-menu" name="month" title="<?php echo $this->lang -> line('Month'); ?>" required>
                    									<?php if(!isset($month) OR ($month == '')) { ?>
                    										<option value="" disabled selected><?php echo $this->lang -> line('Month'); ?></option>
                    									<?php } else { 
                    									    $months=array('1'=>'January', '2'=>'February', '3'=>'March', '4'=>'April', '5'=>'May', '6'=>'June', '7'=>'July', '8'=>'August', '9'=>'September', '10'=>'October', '11'=>'November', '12'=>'December');
                    									   
                    									    ?>
                    										<option value="<?php echo $month; ?>"><?php echo $months[$month]; ?></option>
                    									<?php } ?>
                    									
                    									</select>
                                                </div>
                                                
                                                
                                                <div class="col-md-4" style="padding-right: 10px;padding-left: 10px;">
                                                    <select class="form-control rig-inp" id="day-menu"  name="day" title="<?php echo $this->lang -> line('Day'); ?>" required>
                										<?php if(!isset($day) OR ($day == '')) { ?>
                											<option value="" disabled selected><?php echo $this->lang -> line('Day'); ?></option>
                										<?php } else { ?>
                											<option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                										<?php } ?>
                									</select>                                                    
                                                </div>
                                                    
                                                    
                                                    <div class="col-md-4" style="padding-right: 10px;padding-left: 10px;">
                                                    <select class="form-control rig-inp" id="year-menu" style="width: 94%;" name="year" title="<?php echo $this->lang -> line('Year'); ?>" required>
                										<?php if(!isset($year) OR ($year == '')) { ?>
                											<option value="" disabled selected><?php echo $this->lang -> line('Year'); ?></option>
                										<?php } else { ?>
                											<option value="<?php echo $year; ?>"><?php echo $year;?></option>
                										<?php } ?>
                									</select>                                                    
                                                </div>
                                                </div>
                                                  </div>
                                             
                                        </div>

                                        
                                         <div class="form-group">                                           
                                            <div class="col-md-12">                                               
                                                 <div class="col-md-6">                                           
                                            </div>
                                                
                                                <div class="input-group col-md-6">                                                    
                                                   <button type="submit" class="btn btn-warning pull-left"><?php echo $this->lang -> line('Save'); ?> </button>
                                                   <input  type="hidden" value="<?php echo $avatar; ?>" name="avatar" />
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </fieldset>
                                </form>
                    </div> 
</div>
                  
                </div>
				<!-- End contact -->
              </div>
                  </div>
	

<script type="text/javascript">

 $("#upload").change(function( event ) {	   
	   if (this.files && this.files[0]) {
	        var reader = new FileReader();

	        reader.onload = function (e) {
	            $('#imgpreview').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(this.files[0]);
	    }
	  
});
</script>
