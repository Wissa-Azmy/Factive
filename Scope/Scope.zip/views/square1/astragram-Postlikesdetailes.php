 <style>
 #contentdivlikes {background-color: rgba(255, 255, 255, 0.39); }
 </style>
<?php 
  if(!empty($likes)) {?>
<br/>
            <ul  style="list-style-type: none;"  id="containerdivcontainerx"><li></li>
        <?php  foreach($likes as $c) { ?>

	   <li class="li-<?php echo $c -> likes_id; ?>">
	   <img src="<?php echo base_url('assets/images/profile/' . $c -> avatar . ''); ?>" style="width:45px; height:45px">
	   <span class="com_name" >

        <a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>" style="color:#fff">
        <?php echo $c -> fname . " " . $c -> lname; ?></a></span></li>

						<?php
 }
  ?>
						</ul>
<br/>
<? } ?>

                      
