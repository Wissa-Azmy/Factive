<?php

   

  if(!empty($comments)) {?>
							<li></li>
							<?php  foreach($comments as $c) { ?>
							<li class="li-<?php echo $c -> comment_id; ?>">
							<img src="<?php echo base_url('assets/images/profile/' . $c -> avatar . ''); ?>" style="width:65px; height:65px">
							<br/>
							<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span><span><?php echo $c -> text; ?></span>
							<?php
 if($c -> user_id == $this -> session -> userdata('userid')) { ?>
     <span id="<?php echo $c -> comment_id; ?>" class="deletelink"><a class="ddeletelink" >
  <img class="dellink" src="<?php echo base_url('/assets/images/delete.png');?>" /></a></span>
							<?php } ?>
							</li>
						<?php
 }
  ?>
						
<? } ?>
