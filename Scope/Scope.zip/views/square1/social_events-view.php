<img src="<?php echo base_url('assets/images/logos/Social events.png'); ?>" 
	class="logoSoonScreen" />
<img src="<?php echo base_url($commonMessages->line('path_SoonLogo')); ?>" style="width:100%;margin-top: -140px;height: 100%;"/>
