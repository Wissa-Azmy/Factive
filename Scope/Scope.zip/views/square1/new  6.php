<?php if (!empty($rows)) {  foreach($rows as $r) : ?>
	
 <?php //if (!empty($r->person)) : ?>
	
	
	<div class="containerx-box">
	<?php foreach($r -> persons as $pp) : ?>
	<div class="person">
		<a href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><img src="<?php echo base_url('assets/images/profile/'. $pp -> avatar); ?>"/></a>
		<br />
		<a style="color:#000; text-align: center; text-decoration: none;" href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><span><?php echo $pp -> fname; ?></span></a>
	</div>
	<?php endforeach; ?>
	<?php //endif; ?>
			<div style=" width: 320px; float: left;padding: 15px; ">
		<p style=" font-size: 22px; ">
		<?php 
		$verhashtext=$r -> details;
		$textarr=explode(" ",$verhashtext);
		$looper=count($textarr);
		$varwords=array();
		while($looper>0){
		$looper--;
		$word=$textarr[$looper];
		
		if($word[0]=="#"){
		$getit=0;
		$countaary=count($varwords);
		while($countaary>0){
		$countaary--;
		if($varwords[$countaary]==$word){
		$getit=1;
		break;
		}
	
		}
		if($getit==0){
		$varwords[]=$word;
		$str= ltrim($word,'#');
		$varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
		$verhashtext=str_replace($word,$varlinktext,$verhashtext);
		}
		
		
		}
		
		}
		
		
		 echo $verhashtext;
		 ?>
   </p>
  </div>
	    <div class="containerx-box-img">

                
<a  data-toggle="modal" data-target="#myModal<?php echo $r -> post_id;?>">
	        <img src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" />

</a>

	    </div>
	    
	    <div class="col-xs-12 containerx-box-liks">
	        <div class="containerx-box-heart tcent nopad nomar"><a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like"><i class="glyphicon glyphicon-heart <?php
            if ($r -> like_status)
                echo ' glyphicon-red';
 ?>" style="font-size:27px;"></i></a></div>
	        <?php if (!empty($r->likes)) : ?>
		        <?php $x = 0; ?>
		        <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 35px; font-size: 12px;">
			        <?php
          foreach($r->likes as $l){
           $ilikescount= $l->count;
        break;
}
                                   echo $ilikescount." :";

                                  foreach($r->likes as $l) : ?>
				        <?php if (($x >= 1) || ($x >= 2)) : ?>
			        		and
			        	<?php endif; ?>
				        <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
			        	<?php ++$x; if($x==3)break;?>

			        <?php endforeach; ?>

		        </div>
           <?php if ($ilikescount>1) { ?>
<div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">
	      
<a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('square/astragram/likesload/'.$r -> post_id); ?>" >
							<i>...</i>
						</a>
	        </div>
            <?php } ?>
	        <?php endif; ?>
	        
	    </div>
	    
	    <div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment">
	      	<ul class="timeline">
	      		<li>
	      		</li>
	      		<?php if (!empty($r->comments)) : ?>
	      		<?php foreach($r->comments as $c) : ?>
	    		<li id=li-<?php echo $c -> comment_id;?>>				
					<img src="<?php echo base_url('assets/images/profile/'. $c -> avatar); ?>">
					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c -> text; ?></span>
					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
					
					<span id="<?php echo $c -> comment_id; ?>" class="deletelink"><a class="ddeletelink" href="#Exit"><img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" /></a></span>
					<?php } ?>
				</li>
				<?php endforeach; ?>
				<?php endif; ?>
	    	</ul>
	    </div>
	    <form class="frmcomment" action="">
	        <div class="col-xs-12 containerx-box-comment">
	            <textarea placeholder="<?php echo $commonMessages->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
	        </div>
	    </form>
	</div>
	<br /><br />
	<div class="modal fade" id="myModal<?php echo $r -> post_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style=" border-bottom: 0; ">
        <button type="button" class="close" data-dismiss="modal" style="padding: 5px;"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      
      </div>
	  
	  
	  
	  
      <div class="modal-body">
       <div class="containerx-box">
	<?php foreach($r -> persons as $pp) : ?>
	<div class="person">
		<a href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><img src="<?php echo base_url('assets/images/profile/'. $pp -> avatar); ?>"/></a>
		<br />
		<a style="color:#000; text-align: center; text-decoration: none;" href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><span><?php echo $pp -> fname; ?></span></a>
	</div>
	<?php endforeach; ?>
	<?php //endif; ?>
			<div style=" width: 320px; float: left;padding: 15px; ">
		<p style=" font-size: 22px; ">
		<?php 
		$verhashtext=$r -> details;
		$textarr=explode(" ",$verhashtext);
		$looper=count($textarr);
		$varwords=array();
		while($looper>0){
		$looper--;
		$word=$textarr[$looper];
		
		if($word[0]=="#"){
		$getit=0;
		$countaary=count($varwords);
		while($countaary>0){
		$countaary--;
		if($varwords[$countaary]==$word){
		$getit=1;
		break;
		}
	
		}
		if($getit==0){
		$varwords[]=$word;
		$str= ltrim($word,'#');
		$varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
		$verhashtext=str_replace($word,$varlinktext,$verhashtext);
		}
		
		
		}
		
		}
		
		
		 echo $verhashtext;
		 ?>
   </p>
  </div>
	    <div class="containerx-box-img">
	        <img src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" />

	    </div>
	    
	    <div class="col-xs-12 containerx-box-liks">
	        <div class="containerx-box-heart tcent nopad nomar"><a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like"><i class="glyphicon glyphicon-heart <?php
            if ($r -> like_status)
                echo ' glyphicon-red';
 ?>" style="font-size:27px;"></i></a></div>
	        <?php if (!empty($r->likes)) : ?>
		        <?php $x = 0; ?>
		        <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 35px; font-size: 12px;">
			        <?php
          foreach($r->likes as $l){
           $ilikescount= $l->count;
        break;
}
                                   echo $ilikescount." :";

                                  foreach($r->likes as $l) : ?>
				        <?php if (($x >= 1) || ($x >= 2)) : ?>
			        		and
			        	<?php endif; ?>
				        <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
			        	<?php ++$x; if($x==3)break;?>

			        <?php endforeach; ?>

		        </div>
           <?php if ($ilikescount>1) { ?>
<div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">
	      
<a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('square/astragram/likesload/'.$r -> post_id); ?>" >
							<i>...</i>
						</a>
	        </div>
            <?php } ?>
	        <?php endif; ?>
	        
	    </div>
	    
	    <div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment">
	      	<ul class="timeline">
	      		<li>
	      		</li>
	      		<?php if (!empty($r->comments)) : ?>
	      		<?php foreach($r->comments as $c) : ?>
	    		<li id=li-<?php echo $c -> comment_id;?>>				
					<img src="<?php echo base_url('assets/images/profile/'. $c -> avatar); ?>">
					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c -> text; ?></span>
					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
					
					<span id="<?php echo $c -> comment_id; ?>" class="deletelink"><a class="ddeletelink" href="#Exit"><img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" /></a></span>
					<?php } ?>
				</li>
				<?php endforeach; ?>
				<?php endif; ?>
	    	</ul>
	    </div>
	    <form class="frmcomment" action="">
	        <div class="col-xs-12 containerx-box-comment">
	            <textarea placeholder="<?php echo $commonMessages->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
	        </div>
	    </form>
	</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  
      </div>
    </div>
  </div>
</div>
<?php endforeach; } ?>



