<?php $x = 0; 
                             if(is_array($likes)){

               foreach($likes as $l){
              $ilikescount= $l->count;
               break;
          }  
                             echo $ilikescount." :";
                           
                              foreach($likes as $l) : ?>
			   <?php if (($x >= 1) || ($x >= 2)) : ?>
			        		and
			        	<?php endif; ?>
	                          <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
			        	<?php
                                             ++$x;
                                             //if($x==4)break;
                                              endforeach;
                                           }
                                            ?>
