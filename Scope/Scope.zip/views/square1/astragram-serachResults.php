<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title></title>

		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>" />
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/astragram.css'); ?>" />
		<style>
			/*body {
			 padding-top: 70px;
			 }*/
			.thumb {
				margin-bottom: 30px;
			}
			footer {
				margin: 50px 0;
			}
		</style>
	</head>
	<body>
		<?php echo $this -> load -> view('header/astragram-header'); ?>

		<div class="containerprofile">

			<div class="row">

				<div class="col-lg-12 tumbsimgs">
					
					<?php if(!empty($rows)):
					foreach($rows as $r) :
					?>
					<div class="col-lg-3 col-md-4 col-xs-6 thumb">
						<a class="thumbnail" href="#" style="height: 256px"> <img class="img-responsive" src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" alt=""> </a>
					</div>
					<?php 		
					endforeach;
					endif;
					 ?>
				</div>
			</div>

		</div>
	</body>
	

	
		
