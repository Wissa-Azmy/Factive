 <style>
    .modal-body .timeline{
    	padding-top:10px;
    }
	.modal-body .timeline img {
		width: 65px;
		height: 65px;
		margin-top: 5px;
	}
	.modal-body .tip {
		text-decoration: none;
		font-size: 28px;
	}
	.modal-body li {
		list-style: none;
	}
	.tooltip fade top in{
		width:80px;
		text-align:center;
	}
	.modal-body .tooltip-inner{
		height: auto;
		/*width:65%;
		margin-left:50px;*/
	}
	.modal-body .timeline .dellink{
		width:20px;
		height: 20px;
		cursor:pointer;
	} 
</style>

<?php 
$ilikescount=0;
$postid=0;
foreach($rows as $r) : ?>

<?php $postid=$r -> post_id;  ?>
<div class="containerxdiv">
	<div class="row">
		<div class="col-md-6">
			<div class="containerx-box-img">
						<img  data-url="<?php echo base_url('square/astragram/postView/' . $r -> post_id . ' '); ?>" src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" />
					</div>
				
		</div>

		<div class="col-md-6">
			<div class="panel panel-default">
				<!--div class="panel-heading text-center"-->
				<div class="col-xs-12 containerx-box-liks">

<div class="containerx-box-heart tcent nopad nomar"><a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like"><i class="glyphicon glyphicon-heart <?php
            if ($r -> like_status)
                echo ' glyphicon-red';
 ?>" style="font-size:27px;"></i></a></div>
	        <?php if (!empty($r->likes)) : $x = 0; ?>
						<div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 35px; font-size: 12px; border-right: 1px solid #ddd;">
        	<?php  foreach($r->likes as $l){$ilikescount= $l->count; break; }   echo $ilikescount." :";  foreach($r->likes as $l){ ?>
	        <?php if (($x >= 1) || ($x >= 2) || ($x >= 3) || ($x >= 4)) : ?>
			        		  ,
			        	      <?php endif; ?>
			        	      <?php if ($x >= 5): ?>
			        	      and
			        	      <?php endif; ?>
							<a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
							<?php ++$x; ?>
							<?php } ?>
						</div>
					<?php endif; ?>
					
					 <?php if ($ilikescount>1) { ?>
<div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">
	      
<a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('square/astragram/likesload/'.$r -> post_id); ?>" >
							<i>...</i>
						</a>
	        </div>
            <?php } ?>
					

				</div>
				<!--/div-->
				<div class="panel-body">
	  <div id="commentcontainerid" class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment" style="padding:0">
<?php 
 $comments=$r->comments; 

  if(!empty($comments)) {?><ul class="timeline" id="containerdivcontainerx">
							<li></li>

							<?php  foreach($comments as $c) { ?>
							<li class="li-<?php echo $c -> comment_id; ?>">
							<img src="<?php echo base_url('assets/images/profile/' . $c -> avatar . ''); ?>" style="width:65px; height:65px">
							<br/>
							<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span><span><?php echo $c -> text; ?></span>
							<?php
 if($c -> user_id == $this -> session -> userdata('userid')) { ?>
     <span id="<?php echo $c -> comment_id; ?>" class="deletelink"><a class="ddeletelink" >
  <img class="dellink" src="<?php echo base_url('/assets/images/delete.png');?>" /></a></span>
							<?php } ?>
							</li>
						<?php
 }
  ?>
						</ul>
<? } ?>

                       </div>
      
				<form class="frmcomment" action="">
					<div class="col-xs-12 containerx-box-comment" style="padding:0; top:20px;">
				<textarea placeholder="<?php echo $commonMessages->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
						</div>
					</form>
				</div>

			</div>
		</div>
	</div>
</div>
<?php endforeach; ?>

<!--script>
	$(document).ready(function() {
		$(".tooltiplink").tooltip({
			'selector' : '',
			'placement' : 'top',
			'container' : 'body'
		});
	});

	$('.auto-tooltip').tooltip(); 
</script-->


 <script type="text/javascript">
	$(document).ready(function() {
		/*	$('.tip').tooltip({
		 html : true
		 });*/
	});
 </script>
  <script type="text/javascript" language="javascript">
        jQuery(document).ready(function(){
	       $('.tip').mouseover(function(){
	        $.ajax({
	         url: "<?php echo base_url('square/astragram/tooltip'); ?>
				",
				type: 'POST',
				data: {
				id: $(this).attr("rel"),
				},
				dataType: 'json',
				success: function(aircraft_j) {
				var rslt = "<ul style='display:table;padding:0;margin:0;text-align:center'>";
				for(i=0; i < aircraft_j.length; i++) {
				rslt += '<li style="width:100%;float:left;list-style:none;padding:2px 0">';
				rslt +=aircraft_j[i].fname;
				rslt += "</li>";
				//console.log(aircraft_j[i].fname);
				}
				rslt += '</ul>';
				$('.tip').attr('data-original-title', rslt).tooltip({html:true, trigger: 'click hover', placement: 'bottom',  'delay': { hide: 4000 }});
				$('.tip').trigger( "click" );
				//$('.tip').tooltip({html:true, trigger: 'click'}).click();
				}
				});
				return false;
				});
				});

      
            var page_index = 0;
            $("#loadmorbtn").click(function() {
                        
			 $.ajax({ type: "GET",url :"<?php echo base_url('square/astragram/commentloadmore'); ?>",
								dataType: "html",
								data : {
                                                                postid :<?php echo $postid ; ?>,
								index : ++page_index,

								},success: function(response) {
$("#commentcontainerid").append(response);
								}
								});

								});

   </script>
