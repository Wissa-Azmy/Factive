<div class="modal-body"> <style>
    .modal-body .timeline{
    	padding-top:10px;
    }
	.modal-body .timeline img {
		width: 65px;
		height: 65px;
		margin-top: 5px;
	}
	.modal-body .tip {
		text-decoration: none;
		font-size: 28px;
	}
	.modal-body li {
		list-style: none;
	}
	.tooltip fade top in{
		width:80px;
		text-align:center;
	}
	.modal-body .tooltip-inner{
		height: auto;
		/*width:65%;
		margin-left:50px;*/
	}
	.modal-body .timeline .dellink{
		width:20px;
		height: 20px;
		cursor:pointer;
	} 
</style>

<div class="modal-body">
	<div class="row">
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-body">

					<div class="containerx-box-img">
						   <img src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" />
					</div>
				</div>
			</div>
		</div>

		<div class="col-md-6">
			<div class="panel panel-default">
				<!--div class="panel-heading text-center"-->
				<div class="col-xs-12 containerx-box-liks">
	        <div class="containerx-box-heart tcent nopad nomar"><a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like"><i class="glyphicon glyphicon-heart <?php
            if ($r -> like_status)
                echo ' glyphicon-red';
 ?>" style="font-size:27px;"></i></a></div>
	        <?php if (!empty($r->likes)) : ?>
		        <?php $x = 0; ?>
		        <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 35px; font-size: 12px;">
			        <?php
          foreach($r->likes as $l){
           $ilikescount= $l->count;
        break;
}
                                   echo $ilikescount." :";

                                  foreach($r->likes as $l) : ?>
				        <?php if (($x >= 1) || ($x >= 2)) : ?>
			        		and
			        	<?php endif; ?>
				        <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
			        	<?php ++$x; if($x==3)break;?>

			        <?php endforeach; ?>

		        </div>
           <?php if ($ilikescount>1) { ?>
<div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">
	      
<a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('square/astragram/likesload/'.$r -> post_id); ?>" >
							<i>...</i>
						</a>
	        </div>
            <?php } ?>
	        <?php endif; ?>
	        
	    </div>
				<!--/div-->
				<div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment">
	      	<ul class="timeline">
	      		<li>
	      		</li>
	      		<?php if (!empty($r->comments)) : ?>
	      		<?php foreach($r->comments as $c) : ?>
	    		<li id=li-<?php echo $c -> comment_id;?>>				
					<img src="<?php echo base_url('assets/images/profile/'. $c -> avatar); ?>">
					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c -> text; ?></span>
					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
					
					<span id="<?php echo $c -> comment_id; ?>" class="deletelink"><a class="ddeletelink" href="#Exit"><img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" /></a></span>
					<?php } ?>
				</li>
				<?php endforeach; ?>
				<?php endif; ?>
	    	</ul>
	    </div>
	    <form class="frmcomment" action="">
	        <div class="col-xs-12 containerx-box-comment">
	            <textarea placeholder="<?php echo $commonMessages->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
	        </div>
	    </form>

			</div>
		</div>
	</div>
</div>

<!--script>
	$(document).ready(function() {
		$(".tooltiplink").tooltip({
			'selector' : '',
			'placement' : 'top',
			'container' : 'body'
		});
	});

	$('.auto-tooltip').tooltip(); 
</script-->


 
  </div>