	<div id="trends" class="trends">
				<ul>

				<li class="trendstitle" style="color:#fff"><?php echo $commonMessages->line('Trendslabel'); ?> </li>
<?php  $idv=1; foreach($trends as $trehash) : ?>
					<li >
					<?php $strh= ltrim($trehash->hashtag,'#');?>
<a  href="<?php echo base_url('square/astragram/hashview/'.$strh);?>" id="n<? echo $idv ; ?>" >
						<?php echo $trehash->hashtag;?>
</a>
					</li>
<?php $idv++; endforeach; ?>

					
			</ul>
			</div>
			
			
		