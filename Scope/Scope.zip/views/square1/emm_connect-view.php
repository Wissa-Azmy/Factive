<img src="<?php echo base_url($commonMessages->line('path_SoonLogo')); ?>" style="width:100%;"/>
