<img src="<?php echo base_url('assets/images/logos/Astragram.png'); ?>" 
	class="logoSoonScreen" />
<img src="<?php echo base_url($commonMessages->line('path_SoonLogo')); ?>" style="width:100%;"/>
