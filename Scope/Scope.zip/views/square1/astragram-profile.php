<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<title><?php
		echo $urows[0]['fname'] . " " . $urows[0]['lname'];
                $coverimg=$urows[0]['cover'];
		 ?></title>

		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>" />
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/astragram.css'); ?>" />
		<style>
			.thumb {
				margin-bottom: 30px;
			}
			footer {
				margin: 50px 0;
			}
		</style>
	</head>

	<body style=" background-color:#b3b3b3;">

		<?php echo $this -> load -> view('header/astragram-header'); ?>

		


<div  style="width:100%; background-color:#333333; height: 277px;position: absolute;">
    


		</div>
		

		<div class="containerprofile">
			
			<div class="row">
			

			<div class="col-xs-1 col-ms-1 col-lg-1"></div>
		        <div class="col-xs-10 col-ms-10 col-lg-10 cover" id="output">	
                        <img src="<?php echo base_url('assets/images/astragram/covers/'.$coverimg);?>"  />

            <?php if($ownerid==$urows[0]['id']) {?>
			

                                 
               <form  class="cover-content" action="<?php echo base_url('/profile/updatecover'); ?>"  method="post" enctype="multipart/form-data" id="MyUploadForm">
				<input style="display: none;" name="image_file" id="imageInput" type="file"  />
				<input  id="submit-btn" type="button"  value="Update Cover photo" style=" border-radius: 15px;font-size: 15px; margin-top: 10px;" />
				
				 <input  type="hidden" value="<?php echo $coverimg; ?>" name="cover"  />
			</form>
			
			
			<form  class="cover-content" style="margin-top: 35px;" action="<?php echo base_url('/profile/delcover'); ?>"  method="post" enctype="multipart/form-data" id="MyUploadFormm">
				
				<input  id="submit-btnn" type="button" style=" width: 157px; border-radius: 15px;font-size: 15px; margin-top: 10px;"  value="Delete Cover photo"  />
				
				 <input  type="hidden" value="<?php echo $coverimg; ?>" name="coverd" />
			</form>
			

<? } ?>
		</div>
			 
		<div class="col-xs-1 col-ms-1 col-lg-1"></div>

				<div class="col-sm-12 col-lg-12 col-md-12 col-xs-12 personalinf">
				<div class="col-lg-3 col-md-4 col-xs-6 thumbusrimg">
			
	      <?php $avatar=$urows[0]['avatar']; ?>
          <span class="thumbnail" href="#" style=" background: url(); border: 0; "> <img class="img-responsive"  src="<?php echo base_url('assets/images/profile/' . $avatar); ?>" style=" width: 70%; " alt=""> </span>
	
		</div>
<div class="row">
	<?php if(!empty($rows)){ ?>
          <div class="counterphoto" href=""> <?php $count=count($rows); echo  ($count." Photos"); ?> </div>
<? } ?>

			</div>
			</div>
				<div class="col-lg-12 tumbsimgs">
					<?php 
					if(!empty($rows)):
					foreach($rows as $r) :
					?>
				<div class="col-lg-3 col-md-4 col-xs-6 thumb">
 <?php if($ownerid!=$urows[0]['id']) {?>
						<a class="thumbnail" data-toggle="modal" data-target="#myModall<?php echo $r -> post_id;?>"  style="height: 200px"> <img class="img-responsive" src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" alt=""> </a>
					
<? }  else { ?>

    <form  action="<?php echo base_url('/square/astragram/delmyimg/'.$ownerid); ?>" class="delimgform" method="post"data-btnid="#btn<?php echo $r -> post_id ; ?>" >
						<a class="thumbnail"  data-toggle="modal" data-target="#myModall<?php echo $r -> post_id;?>" > <img class="img-responsive"  src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" alt=""> </a>
			<input  id="btn<?php echo $r -> post_id ; ?>" class="submitbtn" type="submit" value="delete" />
                        <input  type="hidden" value="<?php echo $r -> post_id ; ?>" name="imgid" />
	</form>
<? } ?>




<div class="modal fade" id="myModall<?php echo $r -> post_id;?>" tabindex="-1"  style="display: none;"role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style=" border-bottom: 0; ">
        <button type="button" class="close" data-dismiss="modal" style="padding: 5px;"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      
      </div>
	  
	  
	  
	  
      <div class="modal-body">
       <div class="containerx-box">
			<div style=" width: 100%; float: left;padding: 23px; ">
		<p style=" font-size: 18px; ">
		<?php 
		$verhashtext=$r -> details;
		$textarr=explode(" ",$verhashtext);
		$looper=count($textarr);
		$varwords=array();
		while($looper>0){
		$looper--;
		$word=$textarr[$looper];
		
		if($word[0]=="#"){
		$getit=0;
		$countaary=count($varwords);
		while($countaary>0){
		$countaary--;
		if($varwords[$countaary]==$word){
		$getit=1;
		break;
		}
	
		}
		if($getit==0){
		$varwords[]=$word;
		$str= ltrim($word,'#');
		$varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
		$verhashtext=str_replace($word,$varlinktext,$verhashtext);
		}
		
		
		}
		
		}
		
		
		 echo $verhashtext." <span style='  font-size: 15px; color: #8E8E8E; '> with </span> ".$r -> who ." <span style='  font-size: 15px; color: #8E8E8E; '>@ </span> ".$r -> where;
		 ?>
   </p>
  </div>
	    <div class="containerx-box-img">
	        <img src="<?php echo base_url('assets/images/astragram/' . $r -> image . ''); ?>" style=" margin-bottom: 35px;max-width: 550px; " />

	    </div>
	    
	  

	</div>
	</div>
      </div>
     
    </div>
  </div>
</div>





					<?php endforeach;
						else:
						echo "<p>No Photos!</p>";
						endif;
                     ?>
				</div>
			</div>

			

		</div>


	</body>
	

  <script type="text/javascript">

$(document).ready(function() {
<?php if($ownerid==$urows[0]['id']) {?>
$("#MyUploadForm").hide();
$("#MyUploadFormm").hide();
$("#output").hover(function(){
  $("#MyUploadForm").show();
  $("#MyUploadFormm").show();
  },function(){
  $("#MyUploadForm").hide();
  $("#MyUploadFormm").hide();
}); 


   $("#submit-btn").click(function(e) {
			$('#imageInput').trigger('click');
		});

		$("#imageInput").change(function() {
                    $("#MyUploadForm").submit();
               });
$("#submit-btnn").click(function(e) {
			   $("#MyUploadFormm").submit();
		});

	

$(".submitbtn").hide();
$(".delimgform").hover(function(){
id=$(this).attr("data-btnid");
  $(id).show();
  },function(){
  id=$(this).attr("data-btnid");
  $(id).hide();
}); 




<?php } ?>
  });
</script>

	

