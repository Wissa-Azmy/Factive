
<div id="trends" class="trends" style="top: 20%;">
<div style=" background-image: url(<?php echo base_url('assets/images/cal.png'); ?>); width: 20%;  float: left;text-align: center; background-repeat: no-repeat; background-size:contain; background-position:center; margin-top: 1%;" >
<p style=" color: #FF0000; font-weight: bold; font-size: 2.0vw; margin-bottom: 0px;  padding: 13% 5% 5% 0%;" >
                              <?php  $idv=1; foreach($comps as $trehash) : ?>
							  <?php 
							   $start = date('Y-m-d',strtotime("now"));
                               $end = date('Y-m-d',$trehash->end_date);                              
                               if (strtotime($end) >= strtotime($start)) {
                               		$diff = (strtotime($end)- strtotime($start))/24/3600;
									echo number_format($diff, 0, '', '');
                               }else{
									echo '0';
							   }
                              
							 $idv++;
							 endforeach; ?> 
						</p>
</div>	
<div style=" width: 80%; float: left; margin-left: 0px; ">

				<ul style=" /* margin-left: 3px; */ padding: 3px; ">

		<li class="trendstitle" style="background-color: rgba(0, 0, 0, 0.46);font-size: 1.5vw;padding: 0px;color:#fff;text-align: center;"> Challenge of the Month <?php  $idv=1; foreach($comps as $trehash) : ?>
			<?php $strhd= ltrim($trehash->hashtag,'#');?>		
<a  href="<?php echo base_url('square/astragram/hashview/'.$strhd);?>" style=" color: #e05dc2 !important; ">
						<?php echo $trehash->hashtag;?>
						
</a> <?php $idv++; endforeach; ?> </li>

					
			</ul>
			
			</div>
			</div>

			
		<?php if ($diff==0){ ?>
		  
		<style type="text/css">
			.navigation{
				height:120px;
			}
		</style>
				<style>
		.black_overlay{
			display: block;
			position: absolute;
			top: 0%;
			left: 0%;
			width: 100%;
			height: 100%;
			background-color: black;
			z-index:1001;
			-moz-opacity: 0.8;
			opacity:.80;
			filter: alpha(opacity=80);
		}
		.white_content {
			display: block;
position: absolute;
top: 10%;
left: 28%;


padding: 2%;
background-color: white;
z-index: 1002;
overflow: hidden;
background: url(<?php echo base_url('assets/images/winner.png'); ?>) no-repeat center;
background-repeat: no-repeat;
background-size: contain;
background-position: center;
		}
		.aclos {
		background: rgba(195, 195, 195, 0.8);
z-index: 1001;
color: #000;
position: absolute;

left: 67%;
font-size: 1.3vw;

text-align: center;
width: 5%;
height: 5%;
overflow: hidden;

filter: alpha(opacity=0);
-webkit-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
-moz-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
-webkit-transition: opacity 0.3s linear 1.2s;
-moz-transition: opacity 0.3s linear 1.2s;
-o-transition: opacity 0.3s linear 1.2s;
-ms-transition: opacity 0.3s linear 1.2s;
transition: opacity 0.3s linear 1.2s;
top: 6%;
		}
	</style>
		
	
		<div style="width:100%;height:100%">
	    <div id="light" class="white_content"> <a class="aclos" href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">X</a>
		<p style=" margin: 0px;font-size: 2vw;padding: 5%;text-align: center; ">
		 <?php  $idv=1; foreach($comprs as $trehashr) : ?>
		<span style=" color: #820E50; font-size: 1vw;"><?php echo $trehash->hashtag;?> reward </span><br/>
		<span style=" color: #820E50; font-size: 1vw; font-weight: bold;">AND THE WINNER IS</span><br/>
		<?php foreach($trehashr -> persons as $appsd) : ?>
		<a href="<?php echo base_url('square/astragram/profile/' . $appsd -> user_id . ''); ?>" style=" color: #820E50; font-size: 1.5vw; font-weight: bold; "><?php echo $appsd->fname;?> <?php echo $appsd->lname;?></a>
	     <?php endforeach; ?>  
		<br/>
		 <img src="<?php echo base_url('assets/images/astragram/' . $trehashr -> image . ''); ?>" style=" max-width: 50%;padding-bottom: 15%;" />
		<?php 
		 $idv++;
		 endforeach; ?> 
		
		</p>
		</div>
		<div id="fade" class="black_overlay"></div>
		</div>

		
		
	<?php 	} ?>