<script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<style>
   .modal-dialog{
   
   margin: 100px auto;
   }
	.astraupload {
		font-size: 18px;
		width: 50%;
		margin: auto;
	}
	#mypro { background: url(<?php echo base_url('assets/images/upload.png');?>) no-repeat center;
	height: 525px;
	width: 650px;
	box-shadow: 0 0px 0px rgba(0, 0, 0, .5);
	webkit-box-shadow: 0 0px 0px rgba(0, 0, 0, .5);
	border:0;
	}
	
#exampleInputFile
   {
   position: absolute;
   left: -132px;
   opacity: 0;
   filter: alpha(opacity=0);
   }

#browser_box
   {
   width: 150px;
   height: 150px;
   position: relative;
   overflow: hidden;
   background: url(<?php echo base_url('assets/images/face2.png');?>) no-repeat;
   }

#browser_box:active
   {
   background: url(<?php echo base_url('assets/images/face2.png');?>) no-repeat;
   }
   
#up_result
   { 
 list-style: none;
background-color: #fff;
border: 1px transparent;
border-radius: 10px;
width: 70%;
margin: auto;
padding: 10px;
display: none;
position: absolute;
z-index:10000;
}
textarea:focus, input[type="text"]:focus,textarea[type="text"]:focus,   input[type="password"]:focus, input[type="datetime"]:focus, input[type="datetime-local"]:focus, input[type="date"]:focus, input[type="month"]:focus, input[type="time"]:focus, input[type="week"]:focus, input[type="number"]:focus, input[type="email"]:focus, input[type="url"]:focus, input[type="search"]:focus, input[type="tel"]:focus,  input[type="color"]:focus, .uneditable-input:focus, .form-control:focus {  
border-color: none;
box-shadow:none;
outline: none;}
</style>

<div class="astraupload" style=" margin-left: 100px; ">
	<form role="form" action="<?php echo base_url('square/astragram/execute'); ?>" method="post" enctype="multipart/form-data">
		<div class="form-group" id="browser_box" style=" margin: 40px 0 10px 155px; ">
			<input type="file" id="exampleInputFile" name="astrimg"  onchange="readURL(this);" hidden="true" required onclick="startBrowse()"  style=" height: 150px;cursor: pointer; ">
		<img id="blah" src="http://localhost/ne/assets/images/face2.png"  style="width:150px;height:150px"/>
		</div>
		<div class="form-group">
			<input type="text" class="form-control" placeholder="What?#..." name="astrawhat"  style=" background: url(<?php echo base_url('assets/images/1b2.png');?>) no-repeat left; height: 63px; width: 410px; border: 0; padding-left: 50px; ">
		</div>
		<div class="form-group">
			<input type="text" id="upauto" onkeyup="autocomplett()" onblur="cleann()"  class="form-control" placeholder="Who?..." name="astraWhvvo"  style=" background: url(<?php echo base_url('assets/images/22.png');?>) no-repeat left; height: 50px; width: 410px; border: 0; padding-left: 50px;padding-top: 15px; ">
			<input type="hidden" id="upautoo" name="astraWho">
		     <ul id="up_result" ></ul>
		</div>
		<div class="form-group">
			<input type="text" class="form-control" placeholder="Where?..." name="astraWhere"  style=" background: url(<?php echo base_url('assets/images/222.png');?>) no-repeat left; height: 63px; width: 410px; border: 0; padding-left: 50px; ">
		</div>
		<button type="submit" class="btn btn-default">
			Submit
		</button>
	</form>
	
</div>
<script type="text/javascript">

function tarek(name,id) {

       var currenthtml=$('#upauto').val();
	   var divcurrenthtml=currenthtml.lastIndexOf(',');
	  
	   if(divcurrenthtml==-1)
	    currenthtml=currenthtml.substring(0,divcurrenthtml);
		else currenthtml=currenthtml.substring(0,divcurrenthtml)+",";
		
		$("#upauto").val(currenthtml+name);
		
		var currenthtmlid=$('#upautoo').val();
	  
		$("#upautoo").val(currenthtmlid+id+",");
		
		
	}

function cleann() {
		$('#up_result').delay(500).fadeOut('slow');
	}			
			function autocomplett() {
			var keyword = $('#upauto').val();
			
			if(keyword != '' ) {
			var lastone = keyword.split(',');
			var vallen=lastone.length-1;
			 keyword = lastone[vallen];
			 
			if(keyword!=',' && keyword != ''){
			
			$.ajax({
					url : '<?php echo base_url('square/astragram/search2'); ?>
						',
						//dataType : 'json',
						type : 'POST',
						data : {
						req : keyword,
						},
							success : function(data) {
							   
	                           $('#up_result').show().html(data);
							   }
							 });
							}
							}
						}	

	</script>