 <?php

$current = $this -> uri -> segment(1);
$user = $this -> session -> userdata('username');

//*****************************
// lang
// ----------------------
$lang = 'en';
// default lang
// set lang if it evaluated before
if ($this -> session -> userdata('lang')) {
	$lang = $this -> session -> userdata('lang');
}
// ----------------------

// i18n : FE_RESOURCES - assets (imgs/pdfs/vids/...)
$this -> lang -> load("commonMessages", $lang);

// pass Messages to view
$commonMessages = $this -> lang;
// *****************************
?>
<!--////////////////////////////////////////////////////-->

<!DOCTYPE HTML>
<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>" />
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/astragram.css'); ?>" />
		<title>Astragram</title>
		<!--style>@import url(http://fonts.googleapis.com/css?family=Cherry+Swash);</style-->
		<style>
			.modal-body .tooltip-inner {
	height: auto;
	/* width: 65%; */
	/* margin-left: 50px; */
}
		</style>
	<body>    
	<?php echo $this -> load -> view('header/astragram-header'); ?>
  
         <?php if($page!="square/astragramPostView") { ?>
		<?php echo $this -> load -> view('square/trends-view'); ?>
		<?php echo $this -> load -> view('square/comp-view'); ?>
	
		<div class="containerx" id="containerdivcontainerx">
			<?php echo $this -> load -> view('square/astragram-post'); ?>
		</div>
            <? } else   echo $this -> load -> view('square/astragramPostView');  ?>
		<div id="wrapx">
                <img class="bgfade n1" src="<?php echo base_url('assets/images/astragram/bg/Together.jpg'); ?>">
				<img class="bgfade n2" src="<?php echo base_url('assets/images/astragram/bg/Best-smile.jpg'); ?>">
				<img class="bgfade n3" src="<?php echo base_url('assets/images/astragram/bg/Value-in-action.jpg'); ?>">
				<img class="bgfade n4" src="<?php echo base_url('assets/images/astragram/bg/one-team.jpg'); ?>">
				<img class="bgfade n5" src="<?php echo base_url('assets/images/astragram/bg/Odd-catch.jpg'); ?>">
		</div>
		
	<div id="contentlikes" class="modal" aria-hidden="true" style="display: none;">	
      <div class="modal-sdialog" >
        <div class="modal-content" id="contentdivlikes">
          <div class="modal-body" >

</div>
</div>
</div>
<script type="text/javascript">
		
	</script>

			
		<script type="text/javascript">
				$(window).load(function() {
				$('img.bgfade').hide();
				$('li.bgfade').hide();
				///li
				var dg_H = $(window).height();
				var dg_W = $(window).width();
				$('#wrapx').css({
					'height' : dg_H,
					'width' : dg_W
				});
				/*function anim() {
				 $("#wrapx img.bgfade").first().appendTo('#wrapx').fadeOut(1500);
				 $("#wrapx img").first().fadeIn(1500);
				 setTimeout(anim, 3000);
				 }*/
				function anim() {
					$("#wrapx img.bgfade").first().appendTo('#wrapx').fadeOut(1500);
					var order = $("#wrapx img").first().fadeIn(1500).attr('class').split(' ').pop();
					//$('#trends li').css("background", 'none');
					//$('#trends li.' + order).css("background-color", 'yellow');
					$('#trends li a').css("color", '#fff');
					
					$('#' + order).css("color", '#cdc442');

					setTimeout(anim, 3000);

				}

				anim();
			})
			$(window).resize(function() {
				//window.location.href = window.location.href
			});
			

			
			///////////////////////////////////////////////////////////////    
            var page_index = 0;

	        $(window).scroll(function() {
			if  ($(window).scrollTop() == $(document).height() - $(window).height())
                {
                	 //console.log(page_index);
                	 $.ajax({
                	 	    type: "GET",
							url : "<?php echo base_url('square/astragram/'.$loadmore); ?>",
								dataType: "html",
								data : {
								index : ++page_index,

								},success: function(response) {
								$("#containerdivcontainerx").append(response);
								}
								});

								}

								});



            $(".openmodelbtn").live("click", function() {
            
			$.ajax({
				url : $(this).attr("data-url"),
			}).done(function(response) {
                               $('#contentdivlikes').html(response);
				$('#contentlikes').modal('show');

			});

			
		});


		</script>

		<script type="text/javascript">
		//$(function () { 
         // $("[data-toggle='tooltip']").tooltip(); 
        //});
	
				/*$(".openmodel").live("click", function() {
				$.ajax({
					url : $(this).attr("data-url"),
				}).done(function(response) {
					$('.modal-body').html(response);
					$('#astmodel').modal('show');

				})
				//$('#astmodel').modal('show'); // tODO:delete it
			});*/

			////////////////////////////////////////////////////////////////
			$('.like').live("click", function(e) {
			  
               if($(this).children().hasClass('glyphicon-red')) {
               	  $(this).children().removeClass('glyphicon-red');
               	  $.ajax({
					    url : "<?php echo base_url('square/astragram/dislike'); ?>",
						dataType: "html",
						data : {
						postId : $(this).attr("id"),
						},success: function(response) {
                                                 var res = response.split("###");
                                                 divid="#div"+res[0];
						$(divid).html(res[1]);


						}

						});
						} else {
						$(this).children().addClass('glyphicon-red');
						$.ajax({
						url : "<?php echo base_url('square/astragram/like'); ?>",
						dataType: "html",
						data : {
						postId : $(this).attr("id"),
						},success: function(response) {
                                                var res = response.split("###");
                                                divid="#div"+res[0];
						$(divid).html(res[1]);



						}

						});
						}
						e.preventDefault();
						});

						///////////////////////////////////////////////////////////////

						jQuery(".astcomment").live("keydown", function(e) {

						if(e.which==13) {
						picid = $(this).attr("data-id");

						//TODO REMOVED IT JUST TEST
						/*
						rslt = "<li>";
						rslt += "<img src=\"<?php echo base_url('assets/images/astragram/imgbox.jpg');?>\" />";
						rslt += "<span  class=\"com_name\">Mahmoud Soliman</span>";
						rslt += "<span>" + $(this).val() + "</span>";
						rslt += "</li>";
						*/
						//$("'div[data-id=" + picid + "][data-type='rsltcomment'] ul").append(rslt);

						$.ajax({
							//url : "CONTROLER",
							url : "<?php echo base_url('square/astragram/comments'); ?>",
							dataType: "json",
							data : {
							comment : $(this).val(),
							postId : picid
						},success: function(response) {
						//response = jQuery.parseJSON( response );
						
			                //rslt = rslt = "<li id=li-"+picid+" data-id='"+response.last_id+"'>";
							rslt = rslt = "<li class='li-"+response.last_id+"'>";
							rslt += "<img src=\"<?php echo base_url('assets/images/profile');?>/" + response.image + "\" />";
							rslt += "<span  class=\"com_name\">" + response.name + "</span>";
							rslt += "<span>" + response.comment + "</span>";
							rslt += "<span id="+response.last_id+" class=\"deletelink\" ><a val="+response.last_id+" class=\"ddeletelink\" ><img class=\"dellink\"  src=\"<?php echo base_url('assets/images/delete.png');?>"+ "\" /></a>"  + "</span>";
							//rslt += "<span class=\"deletelink\" val="+picid+"><a href=\""+ "\"><img src=\"<?php echo base_url('assets/images/delete.png');?>"+ "\" /></a>"  + "</span>";
							rslt += "</li>";
			
							$("'div[data-id=" + picid + "][data-type='rsltcomment'] ul").append(rslt);
							$(".astcomment").val("");
							}
		
						});
		
						e.preventDefault();
						}
						});
		</script>
		
		<script type="text/javascript">
			$(document).ready(function() {
				$(".deletelink").live("click", function(){
					var id = $(this).attr("id");
					$.ajax({
						type : "post",
						url : "<?php echo base_url('square/astragram/delcomment'); ?>",
							data : "id=" + id,
							success : function(msg, string, jqXHR) {
										$(".li-" + id).hide("slow", function() {
											//console.log('id[li-' + id + ']');
											//$('id[li-' + id + ']').hide("slow", function() {
										$(this).remove();
									});
								}
							});
						});
                        $('.close').on('click', function () {
						// location.reload();
						});
					});
		</script>
		
		
	</body>
	<!--div id="astmodel" class="modal" aria-hidden="true" style="display: none;">	
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="myModalLabel">Modal title</h4>
          </div>
          <div class="modal-body"-->
             <!-----------------------Error Messages------------------------------------------------------>
		<?php //if( isset($showMessage) && ($showMessage==true) ) { ?>
		<!--div id="messagesGrid" class="col-xs-12">
			<div class="alert <?php
			if ($type == 'Error') { echo 'alert-danger';
			} else { echo 'alert-success';
			}
 ?>" style="text-align: center; font-size: 13px; margin: 20px 90px">
				<b><?php
				if ($type == 'Error') { echo $commonMessages -> line('ErrorOccurred');
					'Error Occurred ...';
				} else { echo 'Action Done Successfully ...';
				}
 ?></b>
				<br />
				<?php echo $messageToBeShow; ?>
			</div>
		</div>
		<?php //} ?>		
	
		<?php if(validation_errors()) {
		?>
		<div class="alert alert-danger" style="display:;">
			<button type="button" class="close" data-dismiss="alert">
				<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
			</button>
			<b><?php echo $commonMessages -> line('ErrorOccurred'); ?></b>
			<?php
			if (validation_errors())
				echo "<ul>";
			echo validation_errors('<li>', '</li>');
			echo "</ul>";
			?>
		</div>
		<?php } ?>
		<!-----------------------End Error Messages---------------------------------------------------->
          <!--/div>
        </div>
      </div>
    </div-->
</html>
