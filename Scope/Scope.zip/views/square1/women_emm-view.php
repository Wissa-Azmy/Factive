<img src="<?php echo base_url('assets/images/logos/Women@EMM.png'); ?>" class="logoSoonScreen" />
<img src="<?php echo base_url($commonMessages->line('path_SoonLogo')); ?>" style="width:100%;height: 100%;margin-top: -140px;"/>
