<img src="<?php echo base_url('assets/images/logos/Book of the month.png'); ?>"	class="logoSoonScreen" style=" width: 15%; height: 30%; " />
<img src="<?php echo base_url($commonMessages->line('path_SoonLogo')); ?>" style="width:100%;margin-top: -140px;height: 100%;"/>
