<br/><?php if (!empty($rows)) {  foreach($rows as $r) : ?>
	
 <?php //if (!empty($r->person)) : ?>
	
	<div class="containerx-box">
	<?php foreach($r -> persons as $pp) : ?>
	<div class="person">
		<a href="<?php echo base_url('square/astragram/profile/' . $r->user_id . ''); ?>"><img src="<?php echo base_url('uploaded/profile/'. $pp->avatar); ?>"/></a>
		<a style="color: #820E50; text-align: center; text-decoration: none;font-size: 1vw;font-weight: bold;" href="<?php echo base_url('square/astragram/profile/' . $r->user_id . ''); ?>"><span><?php echo $pp -> fname; ?> <?php echo $pp -> lname; ?></span></a>
	</div>
	<?php endforeach; ?>
	<?php //endif; ?>
			<div style=" width: 100%; float: left;padding: 3%; ">
		<p style=" font-size: 1.5vw; ">
		<?php 
		$verhashtext=$r -> details;
		$textarr=explode(" ",$verhashtext);
		$looper=count($textarr);
		$varwords=array();
		while($looper>0){
    		$looper--;
    		$word=$textarr[$looper];
    		
    		if($word[0]=="#"){
    		    $getit=0;
    		    $countaary=count($varwords);
        		while($countaary>0){
        		  $countaary--;
        		  if($varwords[$countaary]==$word){
        		      $getit=1;
        		      break;
        		  }
    		    }
        		if($getit==0){
            		$varwords[]=$word;
            		$str= ltrim($word,'#');
            		$varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
            		$verhashtext=str_replace($word,$varlinktext,$verhashtext);
        		}				
    		}		
		}
		 if($verhashtext) echo $verhashtext;
		foreach($r -> persons2 as $pp2) : 
		  //var_dump ($pp2);
		  if($pp2 -> id) echo " <span style='  font-size: 1.2vw; color: #8E8E8E; '> with </span>"; 
		  echo "&nbsp;<a style='color: #820E50; text-align: center; text-decoration: none;font-size: 1vw;font-weight: bold;' href='". base_url('square/astragram/profile/' . $pp2 -> id )."' > ".$pp2 -> fname ." ".$pp2 -> lname ."</a>";
		endforeach; 
		if($r -> where) echo "&nbsp;&nbsp;<span style='  font-size: 1.2vw; color: #8E8E8E; '>@ </span> ".$r -> where;
		
		 ?>
   </p>
  </div>
	    <div class="containerx-box-img">                
            <a data-toggle="modal" data-target="#myModallll<?php echo $r -> post_id;?>">
            	        <img src="<?php echo base_url('uploaded/astragram/' . $r->image . ''); ?>" style=" max-width: 95%; " />
            
            </a>
	    </div>
	    
	    <div class="col-xs-12 containerx-box-liks">
	        <div class="containerx-box-heart tcent nopad nomar">
    	        <a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like">
    	        <i class="glyphicon glyphicon-heart <?php
                    if ($r -> like_status)
                        echo 'glyphicon-red';
                    ?>" style="font-size:2vw;">
                </i></a>
            </div>
         <?php if (empty($r->likes)) : ?>
            <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
            </div>
         <?php endif; ?>
          <?php if (!empty($r->likes)) : ?>
		        <?php $x = 0; ?>
		       <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
	           <?php
                  foreach($r->likes as $l){
                    $ilikescount= $l->count;
                    break;
                  }
                    echo $ilikescount." :";
                    foreach($r->likes as $l) : ?>
				        <?php if (($x >= 1) || ($x >= 2)) : ?>
			        		and
			        	<?php endif; ?>
				        <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
			        	<?php ++$x; if($x==3)break;?>
			        <?php endforeach; ?>
		        </div>
				
           <?php if ($ilikescount>1) { ?>
            <div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">            	      
                <a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('astragram/likesload/'.$r -> post_id); ?>" >
                		<i>...</i>
                </a>
	        </div>
            <?php } ?>
	        <?php endif; ?>
	        
	    </div>
	    
	    <div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment">
	      	<ul class="timeline">
	      		<li>
	      		</li>
	      		<?php if (!empty($r->comments)) : ?>
	      		<?php foreach($r->comments as $c) : ?>
	    		<li id=li-<?php echo $c -> comment_id;?>>				
					<img src="<?php echo base_url('uploaded/profile/'. $c -> avatar); ?>">
					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c -> text; ?></span>
					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
					
					<span id="<?php echo $c -> comment_id; ?>" class="deletelink" style=" width: 8%; "><a class="ddeletelink" href="#Exit"><img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" style="width:60% !important" /></a></span>
					<?php } ?>
				</li>
				<?php endforeach; ?>
				<?php endif; ?>
	    	</ul>
	    </div>
	    <form class="frmcomment" action="">
	        <div class="col-xs-12 containerx-box-comment">
	            <textarea placeholder="<?php echo $commonMessages->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
	        </div>
	    </form>
	</div>

	<div class="modal fade" id="myModallll<?php echo $r -> post_id;?>" tabindex="-1"  style="display: none;"role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style=" border-bottom: 0; ">
        <button type="button" class="close" data-dismiss="modal" style="padding: 5px;"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      
      </div>
	  
	  
	  
	  
      <div class="modal-body">
      <div class="containerx-box">
	<?php foreach($r -> persons as $pp) : ?>
	<div class="person">
		<a href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><img src="<?php echo base_url('uploaded/profile/'. $pp -> avatar); ?>" style=" width: 35%; "/></a>

		<a style="color: #820E50; text-align: center; text-decoration: none;font-size: 1.5vw;font-weight: bold;" href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><span><?php echo $pp -> fname; ?> <?php echo $pp -> lname; ?></span></a>
	</div>
	<?php endforeach; ?>
	<?php //endif; ?>
			<div style=" width: 100%; float: left;padding: 3%; ">
		<p style=" font-size: 1.5vw; ">
		<?php 
		$verhashtext=$r -> details;
		$textarr=explode(" ",$verhashtext);
		$looper=count($textarr);
		$varwords=array();
		while($looper>0){
    		$looper--;
    		$word=$textarr[$looper];
    		
    		if($word[0]=="#"){
        		  $getit=0;
        		  $countaary=count($varwords);
        		while($countaary>0){
        		  $countaary--;
        		  if($varwords[$countaary]==$word){
        		      $getit=1;
        		      break;
        		  }
        		}
        		if($getit==0){
        		  $varwords[]=$word;
        		  $str= ltrim($word,'#');
        		  $varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
        		  $verhashtext=str_replace($word,$varlinktext,$verhashtext);
        		}		
    		}		
		}
		
	    if($verhashtext) echo $verhashtext." <span style='  font-size: 1.2vw; color: #8E8E8E; '> with </span>";
		foreach($r -> persons2 as $pp2) : 
		  //var_dump ($pp2);
		   echo "&nbsp;<a style='color: #820E50; text-align: center; text-decoration: none;font-size: 1vw;font-weight: bold;' href='". base_url('square/astragram/profile/' . $pp2 -> id )."' > ".$pp2 -> fname ." ".$pp2 -> lname ."</a>";
		endforeach; 
		  if($r -> where) echo "&nbsp;&nbsp;<span style='  font-size: 1.2vw; color: #8E8E8E; '>@ </span> ".$r -> where;		
		 ?>
   </p>
  </div>
	    <div class="containerx-box-img">
        <a data-toggle="modal" data-target="#myModallll<?php echo $r -> post_id;?>">
        	        <img src="<?php echo base_url('uploaded/astragram/' . $r -> image . ''); ?>" style=" max-width: 95%; " />
        
        </a>
	    </div>
	    
	    <div class="col-xs-12 containerx-box-liks">
	        <div class="containerx-box-heart tcent nopad nomar">
	        <a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like">
	        <i class="glyphicon glyphicon-heart <?php
                if ($r -> like_status)
                    echo 'glyphicon-red';
                ?>" style="font-size:2vw;">
                </i></a>
            </div>
     <?php if (empty($r->likes)) : ?>
     <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
     </div>
    <?php endif; ?>
          <?php if (!empty($r->likes)) : ?>
		        <?php $x = 0; ?>
		       <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
	
			        <?php
          foreach($r->likes as $l){
            $ilikescount= $l->count;
            break;
            }
           echo $ilikescount." :";

            foreach($r->likes as $l) : ?>
				<?php if (($x >= 1) || ($x >= 2)) : ?>
			      and
			     <?php endif; ?>
				    <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
			     <?php ++$x; if($x==3)break;?>
			     <?php endforeach; ?>
		        </div>
				
           <?php if ($ilikescount>1) { ?>
            <div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">
            	      
            <a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('astragram/likesload/'.$r -> post_id); ?>" >
            							<i>...</i>
						</a>
	        </div>
            <?php } ?>
	        <?php endif; ?>	        
	    </div>
	    
	    <div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment">
	      	<ul class="timeline">
	      		<li>
	      		</li>
	      		<?php if (!empty($r->comments)) : ?>
	      		<?php foreach($r->comments as $c) : ?>
	    		<li id=li-<?php echo $c -> comment_id;?>>				
					<img src="<?php echo base_url('uploaded/profile/'. $c -> avatar); ?>">
					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c -> text; ?></span>
					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
					
					<span id="<?php echo $c -> comment_id; ?>" class="deletelink" style=" width: 8%; "><a class="ddeletelink" href="#Exit"><img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" style="width: 30%" /></a></span>
					<?php } ?>
				</li>
				<?php endforeach; ?>
				<?php endif; ?>
	    	</ul>
	    </div>
	    <form class="frmcomment" action="">
	        <div class="col-xs-12 containerx-box-comment">
	            <textarea placeholder="<?php echo $commonMessages->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
	        </div>
	    </form>
	</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  
      </div>
    </div>
  </div>
</div>
<?php endforeach; } else { echo "<p style='margin-left: 5%; height: 500px;font-size: 3vw;margin-top: 30%;'>there is no posts</p>";} ?>



