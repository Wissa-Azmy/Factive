 <?php
$current = $this -> uri -> segment(1);
?>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css'); ?>" />
		<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/astragram.css'); ?>" />
		<title>Astragram</title>
		<!--style>@import url(http://fonts.googleapis.com/css?family=Cherry+Swash);</style-->
		<style>
			.modal-body .tooltip-inner {
            	height: auto;
            	
            }
		</style>
	   	  
	  	<div id="trends" class="trends">
		  <ul>
            <li class="trendstitle" style="color:#fff"><?php echo $this->lang->line('Trendslabel'); ?> </li>
                <?php  $idv=1; foreach($trends as $trehash) : ?>
                	<li >
                	<?php $strh= ltrim($trehash->hashtag,'#');?>
                    <a  href="<?php echo base_url('square/astragram/hashview/'.$strh);?>" id="n<? echo $idv ; ?>" >
                		<?php echo $trehash->hashtag;?>
                    </a>
                    </li>
               <?php $idv++; endforeach; ?>
			</ul>
		</div>
			
<div id="trends" class="trends" style="top: 20%;">
    <div style=" background-image: url(<?php echo base_url('assets/images/cal.png'); ?>); width: 20%;  float: left;text-align: center; background-repeat: no-repeat; background-size:contain; background-position:center; margin-top: 1%;" >
         <p style=" color: #FF0000; font-weight: bold; font-size: 2.0vw; margin-bottom: 0px;  padding: 13% 5% 5% 0%;" >
                <?php  $idv=1; foreach($comps as $trehash) : ?>
    							  <?php 
    							  $diff='';
    							   $start = date('Y-m-d',strtotime("now"));
                                   $end = date('Y-m-d',$trehash->end_date);                              
                                   if (strtotime($end) >= strtotime($start)) {
                                   		$diff = (strtotime($end)- strtotime($start))/24/3600;
    									echo number_format($diff, 0, '', '');
                                   }else{
                                       $diff = 0;
    									echo '0';
    							   }                                  
    							 $idv++;
    			 endforeach;?> 
    							 
    	   </p>
    </div>	
    <div style=" width: 80%; float: left; margin-left: 0px; ">    
    	<ul style=" /* margin-left: 3px; */ padding: 3px; ">
    		<li class="trendstitle" style="background-color: rgba(0, 0, 0, 0.46);font-size: 1.5vw;padding: 0px;color:#fff;text-align: center;"> Challenge of the Month 
    		<?php  $idv=1; foreach($comps as $trehash) : ?>
    		  <?php $strhd= ltrim($trehash->hashtag,'#');?>		
                    <a  href="<?php echo base_url('square/astragram/hashview/'.$strhd);?>" style=" color: #e05dc2 !important; "><?php echo $trehash->hashtag;?></a>
             <?php $idv++; endforeach; ?> 
            </li>  
        </ul>
	</div>
</div>

			
		<?php if ($diff==0){ ?>
		 
		<style type="text/css">
			.navigation{
				height:120px;
			}	
		.black_overlay{
			display: block;
			position: absolute;
			top: 0%;
			left: 0%;
			width: 100%;
			height: 100%;
			background-color: black;
			z-index:1001;
			-moz-opacity: 0.8;
			opacity:.80;
			filter: alpha(opacity=80);
		}
		.white_content {
			display: block;
            position: absolute;
            top: 10%;
            left: 28%;
            
            
            padding: 2%;
            background-color: white;
            z-index: 1002;
            overflow: hidden;
            background: url(<?php echo base_url('assets/images/winner.png'); ?>) no-repeat center;
            background-repeat: no-repeat;
            background-size: contain;
            background-position: center;
		}
		.aclos {
		background: rgba(195, 195, 195, 0.8);
        z-index: 1001;
        color: #000;
        position: absolute;
        
        left: 67%;
        font-size: 1.3vw;
        
        text-align: center;
        width: 5%;
        height: 5%;
        overflow: hidden;
        
        filter: alpha(opacity=0);
        -webkit-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
        -moz-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
        box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
        -webkit-transition: opacity 0.3s linear 1.2s;
        -moz-transition: opacity 0.3s linear 1.2s;
        -o-transition: opacity 0.3s linear 1.2s;
        -ms-transition: opacity 0.3s linear 1.2s;
        transition: opacity 0.3s linear 1.2s;
        top: 6%;
		}
	</style>
		
	
		<div style="width:100%;height:100%">
	    <div id="light" class="white_content"> <a class="aclos" href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">X</a>
		<p style=" margin: 0px;font-size: 2vw;padding: 5%;text-align: center; ">
    		 <?php  $idv=1; foreach($comprs as $trehashr) : ?>
            		<span style=" color: #820E50; font-size: 1vw;"><?php echo $trehash->hashtag;?> reward </span><br/>
            		<span style=" color: #820E50; font-size: 1vw; font-weight: bold;">AND THE WINNER IS</span><br/>
            		<?php foreach($trehashr -> persons as $appsd) : ?>
            		      <a href="<?php echo base_url('uploaded/profile/' . $appsd -> user_id . ''); ?>" style=" color: #820E50; font-size: 1.5vw; font-weight: bold; "><?php echo $appsd->fname;?> <?php echo $appsd->lname;?></a>
            	     <?php endforeach; ?>  
            		<br/>
            		 <img src="<?php echo base_url('uploaded/astragram/' . $trehashr -> image . ''); ?>" style=" max-width: 50%;padding-bottom: 15%;" />
        	  <?php 
    		  $idv++;
    		 endforeach; ?> 		
		</p>
		</div>
		<div id="fade" class="black_overlay"></div>
		</div>

	<?php 	} ?>
        
	
		<div class="containerx" id="containerdivcontainerx">
		  <br/>
		  <?php if (!empty($rows)) {  
		           foreach($rows as $r) :
		           
		           /*echo "<pre>";
		           print_r($r) ;
		           echo "</pre>";*/
		      ?>
	
 <?php //if (!empty($r->person)) : ?>
	
        	<div class="containerx-box">
        	<?php foreach($r->persons as $pp) : ?>
        	<div class="person">
        		<a href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><img src="<?php echo base_url('uploaded/profile/'. $pp -> avatar); ?>"/></a>
        
        		<a style="color: #820E50; text-align: center; text-decoration: none;font-size: 1vw;font-weight: bold;" href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><span><?php echo $pp -> fname; ?> <?php echo $pp -> lname; ?></span></a>
        	</div>
        	<?php endforeach; ?>
        	<?php //endif; ?>
        	<div style=" width: 100%; float: left;padding: 3%; ">
        		<p style=" font-size: 1.5vw; ">
        		<?php 
        		$verhashtext=$r->details;
        		$textarr=explode(" ",$verhashtext);
        		$looper=count($textarr);
        		$varwords=array();
        		while($looper>0){
        		    $looper--;
        		    $word=$textarr[$looper];        		
        		
            		if($word[0]=="#"){
                		$getit=0;
                		$countaary=count($varwords);
                		
                		//check if the hashtag has been detected before
                		while($countaary>0){
                		  $countaary--;
                    		if($varwords[$countaary]==$word){
                    		  $getit=1;
                    		  break;
                    		}	
                		}
                		
                		if($getit==0){
                		    //convert the hashtag world to link
                    		$varwords[]=$word;
                    		$str= ltrim($word,'#');
                    		$varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
                    		//replase the hashtag to links i main text
                    		$verhashtext=str_replace($word,$varlinktext,$verhashtext);
                		}	                		
            		}
        		
        		}
        		 if($verhashtext) echo $verhashtext;		
        		 if ($r->persons2) {		    
            		foreach($r->persons2 as $pp2) : 
            		  //var_dump ($pp2);
            		  if($pp2 -> id) echo " <span style='  font-size: 1.2vw; color: #8E8E8E; '> with </span>"; 
            		   echo "&nbsp;<a style='color: #820E50; text-align: center; text-decoration: none;font-size: 1vw;font-weight: bold;' href='". base_url('square/astragram/profile/' . $pp2 -> id )."' > ".$pp2 -> fname ." ".$pp2 -> lname ."</a>";
            		endforeach; 
        		 }
        		if($r -> where) echo "&nbsp;&nbsp;<span style='  font-size: 1.2vw; color: #8E8E8E; '>@ </span> ".$r -> where;
        		
        		 ?>
           </p>
          </div>
        <div class="containerx-box-img">
                       
            <a data-toggle="modal" data-target="#myModallll<?php echo $r->post_id;?>">
            	 <img src="<?php echo base_url('uploaded/astragram/' . $r->image . ''); ?>" style=" max-width: 95%; " />
            </a>
        </div>
        	    
        	    <div class="col-xs-12 containerx-box-liks">
        	        <div class="containerx-box-heart tcent nopad nomar">
        	        <a href="#" href="javascript: void(0)" id="<?php  echo $r->post_id; ?>" class="like">
            	        <i class="glyphicon glyphicon-heart <?php
                            if ($r->like_status)
                                echo 'glyphicon-red';
                         ?>" style="font-size:2vw;">
                         </i>
                     </a>
                </div>
             <?php if (empty($r->likes)) : ?>
             <div class="containerx-box-people" id="div<?php  echo $r->post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
             </div>
            <?php endif; ?>
                  <?php if (!empty($r->likes)) : ?>
        		        <?php $x = 0; ?>
        		       <div class="containerx-box-people" id="div<?php  echo $r->post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
        	
        		 <?php
                    foreach($r->likes as $l){
                        $ilikescount= $l->count;
                        break;
                    }
                    echo $ilikescount." :";
                            //echo 3 users like
                            foreach($r->likes as $l) : ?>
        				        <?php if (($x >= 1) || ($x >= 2)) : ?>
        			        		and
        			        	<?php endif; ?>
        				        <a href="<?php echo base_url('square/astragram/profile/' . $l->user_id . ''); ?>"><?php echo $l -> fname; ?></a>
        			        	<?php ++$x; if($x==3)break;?>
        
        			        <?php endforeach; ?>
        
        		        </div>
        				
                   <?php
                    //echo more link if there are more than one liked
                    if ($ilikescount>1) { ?>
                     <div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">        	      
                        <a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('astragram/likesload/'.$r -> post_id); ?>" ><i>...</i></a>
            	     </div>
                    <?php } ?>
        	        <?php endif; ?>        	        
        	    </div>
        	    
        	    <div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r -> post_id; ?>" data-type="rsltcomment">
        	      	<ul class="timeline">
        	      		<li>
        	      		</li>
        	      		<?php if (!empty($r->comments)) : ?>
        	      		<?php foreach($r->comments as $c) : ?>
        	    		<li id=li-<?php echo $c->comment_id;?>>				
        					<img src="<?php echo base_url('uploaded/profile/'. $c->avatar); ?>">
        					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c->text; ?></span>
        					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
        					
        					<span id="<?php echo $c->comment_id; ?>" class="deletelink" style=" width: 8%; "><a class="ddeletelink" href="#Exit">
        					   <img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" style="width:60% !important" /></a>
        					</span>
        					<?php } ?>
        				</li>
        				<?php endforeach; ?>
        				<?php endif; ?>
        	    	</ul>
        	    </div>
        	    <form class="frmcomment" action="">
        	        <div class="col-xs-12 containerx-box-comment">
        	            <textarea placeholder="<?php echo $this->lang->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
        	        </div>
        	    </form>
        	</div>
      
            <!-- 
            Post Model
             -->  
        
        <div class="modal fade" id="myModallll<?php echo $r->post_id;?>" tabindex="-1"  style="display: none;"role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header" style=" border-bottom: 0; ">
                <button type="button" class="close" data-dismiss="modal" style="padding: 5px;"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
               </div>
        	  <div class="modal-body">
              <div class="containerx-box">
        	<?php foreach($r->persons as $pp) : ?>
            	<div class="person">
            		<a href="<?php echo base_url('square/astragram/profile/' . $r->user_id . ''); ?>"><img src="<?php echo base_url('uploaded/profile/'. $pp -> avatar); ?>" style=" width: 35%; "/></a>            
            		<a style="color: #820E50; text-align: center; text-decoration: none;font-size: 1.5vw;font-weight: bold;" href="<?php echo base_url('square/astragram/profile/' . $r -> user_id . ''); ?>"><span><?php echo $pp -> fname; ?> <?php echo $pp -> lname; ?></span></a>
            	</div>
        	<?php endforeach; ?>
        	<?php //endif; ?>
        			<div style=" width: 100%; float: left;padding: 3%; ">
        		<p style=" font-size: 1.5vw; ">
        		<?php 
        		$verhashtext=$r->details;
        		$textarr=explode(" ",$verhashtext);
        		$looper=count($textarr);
        		$varwords=array();
        		while($looper>0){
            		$looper--;
            		$word=$textarr[$looper];
            		
            		if($word[0]=="#"){
                		$getit=0;
                		$countaary=count($varwords);
                		while($countaary>0){
                    		$countaary--;
                    		if($varwords[$countaary]==$word){
                        		$getit=1;
                        		break;
                    		}
                	
                		}
                		if($getit==0){
                    		$varwords[]=$word;
                    		$str= ltrim($word,'#');
                    		$varlinktext="<a  href=".base_url('square/astragram/hashview/'.$str).">".$word."</a>";
                    		$verhashtext=str_replace($word,$varlinktext,$verhashtext);
                		}
            		
            		}
        		
        		}
        		
        		if($verhashtext) echo $verhashtext." <span style='  font-size: 1.2vw; color: #8E8E8E; '> with </span>";
        		foreach($r -> persons2 as $pp2) : 
        		  //var_dump ($pp2);
        		  echo "&nbsp;<a style='color: #820E50; text-align: center; text-decoration: none;font-size: 1vw;font-weight: bold;' href='". base_url('square/astragram/profile/' . $pp2 -> id )."' > ".$pp2 -> fname ." ".$pp2 -> lname ."</a>";
        		endforeach; 
        		if($r -> where) echo "&nbsp;&nbsp;<span style='  font-size: 1.2vw; color: #8E8E8E; '>@ </span> ".$r -> where;
        		
        		 ?>
           </p>
          </div>
            <div class="containerx-box-img">
                <a data-toggle="modal" data-target="#myModallll<?php echo $r->post_id;?>">
                	        <img src="<?php echo base_url('uploaded/astragram/' . $r -> image . ''); ?>" style=" max-width: 95%; " />
                </a>
           </div>
        	    
        	    <div class="col-xs-12 containerx-box-liks">
        	        <div class="containerx-box-heart tcent nopad nomar"><a href="#" href="javascript: void(0)" id="<?php  echo $r -> post_id; ?>" class="like">
        	           <i class="glyphicon glyphicon-heart <?php
                        if ($r -> like_status)
                        echo 'glyphicon-red';
                         ?>" style="font-size:2vw;">
                       </i></a>
                     </div>
             <?php if (empty($r->likes)) : ?>
                 <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
                 </div>
             <?php endif; ?>
                  <?php if (!empty($r->likes)) : ?>
        		        <?php $x = 0; ?>
        		       <div class="containerx-box-people" id="div<?php  echo $r -> post_id; ?>" style="line-height: 3vw; font-size: 1vw;">
        			        <?php
                               foreach($r->likes as $l){
                                 $ilikescount= $l->count;
                                 break;
                                 }
                                 echo $ilikescount." :";
        
                                foreach($r->likes as $l) : ?>
        				        <?php if (($x >= 1) || ($x >= 2)) : ?>
        			        		and
        			        	<?php endif; ?>
        				        <a href="<?php echo base_url('square/astragram/profile/' . $l -> user_id . ''); ?>"><?php echo $l -> fname; ?></a>
        			        	<?php ++$x; if($x==3)break;?>        
        			        <?php endforeach; ?>
        
        		        </div>
        				
                   <?php if ($ilikescount>1) { ?>
                    <div class="containerx-box-more tcent nopad nomar" style="line-height: 22px;">                    	      
                        <a href="#" class="openmodelbtn" data-html="true" data-url="<?php echo base_url('astragram/likesload/'.$r->post_id); ?>" >
                    		<i>...</i>
                    	</a>
        	        </div>
                    <?php } ?>
        	        <?php endif; ?>        	        
        	    </div>
        	    
        	    <div class="col-xs-12 containerx-box-comments" data-id="<?php echo $r->post_id; ?>" data-type="rsltcomment">
        	      	<ul class="timeline">
        	      		<li>
        	      		</li>
        	      		<?php if (!empty($r->comments)) : ?>
        	      		<?php foreach($r->comments as $c) : ?>
        	    		<li id=li-<?php echo $c -> comment_id;?>>				
        					<img src="<?php echo base_url('uploaded/profile/'. $c -> avatar); ?>">
        					<span class="com_name"><a href="<?php echo base_url('square/astragram/profile/' . $c -> user_id . ''); ?>"><?php echo $c -> fname . " " . $c -> lname; ?></a></span> <span><?php echo $c -> text; ?></span>
        					<?php if($c -> user_id == $this -> session -> userdata('userid')) { ?>
        					
        					<span id="<?php echo $c -> comment_id; ?>" class="deletelink" style=" width: 8%; "><a class="ddeletelink" href="#Exit"><img class="dellink" src="<?php echo base_url('assets/images/delete.png');?>" style="width: 30%" /></a></span>
        					<?php } ?>
        				</li>
        				<?php endforeach; ?>
        				<?php endif; ?>
        	    	</ul>
        	    </div>
        	    <form class="frmcomment" action="">
        	        <div class="col-xs-12 containerx-box-comment">
        	            <textarea placeholder="<?php echo $this->lang->line('Writeacommentmsgg'); ?>" name="comment" class="astcomment" data-id="<?php echo $r -> post_id; ?>"></textarea>
        	        </div>
        	    </form>
        	</div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; 
		  } else { echo "<p style='margin-left: 5%; height: 500px;font-size: 3vw;margin-top: 30%;'>there is no posts</p>";} ?>		
		</div>
         
		<div id="wrapx">
                <img class="bgfade n1" src="<?php echo base_url('uploaded/astragram/bg/Together.jpg'); ?>">
				<img class="bgfade n2" src="<?php echo base_url('uploaded/astragram/bg/Best-smile.jpg'); ?>">
				<img class="bgfade n3" src="<?php echo base_url('uploaded/astragram/bg/Value-in-action.jpg'); ?>">
				<img class="bgfade n4" src="<?php echo base_url('uploaded/astragram/bg/one-team.jpg'); ?>">
				<img class="bgfade n5" src="<?php echo base_url('uploaded/astragram/bg/Odd-catch.jpg'); ?>">
		</div>
		
	<div id="contentlikes" class="modal" aria-hidden="true" style="display: none;">	
    <div class="modal-sdialog" >
         <div class="modal-content" id="contentdivlikes">
              <div class="modal-body" >
              </div>
         </div>
    </div>

<script type="text/javascript">
			$(window).load(function() {
				$('img.bgfade').hide();
				$('li.bgfade').hide();
				///li
				var dg_H = $(window).height();
				var dg_W = $(window).width();
				$('#wrapx').css({
					'height' : dg_H,
					'width' : dg_W
				});
				/*function anim() {
				 $("#wrapx img.bgfade").first().appendTo('#wrapx').fadeOut(1500);
				 $("#wrapx img").first().fadeIn(1500);
				 setTimeout(anim, 3000);
				 }*/
				function anim() {
					$("#wrapx img.bgfade").first().appendTo('#wrapx').fadeOut(1500);
					var order = $("#wrapx img").first().fadeIn(1500).attr('class').split(' ').pop();
					//$('#trends li').css("background", 'none');
					//$('#trends li.' + order).css("background-color", 'yellow');
					$('#trends li a').css("color", '#fff');
					
					$('#' + order).css("color", '#cdc442');

					setTimeout(anim, 3000);

				}

				anim();
			})
			$(window).resize(function() {
				//window.location.href = window.location.href
			});
			

			///////////////////////////////////////////////////////////////    
            var page_index = 0;
	        $(window).scroll(function() {
			if  ($(window).scrollTop() == $(document).height() - $(window).height()){
                	 console.log(page_index);
                	 $.ajax({
                	 	    type: "GET",
							url : "<?php echo base_url('astragram/'.$loadmore); ?>",
								dataType: "html",
								data : {
								index : ++page_index,

							},success: function(response) {
								$("#containerdivcontainerx").append(response);
							}
						});

				}
			});
	        /*
	        get all like "likesload"
	        */
            $(".openmodelbtn").live("click", function() {            
			$.ajax({
				url : $(this).attr("data-url"),
			}).done(function(response) {
                $('#contentdivlikes').html(response);
				$('#contentlikes').modal('show');

			});

			
		});

		//$(function () { 
         // $("[data-toggle='tooltip']").tooltip(); 
        //});
	
				/*$(".openmodel").live("click", function() {
				$.ajax({
					url : $(this).attr("data-url"),
				}).done(function(response) {
					$('.modal-body').html(response);
					$('#astmodel').modal('show');

				})
				//$('#astmodel').modal('show'); // tODO:delete it
			});*/

			////////////////////////////////////////////////////////////////
			$('.like').live("click", function(e) {
			  
               if($(this).children().hasClass('glyphicon-red')) {
               	  $(this).children().removeClass('glyphicon-red');
               	  $.ajax({
					    url : "<?php echo base_url('square/astragram/dislike'); ?>",
						dataType: "html",
						data : {
						postId : $(this).attr("id"),
						},success: function(response) {
                               var res = response.split("###");
                               divid="#div"+res[0];
                               $(divid).html(res[1]);
						}
				});
			 }else{
						$(this).children().addClass('glyphicon-red');
						$.ajax({
						url : "<?php echo base_url('square/astragram/like'); ?>",
						dataType: "html",
						data : {
						postId : $(this).attr("id"),
						},success: function(response) {
                                                var res = response.split("###");
                                                divid="#div"+res[0];
						$(divid).html(res[1]);



						}

						});
						}
						e.preventDefault();
			});

						///////////////////////////////////////////////////////////////

				jQuery(".astcomment").live("keydown", function(e) {
						if(e.which==13) {
						picid = $(this).attr("data-id");

						//TODO REMOVED IT JUST TEST
						/*
						rslt = "<li>";
						rslt += "<img src=\"<?php echo base_url('uploaded/astragram/imgbox.jpg');?>\" />";
						rslt += "<span  class=\"com_name\">Mahmoud Soliman</span>";
						rslt += "<span>" + $(this).val() + "</span>";
						rslt += "</li>";
						*/
						//$("'div[data-id=" + picid + "][data-type='rsltcomment'] ul").append(rslt);

						$.ajax({
							//url : "CONTROLER",
							url : "<?php echo base_url('square/astragram/comments'); ?>",
							dataType: "json",
							data : {
							comment : $(this).val(),
							postId : picid
						},success: function(response) {
						//response = jQuery.parseJSON( response );
						
			                //rslt = rslt = "<li id=li-"+picid+" data-id='"+response.last_id+"'>";
							rslt = rslt = "<li class='li-"+response.last_id+"'>";
							rslt += "<img src=\"<?php echo base_url('assets/images/profile');?>/" + response.image + "\" />";
							rslt += "<span  class=\"com_name\">" + response.name + "</span>";
							rslt += "<span>" + response.comment + "</span>";
							rslt += "<span id="+response.last_id+" class=\"deletelink\" ><a val="+response.last_id+" class=\"ddeletelink\" ><img class=\"dellink\"  src=\"<?php echo base_url('assets/images/delete.png');?>"+ "\" /></a>"  + "</span>";
							//rslt += "<span class=\"deletelink\" val="+picid+"><a href=\""+ "\"><img src=\"<?php echo base_url('assets/images/delete.png');?>"+ "\" /></a>"  + "</span>";
							rslt += "</li>";
			
							$("'div[data-id=" + picid + "][data-type='rsltcomment'] ul").append(rslt);
							$(".astcomment").val("");
							}
		
						});
		
						e.preventDefault();
						}
				});
		
			$(document).ready(function() {
				$(".deletelink").live("click", function(){
					var id = $(this).attr("id");
					$.ajax({
						type : "post",
						url : "<?php echo base_url('square/astragram/delcomment'); ?>",
							data : "id=" + id,
							success : function(msg, string, jqXHR) {
										$(".li-" + id).hide("slow", function() {
											//console.log('id[li-' + id + ']');
											//$('id[li-' + id + ']').hide("slow", function() {
										$(this).remove();
									});
								}
							});
						});
                        $('.close').on('click', function () {
						// location.reload();
						});
					});
		
		$(".openmodel").live("click", function() {
			$.ajax({
				url : $(this).attr("data-url"),
			}).done(function(response) {
				$('#contentuploaddiv').html(response);
				$('#contentupload').modal('show');

			})
			//$('#astmodel').modal('show'); // tODO:delete it
		});
	
	function clean() {
		$('#search_result').delay(500).fadeOut('slow');
	}
			function autocomplet() {
			var keyword = $('#swSearch').val();
			if(keyword != '' ) {				$.ajax({
					url : '<?php echo base_url('square/astragram/search'); ?>
						',
						//dataType : 'json',
						type : 'POST',
						data : {
						req : keyword,
						},
							success : function(data) {
							   $('#search_result').show().html(data);
							   }
							 });
							}
						}

						
	</script>

             <!-----------------------Error Messages------------------------------------------------------>
		<?php //if( isset($showMessage) && ($showMessage==true) ) { ?>
		
			<div class="alert <?php
    			if ($type == 'Error') { 
    			    echo 'alert-danger';
    			} else { 
    			    echo 'alert-success';
    			}
            ?>" style="text-align: center; font-size: 13px; margin: 20px 90px">
				<b>
    				<?php
    				if ($type == 'Error') { 
    				    echo $this->lang -> line('ErrorOccurred');
    					'Error Occurred ...';
    				} else { 
    				    echo 'Action Done Successfully ...';
    				}
                    ?>
                </b>
				<br />
				<?php echo $messageToBeShow; ?>
			</div>
		</div>
		<?php //} ?>		
	
		<?php if(validation_errors()) { ?>
		<div class="alert alert-danger" style="display:;">
			<button type="button" class="close" data-dismiss="alert">
				<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
			</button>
			<b><?php echo $this->lang -> line('ErrorOccurred'); ?></b>
			<?php
			if (validation_errors())
				echo "<ul>";
			echo validation_errors('<li>', '</li>');
			echo "</ul>";
			?>
		</div>
		<?php } ?>

