			<!-- Main content -->
              <div class="col-md-3">
			
            <div class="span6">
                    <div class="container-big">
                      <img alt="" src="<?php echo base_url();?>assets/img/scroll/s1big.jpg">
                      <article class="text-big">
                        <div class="infotexthv district">
                          <h3><a href="#" title=""> The District</a> </h3>
                          <p><a href="#" title="">Business Communication</a></p>
                        </div>
                      </article>
                    </div>
                  </div>
                  
                  
              </div>
                
                
                 <div class="col-md-3">
			 <div class="span6">
                    <div class="container-big">
                      <img alt="" src="<?php echo base_url();?>assets/img/scroll/s1big.jpg">
                      <article class="text-big">
                        <div class="infotexthv beacon">
                          <h3><a href="#" title="">   The Beacon</a> </h3>
                          <p><a href="#" title="">Learning and Development</a></p>
                        </div>
                      </article>
                    </div>
                  </div>
                  
                  
              </div>
                
                
                 <div class="col-md-3">
			 <div class="span6">
                    <div class="container-big">
                      <img alt="" src="<?php echo base_url();?>assets/img/scroll/s1big.jpg">
                      <article class="text-big">
                        <div class="infotexthv square">
                          <h3><a href="#" title="">  The Square</a> </h3>
                          <p><a href="#" title="">Social Communication</a></p>
                        </div>
                      </article>
                    </div>
                  </div>
                  
                  
                  
              </div>
                
                
                 <div class="col-md-3">
			 <div class="span6">
                    <div class="container-big">
                      <img alt="" src="<?php echo base_url();?>assets/img/scroll/s1big.jpg">
                      <article class="text-big">
                        <div class="infotexthv astragram">
                          <h3><a href="#" title="">  Astragram</a> </h3>
                           <p><a href="#" title="">Social Communication</a></p>
                        </div>
                      </article>
                    </div>
                  </div>
                
                  
                  
              </div>