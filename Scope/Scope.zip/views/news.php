
  <?php foreach($news as $x=> $new){ ?>
 
           <div class="col-md-6">
			 <!-- Contact -->
                <div class="contact">
                 
                  <div class="contact-bor">             
                   
                    <div class="add-contact">
                      <div class="row">
                        <div class="col-md-6">
                             <h2> <?php echo $new->title;?></h2>
                          <h6><?php echo date('m/d/Y',strtotime($new->newdate));?></h6>
                          <div class="infotext">
                    <a href="<?=base_url()?>home/newdetail/<?=$new->id?>">
                    <?php $newDescription = strip_tags($new->desc);
                                if (strlen($newDescription) > 180) {
                                    $newDescription = substr($newDescription,0,strpos($newDescription,' ',180));
                                    $newDescription = $newDescription . ' ...';
                                }                                
						          echo $newDescription;?>
                    </a>
                    </div>
                        </div>
                        <div class="col-md-6 pull-right">
                          <br/>
                          <?php if ($new->img_url){?>
                            <div class="our-img"><img class="img-responsive" alt="" src="<?php echo base_url().$new->img_url;?>"></div>
                            <?php }?>
                        </div>
                      </div>
                    </div>
                  </div>
   
                </div>
				<!-- End contact -->
              </div>
    <?php }?>
               