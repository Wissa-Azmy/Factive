<ol class="breadcrumb bc-3">
    <li>
        <a href="<?php echo base_url();?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?php echo base_url();?>admin/news">News</a>
    </li>
    <li class="active">
        <strong>Edit new</strong>
    </li>
</ol>


<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-body form-horizontal form-groups-bordered">
            
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Title</label>
                        <div class="col-sm-9">
                            <input type="text" name="title" value="<?php echo $news->title;?>" required required="" class="form-control" />
                        </div>
                    </div>                   
              
                        
                  <div class="form-group">
                        <label class="col-sm-3 control-label">New Date</label>
                        <div class="col-sm-9">
                          <input type="text" name="newdate" class="form-control" value="<?php if ($news->newdate != '0000-00-00 00:00:00'){echo date('m/d/Y',strtotime($news->newdate));}?>">
                        </div>                       
                    </div>          
                     
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-body form-horizontal form-groups-bordered">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Main Image</label>
                        <div class="col-sm-5">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                    <img src="<?php echo base_url().$news->img_url;?>" alt="">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                <div>
                                    <span class="btn btn-white btn-file">
                                        <span class="fileinput-new">Select Image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img_url" accept="image/*" >
                                    </span>
                                    <a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Delete</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">WaterMark</label>
                        <div class="col-sm-9">
                            <div class="make-switch" data-on-label="<i class='entypo-check'></i>" data-off-label="<i class='entypo-cancel'></i>">
                                <input type="checkbox" <?php echo $data['poster_watermark'];?> value="1" name="poster_watermark" />
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
       
       <div class="row">
        <label class="col-sm-12 control-label" style="text-align: left;">Description</label>
        <div class="col-lg-12">
            <textarea class="form-control ckeditor" id="ckeditor" name="desc" required><?php echo $news->desc;?></textarea>
        </div>
    </div>
     <div class="clearfix"></div>
    
  
          <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-body form-horizontal form-groups-bordered">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">WaterMark</label>
                        <div class="col-sm-9">
                            <div class="make-switch" data-on-label="<i class='entypo-check'></i>" data-off-label="<i class='entypo-cancel'></i>">
                                <input type="checkbox" <?php echo $data['images_watermark'];?> value="1" name="images_watermark" />
                            </div>
                        </div>
                    </div>
                     <div id="result-dele" class=" gallery-env" >
                        <?php $images= json_decode($news->images);if(!empty($images)){  
                        	
                        	foreach($images as $x => $image){
                        		
                        		//echo "array".$image['image'];
                        	if ((is_array($image)) OR (is_object($image))) {
                        		//echo "yes";
                        		$imagesource=$image->image;
                        		$comment=$image->comment;
                        	}else{
                        		$imagesource=$image;
                        		$comment='';
                        	}
                        	?>
                        <div class="col-sm-4 col-xs-4" data-tag="<?=$x?>d">
                            <article class="image-thumb">
                                    <a class="image">
                                        <img src="<?=  base_url().$imagesource?>">
                                        <input type="text" class="form-control" id="oldcomment[<?=$x?>]" name="oldcomment[<?=$x?>]" value="<?=$comment?>" style="width: 190px;">
                                        
                                    </a>
                                    <div class="image-options">
                                        <a href="" id="del-sel" class="delete" data-id="<?=$x?>"><i class="entypo-cancel"></i></a>
                                    </div>
                            </article>
                        </div>
                        <?php }} ?>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Add images</label>
                        <div class="col-sm-10" style="margin-bottom: 15px;">
                            <input id="files" name="images[]" type="file" class="form-control file2 inline btn btn-primary" multiple="1" data-label="<i class='glyphicon glyphicon-circle-arrow-up'></i> &nbsp;Add images" />
                        </div>
                        <div id="result" class=""></div>
                    </div>                  
                    
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix mar-top-clear"></div>
    <div class="form-group default-padding">
            <button type="submit" class="btn btn-success">Edit</button>
            <button type="reset" class="btn">Cancel</button>
    </div>
</form>




    
<script>
$('.gallery-env').on('click', 'a[href]', function() {

    var info = 'id='+$(this).attr('data-id')+'&news=<?=$news->id?>'; 
    $.ajax({
        type: "POST",
        url: "<?=  base_url()?>admin/news/edit_img/?"+info,
        data: info,
        cache: false,
        async: true,
        beforeSend : function(){
                $("#result-dele").html('');              
        },
        success: function(data_success){
            if(data_success == ""){

            }else{
                setTimeout(function() {
                    $("#result-dele").html(data_success);
                }, 1000);
            }
        }
    });
    return false; 
 });
 window.onload = function(){
    if(window.File && window.FileList && window.FileReader)
    {
        var filesInput = document.getElementById("files");
        
        filesInput.addEventListener("change", function(event){
            
            var files = event.target.files; //FileList object
            var output = document.getElementById("result");
            output.innerHTML = '';
            for(var i = 0; i< files.length; i++)
            {
            	
                var file = files[i];
                //var ids['']=i;
                //alert (i);
                //Only pics
                // if(!file.type.match('image'))
                if(file.type.match('image.*')){
                	//alert (i);
                    if(this.files[0].size < 2097152){    
                    	//alert (i);
                    	
                  // continue;
                    var picReader = new FileReader();
                    picReader.fileName = file.name ;
                    picReader.addEventListener("load",function(event){
                    	//alert (i);
                        var picFile = event.target;
                        var div = document.createElement("div");
                        div.style.float = "right";
                        //alert (i);
                        //var j=0;
                        var fullfilename=picFile.fileName;
                       // file_name=fullfilename.substr(0, fullfilename.lastIndexOf('.'));
                        parts = fullfilename.split(".");
                        file_name = parts[0];
                        div.innerHTML = '<img class="thumbnail thumbtoup" src="' + picFile.result + '"' +
                                'title="preview image"/><input type="text" class="form-control" id="'+file_name+'" name="'+file_name+'" placeholder="Image comment" style="width: 190px;margin-right: 15px;">';
                        // j++;
                                output.insertBefore(div,null);            
                    });
                    //Read the image
                    $('#clear, #result').show();
                    picReader.readAsDataURL(file);
                    }else{
                        alert("Image Size is too big. Minimum size is 2MB.");
                        $(this).val("");
                    }
                }else{
                alert("You can only upload image file.");
                $(this).val("");
                }
            }                               
           
        });
    }
    else
    {
        console.log("Your browser does not support File API");
    }
}

 
    
$( "#files" ).click(function() {
    $('.thumbnail').parent().remove();
    $('result').hide();
    $(this).val("");
}); 
 
        

    

	jQuery(document).ready(function($) {		

		CKEDITOR.replace( 'ckeditor', {
            language: 'en'
        });
        
		CKEDITOR.on('instanceReady', function(e) {
		    $('.cke_floatingtools').hide();
		});

		 $('input[name="newdate"]').daterangepicker({
			 defaultDate: new Date(),
		        singleDatePicker: true,
		        showDropdowns: true
		    }); 
		    
		});
	
		 
    </script>
<style>
    .auothor-input-a{
        margin-top: 13px;
    }
.mar-top-clear{
    margin-top: 20px;
}
.thumbtoup{
  margin-right: 15px;
  max-height: 150px;
}


.field_wrapper div{ margin-bottom:5px;}
.add_button img{ margin-top:7px;}
.remove_button img { margin-top:7px;}
</style>
  
  