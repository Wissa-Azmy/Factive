
<form role="form" method="get" class="form-horizontal form-groups-bordered" action="<?php echo base_url();?>admin/calendars/index">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        Search
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                        <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="form-group col-lg-3">
                        <label for="field-1" class="col-sm-2 control-label">ID</label>
                        <div class="col-sm-6">
                            <input type="number" name="sel_id" value="<?=$sel_id?>" class="form-control" />
                        </div>
                    </div>                    
                    <div class="form-group col-lg-6">
                        <label for="field-1" class="col-sm-2 control-label">Keywords</label>
                        <div class="col-sm-10">
                            <input type="text" value="<?=$keyword?>" name="keywords" class="form-control" />
                        </div>
                    </div>
                    
                    <div class="form-group col-lg-3">
                        
                            <label for="field-1" class="col-sm-2 control-label">Limit</label>
                            <div class="col-sm-6" >
                                <input type="number" name="limit" value="<?=$limit?>" class="form-control" />
                            </div>
                
                    </div>                    <div class="form-group col-lg-6">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-success col-lg-12">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered responsive">
            <thead>
                <tr>
                    <th>ID</th>
                    <th width="40%">Title</th>
                    <th>Creation Date</th>
                    <th>Last Update</th>
                    <th> </th>                    
                </tr>
            </thead>
            <tbody>
                <?php foreach($calendars as $x=> $calendar){ ?>
                    <tr>
                        <td><?=$calendar->id?></td>
                        <td>
                            <?=$calendar->title?>                        </td>                        <td><?php echo $calendar->creation_date;?></td>                        <td><?php if($calendar->modified_date != '0000-00-00 00:00:00'){echo $calendar->modified_date;}else{echo 'No Updates';}?> </td>                        <td>                                       <?php                            if($this->Scope->check_view_actions('2','calendars', 'edit','') == 1){?>                                <a href="<?=base_url()?>admin/calendars/edit/<?=$calendar->id?>" class="btn btn-default btn-sm btn-icon icon-left">                                    <i class="entypo-pencil"></i>                                    Edit                                </a>                            <?php }?>                              <?php if($this->Scope->check_view_actions('2','calendars', 'delete','') == 1){?>                                <a type="button"onclick="return confirm(del_massage);" href="<?=  base_url().'admin/calendars/delete/'.$calendar->id?>" class="btn btn-red btn-icon">                                    <i class="entypo-cancel"></i>                                    Delete                                </a>                            <?php }?>                        </td>                    </tr>                <?php } ?>
            </tbody>
        </table>
    </div>
</div><div class="pagination">					<?php echo $this->pagination->create_links(); ?>				</div>
