<ol class="breadcrumb bc-3">
    <li>
        <a href="<?php echo base_url();?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?php echo base_url();?>admin/calendars">Events</a>
    </li>
    <li class="active">
        <strong>Add event</strong>
    </li>
</ol>


<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-body form-horizontal form-groups-bordered">
            
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Title</label>
                        <div class="col-sm-9">
                            <input type="text" name="title" value="" required required="" class="form-control" />
                        </div>
                    </div>
                   
                         <div class="form-group">
                        <label class="col-sm-3 control-label">Event Date</label>
                        <div class="col-sm-9">
                          <input type="text" name="calendardate" class="form-control">
                        </div>                       
                    </div>          
                     
                </div>
            </div>
        </div>
  
    </div>
   
     <div class="clearfix"></div>
     
   

    <div class="clearfix mar-top-clear"></div>
    <div class="form-group default-padding">
            <button type="submit" class="btn btn-success">Add</button>
            <button type="reset" class="btn">Cancel</button>
    </div>
</form>




    
<script>

   

	jQuery(document).ready(function($) {		
	
	    $('input[name="calendardate"]').daterangepicker({	       
	    	timePicker: true,
	        timePickerIncrement: 30,
	        locale: {
	            format: 'YYYY-MM-DD[T]HH:MM:SS'
	        }
         
	    }); 
		});
	
		 
    </script>
<style>
    .auothor-input-a{
        margin-top: 13px;
    }
.mar-top-clear{
    margin-top: 20px;
}
.thumbtoup{
  margin-right: 15px;
  max-height: 150px;
}


.field_wrapper div{ margin-bottom:5px;}
.add_button img{ margin-top:7px;}
.remove_button img { margin-top:7px;}
</style>
  
  