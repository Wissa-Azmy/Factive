<ol class="breadcrumb bc-3">
    <li>
        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?=  base_url()?>admin/activities">Activities</a>
    </li>
    <li class="active">
        <strong>Add Activity</strong>
    </li>
</ol>
<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                       Activity info
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">                 <?php foreach($language as $lang){ ?>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Name (<?php echo $lang->symbol;?>)</label>
                        <div class="col-sm-10">
                            <input type="text" name="name-<?php echo $lang->id;?>" value="" required required="" class="form-control" />
                        </div>
                    </div>                    <?php }?>                                           <div class="form-group">                        <label class="col-sm-2 control-label">Destination</label>                        <div class="col-sm-10">                         <select name="dest_id" id= "dest_id" class="form-control select2-select" required="" aria-required="true" aria-describedby="-error" aria-invalid="true">							<option value=""></option>                                <?php                                 foreach($destinations as $destination){                                         echo ' <option value="'.$destination->id.'">'.$destination->dest_name.'</option>';                                }?>                            </select>                                                   </div>                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="col-lg-12">
        <button type="submit" class="btn btn-success">Add </button>        
    </div>
</form>