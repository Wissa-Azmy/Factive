<?php 
$data_uls = array(
	
		array(
				'main'=>array(
						'name'=>'Admin Users',
						'icon'=>'entypo-user'
				),
				'subs'=>array(
						array(
								'name'=>'View',
								'link'=>base_url().'admin/admins',
				                'icon'=>'',
				                'table'=>'admins',
				                'action'=>'view',
						),
						array(
								'name'=>'Add',
								'link'=>base_url().'admin/admins/add',
				                'icon'=>'',
				                'table'=>'admins',
				                'action'=>'add',
						),
				)
		),
		array(
				'main'=>array(
						'name'=>'Registered users',
						'icon'=>'entypo-user'
				),
				'subs'=>array(
						array(
								'name'=>'View',
								'link'=>base_url().'admin/users',
				                'icon'=>'',
				                'table'=>'users',
				                'action'=>'view',
						),
						array(
								'name'=>'Deactived Users',
								'link'=>base_url().'admin/users/deactivedusers',
				                'icon'=>'',
				                'table'=>'users',
				                'action'=>'edit',
						),
				    array(
				        'name'=>'Report',
				        'link'=>base_url().'admin/users/userreportform',
				        'icon'=>'',
				        'table'=>'users',
				        'action'=>'edit',
				    ),
				)
		),
		
		array(
				'main'=>array(
						'name'=>'Menus',
						'icon'=>'entypo-air'
				),
				'subs'=>array(
						array(
								'name'=>'View',
								'link'=>base_url().'admin/menus',
								'icon'=>'',
								'table'=>'menus',
								'action'=>'view',
						),
						array(
								'name'=>'Add',
								'link'=>base_url().'admin/menus/add',
								'icon'=>'',
								'table'=>'menus',
								'action'=>'add',
						),
				)
		),
		array(
				'main'=>array(
						'name'=>'PDF Files',
						'icon'=>'entypo-docs'
				),
				'subs'=>array(
						array(
								'name'=>'View',
								'link'=>base_url().'admin/files',
								'icon'=>'',
								'table'=>'files',
								'action'=>'view',
						),
						array(
								'name'=>'Add',
								'link'=>base_url().'admin/files/add',
								'icon'=>'',
								'table'=>'files',
								'action'=>'add',
						),
				)
		),
    array(
        'main'=>array(
            'name'=>'Videos Files',
            'icon'=>'entypo-video'
        ),
        'subs'=>array(
            array(
                'name'=>'View',
                'link'=>base_url().'admin/videos',
                'icon'=>'',
                'table'=>'files',
                'action'=>'view',
            ),
            array(
                'name'=>'Add',
                'link'=>base_url().'admin/videos/add',
                'icon'=>'',
                'table'=>'files',
                'action'=>'add',
            ),
        )
    ),
    array(
        'main'=>array(
            'name'=>'Albums',
            'icon'=>'entypo-picture'
        ),
        'subs'=>array(
            array(
                'name'=>'View',
                'link'=>base_url().'admin/albums',
                'icon'=>'',
                'table'=>'files',
                'action'=>'view',
            ),
            array(
                'name'=>'Add',
                'link'=>base_url().'admin/albums/add',
                'icon'=>'',
                'table'=>'files',
                'action'=>'add',
            ),
        )
    ),
    array(
        'main'=>array(
            'name'=>'DOC Files',
            'icon'=>'entypo-docs'
        ),
        'subs'=>array(
            array(
                'name'=>'View',
                'link'=>base_url().'admin/docs',
                'icon'=>'',
                'table'=>'files',
                'action'=>'view',
            ),
            array(
                'name'=>'Add',
                'link'=>base_url().'admin/docs/add',
                'icon'=>'',
                'table'=>'files',
                'action'=>'add',
            ),
        )
    ),
    
    array(
        'main'=>array(
            'name'=>'News',
            'icon'=>'entypo-docs'
        ),
        'subs'=>array(
            array(
                'name'=>'View',
                'link'=>base_url().'admin/news',
                'icon'=>'',
                'table'=>'news',
                'action'=>'view',
            ),
            array(
                'name'=>'Add',
                'link'=>base_url().'admin/news/add',
                'icon'=>'',
                'table'=>'news',
                'action'=>'add',
            ),
        )
    ),
   
    array(
        'main'=>array(
            'name'=>'Calendar',
            'icon'=>'entypo-docs'
        ),
        'subs'=>array(
            array(
                'name'=>'View events',
                'link'=>base_url().'admin/calendars',
                'icon'=>'',
                'table'=>'calendars',
                'action'=>'view',
            ),
            array(
                'name'=>'Add event',
                'link'=>base_url().'admin/calendars/add',
                'icon'=>'',
                'table'=>'calendars',
                'action'=>'add',
            ),
        )
    ),
    array(
        'main'=>array(
            'name'=>'Help desk',
            'icon'=>'entypo-docs'
        ),
        'subs'=>array(
            array(
                'name'=>'Questions',
                'link'=>base_url().'admin/helpdesks',
                'icon'=>'',
                'table'=>'helpdesks',
                'action'=>'view',
            ),
            array(
                'name'=>'Add question',
                'link'=>base_url().'admin/helpdesks/add',
                'icon'=>'',
                'table'=>'helpdesks',
                'action'=>'add',
            ),
        )
    ),
     
    
		)
    
    ?>








    <li>
        <a href="<?=base_url()?>admin">
                <i class="entypo-gauge"></i>
                <span class="title">Home</span>
        </a>
    </li>
    
    
    
<?php   
foreach($data_uls as $x => $sec){
	$main =  '<li data-id="m'.$x.'" class="" >';//opened
	$main .=  '<a href="#">
                <i class="'.$sec['main']['icon'].'"></i>
                <span class="title">'.$sec['main']['name'].'</span>
        </a>';
	$sub_li = '';
	foreach($sec['subs'] as $x2 => $sub){
		$daa = $this->Scope->check_view_actions_na('2',$sub['table'], $sub['action'],'');
		if($daa == 1){
			$hh = 'id2=s'.$x.$x2.'&id1=m'.$x.'';
			if (strpos($hh, "?") !== FALSE) {$hh = '&'.$hh;}else{$hh = '?'.$hh;}
			$sub_li .= '<li data-id="s'.$x.$x2.'" >
                                <a href="'.$sub['link'].$hh.'">
                                <i class="i i-dot"></i>

                                <span class="title">'.$sub['name'].'</span>
                              </a>
                            </li>';
		}
	}
	if(!empty($sub_li)){
		$main .= '<ul class="nav dk">'.$sub_li.'</ul>';
		echo $main.'</li>';
	}


}
if(isset($_GET['id1'])){
	$id1 = $_GET['id1'];
}else{
	$id1 = '';
}
if(isset($_GET['id2'])){
	$id2 = $_GET['id2'];
}else{
	$id2 = '';
}
?>
<script>
    $(document).ready(function(){
        $('li[data-id=<?=$id1?>]').addClass("opened active");
        $('li[data-id=<?=$id2?>]').addClass("active");
    })
</script>
