<ol class="breadcrumb bc-3">
    <li>
        <a href="<?php echo base_url();?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?php echo base_url();?>admin/helpdesks">Questions</a>
    </li>
    <li class="active">
        <strong>Edit question</strong>
    </li>
</ol>


<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-body form-horizontal form-groups-bordered">
            
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Question</label>
                        <div class="col-sm-10">
                            <input type="text" name="question" value="<?php echo $helpdesks->question;?>" required required="" class="form-control" />
                        </div>
                    </div>                   
              
                        
                  <div class="form-group">
                         <label class="col-sm-2 control-label"">Description</label>
                        <div class="col-lg-10">
                            <textarea class="form-control"  name="answer" required><?php echo $helpdesks->answer;?></textarea>
                        </div>                     
                    </div>          
                     
                </div>
            </div>
        </div>

    </div>
       
  
     <div class="clearfix"></div>
    
    <div class="clearfix mar-top-clear"></div>
    <div class="form-group default-padding">
            <button type="submit" class="btn btn-success">Edit</button>
            <button type="reset" class="btn">Cancel</button>
    </div>
</form>

<style>
    .auothor-input-a{
        margin-top: 13px;
    }
.mar-top-clear{
    margin-top: 20px;
}
.thumbtoup{
  margin-right: 15px;
  max-height: 150px;
}


.field_wrapper div{ margin-bottom:5px;}
.add_button img{ margin-top:7px;}
.remove_button img { margin-top:7px;}
</style>
  
  