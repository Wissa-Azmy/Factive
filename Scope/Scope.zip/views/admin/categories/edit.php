<ol class="breadcrumb bc-3">
    <li>
        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?=  base_url()?>admin/categories">Categories</a>
    </li>
    <li class="active">
        <strong>Update Category</strong>
    </li>
</ol>
<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                       Category info
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">                                               <?php foreach($language as $lang){ ?>                    <div class="form-group">                        <label class="col-sm-2 control-label">Name (<?php echo $lang->symbol;?>)</label>                        <div class="col-sm-10">                            <input type="text" name="name-<?php echo $lang->id;?>" value="<?php echo $categorydetails[$lang->id][0]->cat_name;?>" required required="" class="form-control" />                        </div>                    </div>                    <?php }?>       
                  <div class="form-group">                        <label class="col-sm-2 control-label">Parent Category</label>                        <div class="col-sm-10">                         <select name="parent_id" class="form-control select2">							<option value=""></option>                                <?php                                 foreach($categories as $categoryp){ 									if ($categoryp->id==$category->parent_id) {										$selected="selected='selected'";										}else{										$selected='';									}                                        echo ' <option value="'.$categoryp->id.'" '.$selected.'>'.$categoryp->cat_name.'</option>';                                }?>                            </select>                                                   </div>                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="col-lg-12">
        <button type="submit" class="btn btn-success">Edit </button>        
    </div>
</form>