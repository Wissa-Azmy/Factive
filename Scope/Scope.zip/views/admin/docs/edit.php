<ol class="breadcrumb bc-3">
    <li>        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>    </li>    <li>        <a href="<?=  base_url()?>admin/files">Doc</a>    </li>    <li class="active">        <strong>Edit Doc</strong>    </li></ol>
<h1><?=$file->title?></h1>
<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">    <div class="row">        <div class="col-lg-12">          <div class="panel panel-primary" data-collapsed="0">                <div class="panel-heading">                    <div class="panel-title">                       Menu info                    </div>                    <div class="panel-options">                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>                    </div>                </div>                <div class="panel-body">                                                         <div class="form-group">                        <label class="col-sm-2 control-label">Menu</label>                        <div class="col-sm-10" >                         <select name="submenu1" class="form-control select2" required id="main-form-sel">							<option value=""></option>                                <?php                                 foreach($submenus1 as $submenu1){ 									if ($submenu1->id==$selmenu1) {										$selected="selected='selected'";										}else{										$selected='';									}                                        echo ' <option value="'.$submenu1->id.'" '.$selected.'>'.$submenu1->name.'</option>';                                }?>                            </select>                                                   </div>                         </br></br>                        <label class="col-sm-2 control-label"></label>                        <div class="col-sm-10 pull-right"  >                        <select class="form-control" name="submenu2" id="menu-con-sel2">							<option value=""></option>                                <?php                                                                 foreach($submenus2 as $submenu2){ 									if ($submenu2->id==$selmenu2) {										$selected="selected='selected'";										}else{										$selected='';									}                                        echo ' <option value="'.$submenu2->id.'" '.$selected.'>'.$submenu2->name.'</option>';                                }?>                            </select>                        </div>                         </br></br>                        <label class="col-sm-2 control-label"></label>                        <div class="col-sm-10 pull-right"  >                        <select class="form-control" name="submenu3" id="menu-con-sel3">							<option value=""></option>                                <?php                                                                 foreach($submenus3 as $submenu3){ 									if ($submenu3->id==$selmenu3) {										$selected="selected='selected'";										}else{										$selected='';									}                                        echo ' <option value="'.$submenu3->id.'" '.$selected.'>'.$submenu3->name.'</option>';                                }?>                            </select>                        </div>                         </br></br>                        <label class="col-sm-2 control-label"></label>                        <div class="col-sm-10 pull-right"  >                        <select class="form-control" name="submenu4" id="menu-con-sel4">							<option value=""></option>                                <?php                                                                 foreach($submenus4 as $submenu4){ 									if ($submenu4->id==$selmenu4) {										$selected="selected='selected'";										}else{										$selected='';									}                                        echo ' <option value="'.$submenu4->id.'" '.$selected.'>'.$submenu4->name.'</option>';                                }?>                            </select>                        </div>                    </div>                                   </div>            </div>        </div>    </div>
    <div class="row">
        <div class="col-lg-6">
          <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                       File Info
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                    <label class="col-sm-3 control-label">Title</label>
                        <div class="col-sm-9">
                            <input type="text" name="title" required value="<?=$file->title?>" id="<?=$file->title?>" accept="file/*" placeholder="<?=$file->title?>" required="" class="form-control" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                      <label class="col-sm-3 control-label">Date</label>
                        <div class="col-sm-9">
                            <input type="text" name="file_date" required required="" class="form-control" value="<?php if ($file->file_date != '0000-00-00 00:00:00'){echo date('m/d/Y',strtotime($file->file_date));}?>" />
                        </div>
                    </div>
                     <div class="form-group">       
                      <label class="col-sm-3 control-label">Select the file </label>                        
                                <div class="col-sm-9">
                                   <div class="fileinput fileinput-new" data-provides="fileinput">
					                        <div class="input-group">
					                           <div class="form-control uneditable-input" data-trigger="fileinput" style="width: 220px;">
					                                <i class="glyphicon glyphicon-file fileinput-exists"></i>
					                                <span class="fileinput-filename"></span>
					                            </div>
												<div>
					                            <span class="input-group-addon btn btn-default btn-file" style="width: 60px;">
					                               <span class="fileinput-new">Browse</span>
													<input type="file" accept="application/msword" name="link_url">
					                                <span class="fileinput-exists" style="width: 60px;">Change</span>       
					                            </span>		
					                            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput"> Delete </a>				
					                          </div>												
					                        </div>												 
					                    </div>
					               </div>
                            </div>
                </div>
            </div>
        </div>
     <div class="col-lg-6">
          <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                     Main Image
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                  <div class="form-group">                        
                        <div class="col-sm-10">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                    <img src="<?php echo base_url().$file->img_url;?>" alt="">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                <div>
                                    <span class="btn btn-white btn-file">
                                        <span class="fileinput-new">Select Image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="img_url" accept="image/*" >
                                    </span>
                                    <a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Delete</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>         <div class="col-lg-3"></div>   </div>    <div class="row">       <div class="col-lg-12">            <button type="submit" class="btn btn-success">Edit</button>        </div>    </div></form><script> $( "#main-form-sel" ).change(function () {    //$( "#dept-form-sel option:selected" ).each(function() {      // alert($( "#dept-form-sel option:selected" ).val());        //var value = $(this).val();       var value = $("#main-form-sel option:selected" ).val();               var info = 'menueid='+value;         var loading = "";                $.ajax({            type: "POST",            url: "<?php echo base_url();?>admin/menus/sub_menu_ajax/?"+info,            data: info,            cache: false,            async: true,            beforeSend : function(){                $("#menu-con-sel2").html('');                $("#menu-con-sel3").html('');                $("#menu-con-sel4").html('');            },            success: function(data_success){                if(data_success == ""){                                    }else{                    setTimeout(function() {                        $("#menu-con-sel2").html(data_success);                                            }, 1000);                }            }        });    }); $( "#menu-con-sel2" ).change(function () {	    //$( "#dept-form-sel option:selected" ).each(function() {	      // alert($( "#dept-form-sel option:selected" ).val());	        //var value = $(this).val();	       var value = $("#menu-con-sel2 option:selected" ).val();	        var info = 'menueid='+value; 	        var loading = "";	        $.ajax({	            type: "POST",	            url: "<?php echo base_url();?>admin/menus/sub_menu_ajax/?"+info,	            data: info,	            cache: false,	            async: true,	            beforeSend : function(){	                $("#menu-con-sel3").html('');	                $("#menu-con-sel4").html('');	            },	            success: function(data_success){	                if(data_success == ""){	                    	                }else{	                    setTimeout(function() {	                        $("#menu-con-sel3").html(data_success);	                        $("#menu-con-sel4").html('');	                       // $("#menu-con-sel3").html('');	                    }, 1000);	                }	            }	        });	    });   //}).change(); $( "#menu-con-sel3" ).change(function () {	    //$( "#dept-form-sel option:selected" ).each(function() {	      // alert($( "#dept-form-sel option:selected" ).val());	        //var value = $(this).val();	       var value = $("#menu-con-sel3 option:selected" ).val();	        var info = 'menueid='+value; 	        var loading = "";	        $.ajax({	            type: "POST",	            url: "<?php echo base_url();?>admin/menus/sub_menu_ajax/?"+info,	            data: info,	            cache: false,	            async: true,	            beforeSend : function(){	                $("#menu-con-sel4").html('');	            },	            success: function(data_success){	                if(data_success == ""){	                    	                }else{	                    setTimeout(function() {	                        $("#menu-con-sel4").html(data_success);	                       // $("#menu-con-sel3").html('');	                    }, 1000);	                }	            }	        });	    });
 jQuery(document).ready(function($) {		
		
		
		$('input[name="file_date"]').daterangepicker({
	        singleDatePicker: true,
	        showDropdowns: true
	    }); 
	    
		});    </script>