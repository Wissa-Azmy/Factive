<ol class="breadcrumb bc-3">
    <li>
        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?=  base_url()?>admin/comments">Comments</a>
    </li>
    <li class="active">
        <strong>Update Comment</strong>
    </li>
</ol>
<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                       Comment info
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Name</label>
                        <div class="col-sm-10">
                            <input type="text" name="name" value="<?=$comment->name?>" required required="" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Email</label>
                        <div class="col-sm-10">
                            <input type="text" name="email" value="<?=$comment->email?>" required required="" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Subject</label>
                        <div class="col-sm-10">
                            <textarea style="min-height:200px;"  name="subject" required required="" class="form-control" ><?=$comment->subject?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="col-lg-12">
        <button type="submit" class="btn btn-success">Edit </button>
        <?php if($comment->user_id){?>
            <?php if($this->Smartget->check_view_actions('2','comments', 'unpublish','1') == 1){?>
                <a href="<?=  base_url()?>admin/comments/unpublish/<?=$comment->id?>" class="btn btn-success">Unpublish</a>
            <?php }?>
        <?php }else{ ?>
            <?php if($this->Smartget->check_view_actions('2','comments', 'publish','1') == 1){?>
                <a href="<?=  base_url()?>admin/comments/publish/<?=$comment->id?>" class="btn btn-success">Publish</a>
            <?php }?>
        <?php } ?>
    </div>
</form>