
<form role="form" method="get" class="form-horizontal form-groups-bordered" action="<?php echo base_url();?>admin/comments/index">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        Search
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                        <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="form-group col-lg-2">
                        <label for="field-1" class="col-sm-2 control-label">ID</label>
                        <div class="col-sm-10">
                            <input type="number" name="sel_id" value="<?=$sel_id?>" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group col-lg-2">
                        <label for="field-1" class="col-sm-2 control-label">Trip ID</label>
                        <div class="col-sm-10">
                            <input type="number" name="sel_id_news" value="<?=$sel_id_news?>" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group col-lg-3">
                        <label for="field-1" class="col-sm-3 control-label">Keywords</label>
                        <div class="col-sm-9">
                            <input type="text" value="<?=$keyword?>" name="keywords" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group col-lg-3">
                        <label for="field-1" class="col-sm-3 control-label">Since</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="ago" >
                                <option value=""></option>
                                <option value=".15">15 MIN</option>
                                <option value=".30">Half Hour</option>
                                <option value="12">12 Hour</option>
                                <option value="23.59">24 Hour</option>
                            </select>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-lg-3">
                        <div class="col-sm-12">
                            <label for="field-1" class="col-sm-2 control-label">Limit</label>
                            <div class=" col-sm-10" >
                                <input type="number" name="limit" value="<?=$limit?>" class="form-control" />
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-lg-3">
                        <div class="col-sm-12">
                            <div class=" col-sm-12" >
                                <input tabindex="5" name="published" <?=$published?> type="checkbox" class="icheck-15  col-sm-12" id="minimal-checkbox-1-15">
                                <label for="minimal-checkbox-1-15">Published</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-lg-6">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-success col-lg-12">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered responsive">
            <thead>
                <tr>
                    <th>ID</th>
                    <th width="40%">Name</th>
                    <th>Comment Date</th>
                    <th>Last Update</th>
                    <th> </th>                    
                </tr>
            </thead>
            <tbody>
                <?php foreach($comments as $x=> $comment){ ?>
                    <tr>
                        <td><?=$comment->id?></td>
                        <td>
                            <a target="_blank" href="<?=  base_url()?>news/<?=$comment->news_id?>?admin"><?=$comment->name?></a>
                        </td>
                        <td><?=$this->Smartget->full_date($comment->created);?></td>
                        <td><?php if($comment->last_update != '0000-00-00 00:00:00'){echo $this->Smartget->full_date($comment->last_update);}else{echo 'لا يوجد تعديلات';}?> </td>
                        <td>
                           
                            <?php if($this->Smartget->check_view_actions('2','comments', 'edit','1') == 1){?>
                                <a href="<?=  base_url()?>admin/comments/edit/<?=$comment->id?>" class="btn btn-success">تعديل</a>
                            <?php }?>
                            <?php if($comment->user_id){?>
                                <?php if($this->Smartget->check_view_actions('2','comments', 'unpublish','1') == 1){?>
                                    <a href="<?=  base_url()?>admin/comments/unpublish/<?=$comment->id?>" class="btn btn-success">إلغاء النشر</a>
                                <?php }?>
                            <?php }else{ ?>
                                <?php if($this->Smartget->check_view_actions('2','comments', 'publish','1') == 1){?>
                                    <a href="<?=  base_url()?>admin/comments/publish/<?=$comment->id?>" class="btn btn-success">نشر</a>
                                <?php }?>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div><div class="pagination">					<?php echo $this->pagination->create_links(); ?>				</div>
