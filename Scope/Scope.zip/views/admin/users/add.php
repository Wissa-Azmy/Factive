<h1 class="margin-bottom">Add Administrator</h1>
<ol class="breadcrumb">
    <li>
        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?=  base_url()?>admin/users"><i class="fa-home"></i>Registered users</a>
    </li>
    <li class="active">
        <strong>Add user</strong>
    </li>
</ol>
<br>
<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-12">
            <?php if(!empty($errors)){ 
                    foreach($errors as $error_msg){
                        echo '<div class="alert alert-danger">';
                        echo '<p>'.$error_msg.'</p>';
                        echo '</div>';
                    }
                }
            ?>
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                          General Info
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <?php   
                        echo $this->form_builder->build_form_horizontal(
                        array(
                            array(
                                'id' => 'First Name',
                                'placeholder' => 'First Name',
                                //'value' => ($user->fname),
                                'name'=>'fname',
                                'required'=>''
                            ),
                            array(
                                'id' => 'Last Name',
                                'placeholder' => 'Last Name',
                                //'value' => ($user->lname),
                                'name'=>'lname',
                                'required'=>''
                            ),
                            array(
                                'id' => 'Day',
                                'placeholder' => 'Day',
                                //'value' => ($user->dob_d),
                                'name'=>'dob_d'
                            ),
                            array(
                                'id' => 'Month',
                                'placeholder' => 'Month',
                                //'value' => ($user->dob_m),
                                'name'=>'dob_m',
                                'data-mask'=>'dob_m'
                            ),
                            array(
                                'id' => 'Year',
                                'placeholder' => 'Year',
                                //'value' => ($user->dob_year),
                                'name'=>'dob_year',
                                //'disabled'=>'disabled',
                                'required'=>''
                            ),
                            array(
                                'id' => 'Email',
                                'placeholder' => 'Email',
                                //'value' => ($user->email),
                                'name'=>'email',
                                //'disabled'=>'disabled',
                                'required'=>''
                            ),
                        ), array());
                    ?>
                                  
                    <div class="panel-body ">
                        <div class="form-group col-sm-12">
                            <label class="col-sm-2 control-label">Password </label>
                            <div class="col-sm-5">
                                <input type="password" value="" required="" name="password" class="form-control"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php if($this->Scope->check_view_actions('2','users', 'edit','0') == 1){?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        Login
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body row">
                    <div class="form-group col-sm-2">
                        <label class="col-sm-3 control-label">Active</label>
                        <div class="col-sm-9">
                            <div class="make-switch" data-on-label="<i class='entypo-check'></i>" data-off-label="<i class='entypo-cancel'></i>">
                                <input type="checkbox"  name="active" />
                            </div>
                        </div>
                    </div>                   
                </div>
            </div>
        </div>
    </div>
<?php } ?>
    
    <div class="form-group default-padding">
            <button type="submit" class="btn btn-success">Add</button>
            <button type="reset" class="btn">Cancel</button>
    </div>

</form>