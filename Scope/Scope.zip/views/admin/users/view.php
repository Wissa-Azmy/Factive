<h1 class="margin-bottom"><?php echo @$users[0]->fname . ' ' . $users[0]->lname; ?></h1>

<ol class="breadcrumb">
    <li>
        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?=  base_url()?>admin/users"><i class="fa-home"></i>Registered users</a>
    </li>
    <li class="active">
        <strong><?php echo @$users[0]->fname . ' ' . $users[0]->lname; ?></strong>
    </li>
</ol>
<div id="blog-landing">
    <?php foreach($users as $user){ ?>
    <div class="member-entry">
        <a href="<?=base_url()?>admin/users/<?=$user->id?>" class="member-img">
            <img src="<?=base_url()?>uploaded/profile/<?=$user->avatar?>" class="img-rounded">
                <i class="entypo-forward"></i>
        </a>
        <div class="member-details">
            <h4>
               
            </h4>
            <!-- Details with Icons -->
            <div class="row info-list">
                <div class="col-sm-4">                    <i class="entypo-mail"></i>                    <a href="#"><?=$user->email?></a>                </div>
                <div class="col-sm-4">
                    <i class="entypo-user"></i>
                    <a href="#"><?=$user->dob_d?>-<?=$user->dob_m?>-<?=$user->dob_year?></a>
                </div>                <div class="col-sm-4">                    <i class="entypo-location"></i>                    <a href="#"><?=$country?></a>                </div>
               
                <div class="clear"></div>
                 
            </div>
            <div class="tools-useuserin">
                <?php
                if($this->Scope->check_view_actions('2','users', 'edit','') == 1){?>
                    <a href="<?=base_url()?>admin/users/edit/<?=$user->id?>" class="btn btn-default btn-sm btn-icon icon-left">
                        <i class="entypo-pencil"></i>
                        Edit
                    </a>
                <?php }?>
                <?php if($this->Scope->check_view_actions('2','users', 'delete','') == 1){?>
                    <a type="button"onclick="return confirm(del_massage);" href="<?=  base_url().'admin/users/delete/'.$user->id?>" class="btn btn-red btn-icon">
                                    <i class="entypo-cancel"></i>
                        Delete
                    </a>
                <?php }?>
                
               
            </div>
        </div>
    </div>
    <?php } ?> 
    
</div>