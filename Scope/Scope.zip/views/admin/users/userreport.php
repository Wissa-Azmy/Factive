<script type="text/javascript" src="<?php echo base_url(); ?>data/admin/js/reports/JSClass/FusionCharts.js"></script>	

<!-- BEGIN PAGE CONTENT-->


<h1>Users report</h1>
<form role="form" method="post" class="form-horizontal form-groups-bordered" action="<?php echo base_url();?>admin/users/userreportdetail">
    <div class="row">                   
           <div class="form-group col-lg-12">
               <div class="col-sm-6">
                    <input type="hidden" name="daterange" value="<?php echo $daterange;?>">
                        <button type="submit" class="btn btn-success col-lg-6">View report detail</button>
               </div>
           </div>
     </div>
</form>

				<div class="table-toolbar">	
								
				<div class="table-scrollable">
				
					<div id="chartdiv" style="text-align: justify;">Users report</div>
					
			        <script type="text/javascript">
					   var chart = new FusionCharts("<?php echo base_url(); ?>data/admin/js/reports/chart_user/Column3D.swf", "ChartId", "750", "470", "0", "0");
					   chart.setDataURL("<?php echo base_url(); ?>data/admin/js/reports/chart_user/Column3D.xml");		   
					   chart.render("chartdiv");
					</script> 
					</div>
				
				<table class="table table-striped table-bordered table-hover" id="example2">
					<thead>
                        <tr>						
							<th >Date</th>
							<th>Number of Users subscribed</th>							
						</tr>
					</thead>
					<tbody>
						<?php
						foreach($tableArray as $date => $res){?>
						<tr class="odd gradeX">
							<td><?php echo $date;?></td>
							<td><?php echo $res;?></td>
                           						
						</tr>
						<?php } ?>
						
					</tbody>
			
<script type="text/javascript">
$(document).ready(function() {
	
	// Initialize datepicker
	$('#starting_date').datepicker({setDate: new Date(),
		changeMonth: true,
		changeYear: true,
		 dateFormat: "yy-mm-dd"
		});
	$('#ending_date').datepicker({setDate: new Date(),
		changeMonth: true,
		changeYear: true,
		 dateFormat: "yy-mm-dd"
		});
	

});
</script>
