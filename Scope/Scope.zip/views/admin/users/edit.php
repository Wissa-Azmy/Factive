<h1 class="margin-bottom">Edit User <?php if($user->id != $this->session->userdata('admin')->id){echo '  For  '.$user->fname . ' ' . $user->lname; }?></h1>
<ol class="breadcrumb">
    <li>
        <a href="<?=  base_url()?>admin"><i class="fa-home"></i>Home</a>
    </li>
    <li>
        <a href="<?=  base_url()?>admin/users"><i class="fa-home"></i>Registered users</a>
    </li>
    <li class="active">
        <strong><?=$user->fname . ' ' . $user->lname; ?></strong>
    </li>
</ol>
<br>
<form role="form" method="post" class="form-horizontal form-groups-bordered validate" action="" novalidate="novalidate" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                            General Info
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>
                <div class="panel-body">
                    <?php                                         echo $this->form_builder->build_form_horizontal(
                        array( ), $user);
                    ?>                                       <div class="form-group">                        <label class="col-sm-2 control-label">First Name</label>                        <div class="col-sm-9">                            <?=$user->fname?>                        </div>                    </div>                    <div class="form-group">                        <label class="col-sm-2 control-label">Last Name</label>                        <div class="col-sm-9">                            <?=$user->lname?>                        </div>                    </div>                    <div class="form-group">                        <label class="col-sm-2 control-label">Birthdate</label>                        <div class="col-sm-9">                            <?=$user->dob_d?>-<?=$user->dob_m?>-<?=$user->dob_year?>                        </div>                    </div>                    <div class="form-group">                        <label class="col-sm-2 control-label">Email</label>                        <div class="col-sm-9">                            <?=$user->email?>                        </div>                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Creation Date</label>
                        <div class="col-sm-9">
                            <?=$user->register_date?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">Last Login</label>
                        <div class="col-sm-9">
                            <?=$user->login_date?>
                        </div>
                    </div>
                
                     
                </div>
            </div>
        </div>
    </div>
<?php if($this->Scope->check_view_actions('2','users', 'edit','0') == 1){?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        Login
                    </div>
                    <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                    </div>
                </div>                <div class="panel-body ">                        <div class="form-group col-sm-12">                            <label class="col-sm-3 control-label">Password</label>                            <div class="col-sm-5">                                <input type="password" value="" name="password" class="form-control"/>                            </div>                        </div>                    </div>
                <div class="panel-body">
                    <div class="form-group col-sm-12">
                        <label class="col-sm-3 control-label">Active</label>
                        <div class="col-sm-9">
                            <div class="make-switch" data-on-label="<i class='entypo-check'></i>" data-off-label="<i class='entypo-cancel'></i>">
                                <input type="checkbox" <?php if($user->active == 1){echo 'checked';}?> name="active" />
                            </div>
                        </div>
                    </div>
                  
                </div>                
            </div>
        </div>
    </div>
<?php } ?>
    
    <div class="form-group default-padding">
            <button type="submit" class="btn btn-success">Edit</button>
    </div>

</form>