  <div class="col-md-8">
			 <!-- Contact -->
                <div class="contact">
                  <h1> Welcome </h1>
                  <div class="contact-bor">
                    <div class="infotext">
                      Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. 
                    </div>
                   
                    <div class="add-contact">
                      <div class="row">
                        <div class="col-md-6">
                             <h2> <?php echo $new->title;?> </h2>
                          <h6><?php echo date('m/d/Y',strtotime($new->newdate));?></h6>
                          <div class="infotext">
                    <a href="<?=base_url()?>home/newdetail/<?=$new->id?>">  
                    
                    <?php $newDescription = strip_tags($new->desc);
                                if (strlen($newDescription) > 180) {
                                    $newDescription = substr($newDescription,0,strpos($newDescription,' ',180));
                                    $newDescription = $newDescription . ' ...';
                                }                                
						          echo $newDescription;?>
						           </a>
                    </div>
                        </div>
                        <div class="col-md-6 pull-right">
                          <br/>
                            <div class="our-img">
                            <?php if ($new->img_url){?>
                                <img class="img-responsive" alt="" src="<?php echo base_url().$new->img_url;?>"></div>
                           <?php }?>
                            
                        </div>
                      </div>
                    </div>
                  </div>
                  
                </div>
				<!-- End contact -->
              </div>
			  <!-- End Main content -->
			  
			  <!-- Sidebar left  -->
              <div class="col-md-4">
			  <!-- Box Siderbar -->
                <div class="box-siderbar-container">
				<!-- sidebar-box our-box -->
                  <div class="sidebar-box our-box">
                    <br> 
                    <div class="our-img">
                         
                         <video width="100%" height="100%" src="<?php echo base_url('assets/video/emm_file.mp4'); ?>" controls>
        				<object data="<?php echo base_url('assets/video/emm_file.mp4'); ?>" type="application/x-shockwave-flash">
        				<param value="<?php echo base_url('assets/video/emm_file.mp4'); ?>" name="movie"/>
        				</object>
				</video>
                    </div>
                    
                      <br>
                      <div class="text-center">
                       <h3 class="download-the-app">Download the app</h3>
                      
                          <div class="our-img">
                              <a href="#"><img alt="" src="<?php echo base_url();?>assets/images/app_06.jpg"></a></div>
                          <div class="our-img">
                              <a href="#"><img alt="" src="<?php echo base_url();?>assets/images/play_06.jpg"></a></div>
                      </div>
                     
               </div>
				 <!-- End sidebar-box our-box -->
		
                </div>
				<!-- End Box Siderbar -->
              </div>
			  <!-- End Sidebar left  -->