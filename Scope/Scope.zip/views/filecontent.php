
<script src="<?php echo base_url('assets/js/jquery.backstretch.js'); ?>"></script>

 <?php if ($id==1){?>
 <script>
        $.backstretch([
          "<?php echo base_url('assets/images/backgrounds_/img1.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img2.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img3.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img4.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img5.jpg'); ?>"
        
        ], {
        	fade: 600,		//Speed of Fade
        	duration: 5000 	//Time of image display
        });
    </script> 
    <?php }elseif ($id==2){?>
    <script>
        $.backstretch([
          "<?php echo base_url('assets/images/backgrounds_/img6.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img7.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img8.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img9.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img10.jpg'); ?>"
        
        ], {
        	fade: 600,		//Speed of Fade
        	duration: 5000 	//Time of image display
        });
    </script> 
    <?php }elseif ($id==3){?>
    <script>
        $.backstretch([
          "<?php echo base_url('assets/images/backgrounds_/img11.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img12.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img13.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img14.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img15.jpg'); ?>",
          "<?php echo base_url('assets/images/backgrounds_/img16.jpg'); ?>"
        
        ], {
        	fade: 500,		//Speed of Fade
        	duration: 5000 	//Time of image display
        });
    </script>
    <?php }?>
    
 <div class="v-al">
<div id="l-tabs" class="tab  tabtop left ">
                                <ul  >
                                 <?php if ($id==1){?>
                                     <img src="<?php echo base_url();?>assets/images/district-title-w.png"  class="wow fadeIn" data-wow-delay="400ms" data-wow-duration="1000ms" alt="">
                                  <?php }elseif ($id==2){?>
                                    <img src="<?php echo base_url();?>assets/images/beacon-title-w.png"  class="wow fadeIn" data-wow-delay="400ms" data-wow-duration="1000ms" alt="">
                                  <?php }elseif ($id==3){?>
                                     <img src="<?php echo base_url();?>assets/images/square-title-w.png"  class="wow fadeIn" data-wow-delay="400ms" data-wow-duration="1000ms" alt="">
                                  <?php }?>
                                  <?php foreach ($levels as $keym=>$level1r){ ?>
                                    <li ><a href="#l-tabs-<?php echo $keym;?>" ><h6 > <?php echo $level1r['name'];?></h6></a></li>
                                  <?php }?>
                                                                       
                                </ul>
                                <?php foreach ($levels as $keym=>$level1r){  ?>
                                    <div id="l-tabs-<?php echo $keym;?>">
                                    <div class="col-lg-12" >
                                    <div class=" main-el">
                                    <?php if (!empty($level1r['files'])){ ?>
                                      <div class="icon-list-1 col-lg-4 wow fadeInDown">
                                      <?php foreach ($level1r['files'] as $keyf=>$level1file){  ?>
                                    <div class="element">
                                        <i class="thedistrict alt-text-color flaticon-pdf25 pull-left"></i>
                                        <a class="hvr-icon-pulse" href="<?php echo base_url().$level1file->fileurl;?>" target="_blank" >    <p><?php echo $level1file->title;?></p></a>
                                    </div>
                                        <?php }?>
                                    </div>
                                   
                                    <?php }
                                    if (!empty($levels[$keym][$level1r['id']])){
                                        foreach ($levels[$keym][$level1r['id']] as $key=>$level2r){ 
                                    ?>
                                    
                                     <div class="icon-list-1 col-lg-4 wow fadeInDown" data-wow-delay="200ms" data-wow-duration="1000ms">
                                <div class="sep-heading-container shc4 clearfix">
                                    <h4><?php echo $level2r['name'];?></h4>
                                    <div class="sep-container">
                                        <div class="the-sep"></div>
                                    </div>
                                </div>
                                <?php foreach ($level2r['files'] as $keyf2=>$level2file){  ?>
                                   <div class="element">
                                        <i class="thedistrict alt-text-color flaticon-pdf25 pull-left"></i>
                                         <a class="hvr-icon-pulse" href="<?php echo base_url().$level2file->fileurl;?>" target="_blank" >    <p><?php echo $level2file->title;?></p></a>
                                    </div>
                                 <?php }?>
                                <?php if (!empty($level2r[$level2r['id']])){ ?>
                                      <div class="panel-group accordion" id="accordion-2">
                                    <?php                                                     
                                         foreach ($level2r[$level2r['id']] as $level3r){
                                                                            
                                ?>
                                        
                                    <div class="panel panel-default">
                                        <div class="panel-heading alt-bg-color">
                                            <h6 class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion-2" href="#acc-2-<?php echo $level3r['id'];?>">
                                                    <i class="fa "></i>
                                                    <?php echo $level3r['name'];?>
                                                </a>
                                            </h6>
                                        </div>
                                        <div id="acc-2-<?php echo $level3r['id'];?>" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <p>
                                      
                                     <?php foreach ($level3r['files'] as $keyf2=>$level3file){  ?>
                                       <div class="element">
                                            <i class="thedistrict alt-text-color flaticon-pdf25 pull-left"></i>
                                             <a class="hvr-icon-pulse" href="<?php echo base_url().$level3file->fileurl;?>" target="_blank" >    <p><?php echo $level3file->title;?></p></a>
                                        </div>
                                     <?php }?>
                                            </p>
                                        </div>
                                      </div>
                                    </div>
                                    
                                     
                                <?php }?>
                                    </div>
                                    <?php }?>
                                   </div>
                                <?php }}?>
                                
                                    </div>
                                </div>
                               </div>
                               
                                <?php }?>
                                
                            </div>                    
                            </div>