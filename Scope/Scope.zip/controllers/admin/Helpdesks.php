<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Helpdesks extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_builder');           
    }
   
    public function index($perpage=null){
        $this->Scope->check_view_actions('3','helpdesks', 'view','');  
       
        if(isset($_GET['keywords']) && !empty($_GET['keywords'])){
        	$keyword = $_GET['keywords'];
        	$keywords = explode(' ', $keyword);
        	$other='';
        	foreach($keywords as $keyword) {
        		$keys = trim($keyword);
        		if(!empty($keys)){
        			$other .= "or helpdesks.question like '%$keys%'";
        		}
        	}
        	$where[] = '  '.substr($other, 2);
        	$this->data['keyword'] =  $_GET['keywords'];
        }else{
        	$this->data['keyword'] =  '';
        }
               
        if(isset($_GET['sel_id']) && is_numeric($_GET['sel_id']) && !empty($_GET['sel_id'])){
        	$id_id = $_GET['sel_id'];
        	$where[] = '  helpdesks.id='.$id_id;
        	$this->data['sel_id'] =  $id_id;
        }else{
        	$this->data['sel_id'] =  '';
        }
               
          
        if(!empty($where)){
        	$where = ' WHERE '.implode(' AND ', $where);
        }else{
        	$where = '';
        }
        
        // $this->data['clientdetails'] =  $this->db->query('SELECT language.*, helpdesks_detail.act_name FROM helpdesks_detail INNER JOIN language ON helpdesks_detail.lang=language.id where helpdesks.act_id=' . $id .'')->result();
        $sql='SELECT helpdesks.* FROM helpdesks '.$where.'  ORDER BY helpdesks.id DESC ';
        $searchresults1 = $this->db->query($sql)->result();;
        $this -> load -> library('pagination');
        
        if(isset($_GET['limit']) && is_numeric($_GET['limit']) && !empty($_GET['limit'])){
        	$perpage = $_GET['limit'];
        } else if($perpage != null){
        	$perpage = $perpage;        	
        }else{
        	$perpage = 50;
        }
        
        /*
        if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
        	$perpage = $_GET['perpage'];
        } else if($perpage != null){
        	$perpage = $perpage;
        } else{
        	$perpage = 20;
        }
        */
         
        if(isset($_GET['perpage'])){
        	$sel = $_GET['perpage'];
        }
        else if($perpage != null){
        	$sel = $perpage;
        }
        else{
        	$sel = -1;
        }
        
        $config['base_url'] = base_url() . 'admin/helpdesks/index/'.$perpage.'/';
        $config['total_rows'] = count($searchresults1);
        // $config['first_url'] = base_url() . 'admin/users/index';
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
        
        $config['full_tag_open'] = '<div id="paging">';
        $config['full_tag_close'] = '</div>';
        $config['cur_tag_open'] = '<b>';
        $config['cur_tag_close'] = '</b>';
        $config['first_link'] =  "";
        $config['last_link'] =  "";
        //$config['page_query_string'] = TRUE;
        //$config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['suffix'] = '?'.http_build_query($_GET, '', "&");
        // $config['query_string_segment'] = 'per_page'.$perpage;
        $this -> pagination -> initialize($config);
        
        if ($this -> uri -> segment(5)) {
        	$sql = $sql ." LIMIT ".$this -> uri -> segment(5).",".$config['per_page'] ;
        }else{
        	$sql = $sql ." LIMIT ".$config['per_page'];
        }
         
        // echo "hghgh".$this -> uri -> segment(5).$config['per_page'];
        //$this -> db -> limit($config['per_page'], $this -> uri -> segment(4));
        $query  = $this->db->query($sql)->result();
        
        
        
        
  
        $this->data['limit'] =  $perpage;
        //$query  = $this->db->query('SELECT * FROM helpdesks'.$where.'  ORDER BY helpdesks.id DESC LIMIT '.$limit.' ')->result();
        $this->data['helpdesks'] = $query;
        $this->data['page'] = "/admin/helpdesks/index";
        $this->load->view("/admin/layout", $this->data);
    }  
    
  
    public function add(){
		$this->Scope->check_view_actions('3','helpdesks', 'add','');       
      
       
       // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script> '
                . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
                . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
                . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
                . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.css">'
                .'<script src="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.js"></script>'
              // .'<script src="'.base_url().'data/admin/js/inputtags/js/app.js"></script>'
               // . '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
        . '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
            // .'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
        .'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
            .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        /////save side
        $data = $this->input->post();  
       
        if(!empty($data)){
            /*
            echo "<pre>";
            print_r($data);
            echo "<pre>";
            */
           // $save_array = array();
            
                            
            $save_array['creation_date'] = date("Y-m-d H:i:s");
            $save_array['creation_user'] = $this->session->userdata('admin')->id;
             if(!isset($data['question'])){$save_array['question'] = '';}else{$save_array['question'] = $data['question'];}
             if(!isset($data['answer'])){$save_array['answer'] = '';}else{$save_array['answer'] = $data['answer'];}
            
           
            $this->db->insert('helpdesks',$save_array);
            //echo $this->db->last_query();
            $helpdesks_detail_data = array();
            $helpdesks_detail_data['helpdesk_id']=$helpdeskid  = $this->db->insert_id();            
            
            $this->session->set_flashdata('good', 'Added successfully');
            $this->session->keep_flashdata('good');
           redirect(base_url().'admin/helpdesks');
           			
			$data = array('images_watermark'=>$this->input->post('images_watermark'),'poster_watermark'=>$this->input->post('poster_watermark'),'question'=>$this->input->post('question'),'subquestion'=>$this->input->post('subquestion'),'slider'=>$this->input->post('slider'),'img_comment'=>$this->input->post('img_comment'),'content'=>$this->input->post('content'),'meta_keywords'=>$this->input->post('meta_keywords'),'iframe'=>$this->input->post('iframe'));
            $this->data['data'] = $data;
        }else{
            $data = array('question'=>'','poster_watermark'=>'','images_watermark'=>'','subquestion'=>'','slider'=>'','img_comment'=>'','content'=>'','meta_keywords'=>'','iframe'=>'');
            $this->data['data'] = $data;
        }
        $this->data['page'] = "/admin/helpdesks/add";
        $this->load->view("/admin/layout", $this->data);
    }   

  
    public function edit($id){
        $this->Scope->check_view_actions('3','helpdesks', 'edit','');
        $helpdesks1 = $this->db->query('SELECT * FROM helpdesks where id = ' . $id .'')->result(); 
        $helpdesks  = $this->data['helpdesks'] = $helpdesks1[0];
              
         /*
         echo "<pre>";
         print_r($helpdesks);
         echo "</pre>";
         */
        // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script> '
            . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
            . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
            . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
            . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.css">'
            .'<script src="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.js"></script>'
            //.'<script src="'.base_url().'data/admin/js/inputtags/js/app.js"></script>'
            //. '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
            . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
            . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
                . '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
               // .'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
                .'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
                .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        /////save side
        $data = $this->input->post();         
        if(!empty($data)){
            /*
             echo "<pre>";
             print_r($data);
             echo "<pre>";
             */
           // $save_array = array();
           
          
             //if(!isset($data['content'])){$save_array['topic'] = '';}else{$save_array['topic'] = $data['content'];}
                $save_array['modified_date'] = date("Y-m-d H:i:s");
                $save_array['modified_user'] = $this->session->userdata('admin')->id;
                if(!isset($data['question'])){$save_array['question'] = '';}else{$save_array['question'] = $data['question'];}
                if(!isset($data['answer'])){$save_array['answer'] = '';}else{$save_array['answer'] = $data['answer'];}
                
                $this->Scope->update('helpdesks',$save_array,array('id'=>$id));                
                //echo $this->db->last_query();
                $helpdesks_detail_data = array();
                $helpdesks_detail_data['helpdesk_id']  = $id;
    
                               
    
                $this->session->set_flashdata('good', 'Updated successfully');
                $this->session->keep_flashdata('good');
                redirect(base_url().'admin/helpdesks');               
                	
                $data = array('images_watermark'=>$this->input->post('images_watermark'),'poster_watermark'=>$this->input->post('poster_watermark'),'question'=>$this->input->post('question'),'subquestion'=>$this->input->post('subquestion'),'slider'=>$this->input->post('slider'),'img_comment'=>$this->input->post('img_comment'),'content'=>$this->input->post('content'),'meta_keywords'=>$this->input->post('meta_keywords'),'iframe'=>$this->input->post('iframe'));
                $this->data['data'] = $data;
        }else{
            $data = array('question'=>'','poster_watermark'=>'','images_watermark'=>'','subquestion'=>'','slider'=>'','img_comment'=>'','content'=>'','meta_keywords'=>'','iframe'=>'');
            $this->data['data'] = $data;
        }
        $this->data['page'] = "/admin/helpdesks/edit";
        $this->load->view("/admin/layout", $this->data);
    }
 

    public function delete($id){
        if(!is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/helpdesks');
        }
        $helpdesk1 = $this->data['helpdesk'] = $this->db->query('SELECT * FROM helpdesks where id = ' . $id .'')->result();
        $helpdesk = $helpdesk1[0];
        if(empty($helpdesk)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/helpdesks');
        }
        if($this->Scope->check_view_actions('2','helpdesks','delete','') == 1){
            $this->Scope->delete_cond('helpdesks_detail', array('helpdesk_id'=>$id));
            $this->Scope->delete('helpdesks', $id);
            $this->session->set_flashdata('good', 'Delete Done');
            $this->session->keep_flashdata('good');
            redirect(base_url().'admin/helpdesks');
        }else{
            $this->session->set_flashdata('error', 'Error in deleting');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/helpdesks');
        }
    }
}