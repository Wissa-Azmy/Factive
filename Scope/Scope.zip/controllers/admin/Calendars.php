<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calendars extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_builder');
        $this->original_path = realpath(APPPATH.'uploaded/calendars/large');
        $this->resized_path = realpath(APPPATH.'uploaded/calendars/thumb');
        $this->thumbs_path = realpath(APPPATH.'uploaded/calendars/thumb');        
    }
   
    public function index($perpage=null){
        $this->Scope->check_view_actions('3','calendars', 'view','');  
       
        if(isset($_GET['keywords']) && !empty($_GET['keywords'])){
        	$keyword = $_GET['keywords'];
        	$keywords = explode(' ', $keyword);
        	$other='';
        	foreach($keywords as $keyword) {
        		$keys = trim($keyword);
        		if(!empty($keys)){
        			$other .= "or calendars.title like '%$keys%'";
        		}
        	}
        	$where[] = '  '.substr($other, 2);
        	$this->data['keyword'] =  $_GET['keywords'];
        }else{
        	$this->data['keyword'] =  '';
        }
               
        if(isset($_GET['sel_id']) && is_numeric($_GET['sel_id']) && !empty($_GET['sel_id'])){
        	$id_id = $_GET['sel_id'];
        	$where[] = '  calendars.id='.$id_id;
        	$this->data['sel_id'] =  $id_id;
        }else{
        	$this->data['sel_id'] =  '';
        }
               
          
        if(!empty($where)){
        	$where = ' WHERE '.implode(' AND ', $where);
        }else{
        	$where = '';
        }
        
        // $this->data['clientdetails'] =  $this->db->query('SELECT language.*, calendars_detail.act_name FROM calendars_detail INNER JOIN language ON calendars_detail.lang=language.id where calendars.act_id=' . $id .'')->result();
        $sql='SELECT calendars.* FROM calendars '.$where.'  ORDER BY calendars.id DESC ';
        $searchresults1 = $this->db->query($sql)->result();;
        $this -> load -> library('pagination');
        
        if(isset($_GET['limit']) && is_numeric($_GET['limit']) && !empty($_GET['limit'])){
        	$perpage = $_GET['limit'];
        } else if($perpage != null){
        	$perpage = $perpage;        	
        }else{
        	$perpage = 50;
        }
        
        /*
        if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
        	$perpage = $_GET['perpage'];
        } else if($perpage != null){
        	$perpage = $perpage;
        } else{
        	$perpage = 20;
        }
        */
         
        if(isset($_GET['perpage'])){
        	$sel = $_GET['perpage'];
        }
        else if($perpage != null){
        	$sel = $perpage;
        }
        else{
        	$sel = -1;
        }
        
        $config['base_url'] = base_url() . 'admin/calendars/index/'.$perpage.'/';
        $config['total_rows'] = count($searchresults1);
        // $config['first_url'] = base_url() . 'admin/users/index';
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
        
        $config['full_tag_open'] = '<div id="paging">';
        $config['full_tag_close'] = '</div>';
        $config['cur_tag_open'] = '<b>';
        $config['cur_tag_close'] = '</b>';
        $config['first_link'] =  "";
        $config['last_link'] =  "";
        //$config['page_query_string'] = TRUE;
        //$config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['suffix'] = '?'.http_build_query($_GET, '', "&");
        // $config['query_string_segment'] = 'per_page'.$perpage;
        $this -> pagination -> initialize($config);
        
        if ($this -> uri -> segment(5)) {
        	$sql = $sql ." LIMIT ".$this -> uri -> segment(5).",".$config['per_page'] ;
        }else{
        	$sql = $sql ." LIMIT ".$config['per_page'];
        }
         
        // echo "hghgh".$this -> uri -> segment(5).$config['per_page'];
        //$this -> db -> limit($config['per_page'], $this -> uri -> segment(4));
        $query  = $this->db->query($sql)->result();
        
        
        
        
  
        $this->data['limit'] =  $perpage;
        //$query  = $this->db->query('SELECT * FROM calendars'.$where.'  ORDER BY calendars.id DESC LIMIT '.$limit.' ')->result();
        $this->data['calendars'] = $query;
        $this->data['page'] = "/admin/calendars/index";
        $this->load->view("/admin/layout", $this->data);
    }  
    
  
    public function add(){
		$this->Scope->check_view_actions('3','calendars', 'add','');       
      
       
       // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script> '
                . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
                . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
                . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
                . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.css">'
                .'<script src="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.js"></script>'
              // .'<script src="'.base_url().'data/admin/js/inputtags/js/app.js"></script>'
               // . '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
        . '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
            // .'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
        .'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
            .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        /////save side
        $data = $this->input->post();  
       
        if(!empty($data)){
            /*
            echo "<pre>";
            print_r($data);
            echo "<pre>";
            */
           // $save_array = array();            
       
           // if(!isset($data['schedules'])){$save_array['schedule'] = '';}else{
             //   $save_array['schedule'] = json_encode($data['schedules'], TRUE);}                      
            $save_array['creation_date'] = date("Y-m-d H:i:s");
            $save_array['creation_user'] = $this->session->userdata('admin')->id;
           //$groups  = $this->db->query('SELECT * FROM groups  where post_link !=""')->result();
            if (isset($data['calendardate']) && !empty($data['calendardate'])) {
                $daterange = explode(' - ', $data['calendardate']);
                //$start_date = date('Y-m-d H:i:s',strtotime($daterange['0']));
                //$end_date = date('Y-m-d H:i:s',strtotime($daterange['1']));
                $save_array['startdate'] = $daterange['0'];
                $save_array['enddate'] = $daterange['1'];
                 
            }
            //if(!isset($data['calendardate'])){$save_array['calendardate'] = '';}else{$save_array['calendardate'] = date('Y-m-d',strtotime($data['calendardate']));}
            if(!isset($data['title'])){$save_array['title'] = '';}else{$save_array['title'] = $data['title'];}
            
           
           
            $this->db->insert('calendars',$save_array);
            $id  = $this->db->insert_id();
            /****************Notification***************/
            $notification_array['msg_id']=2;
            $notification_array['post_id']=$id;
            $notification_array['notification_date']=date("Y-m-d H:i:s");
            $notification_array['url']="home/calendar/".date('Y-m-d',strtotime($save_array['startdate']));
            
            $sql='SELECT * FROM users WHERE active=1 ORDER BY id DESC ';
            $usersresults = $this->db->query($sql)->result();
            
            foreach($usersresults as $x=> $usersresult){
                $notification_array['user_id']=$usersresult->id;
                $this->db->insert('notifications',$notification_array);
            }
            /****************Notification***************/
           // echo $this->db->last_query();
            $calendars_detail_data = array();
            $calendars_detail_data['calendar_id']=$calendarid  = $this->db->insert_id();            
            
            $this->session->set_flashdata('good', 'Added successfully');
            $this->session->keep_flashdata('good');
           redirect(base_url().'admin/calendars');
           			
			$data = array('images_watermark'=>$this->input->post('images_watermark'),'poster_watermark'=>$this->input->post('poster_watermark'),'title'=>$this->input->post('title'),'subtitle'=>$this->input->post('subtitle'),'slider'=>$this->input->post('slider'),'img_comment'=>$this->input->post('img_comment'),'content'=>$this->input->post('content'),'meta_keywords'=>$this->input->post('meta_keywords'),'iframe'=>$this->input->post('iframe'));
            $this->data['data'] = $data;
        }else{
            $data = array('title'=>'','poster_watermark'=>'','images_watermark'=>'','subtitle'=>'','slider'=>'','img_comment'=>'','content'=>'','meta_keywords'=>'','iframe'=>'');
            $this->data['data'] = $data;
        }
        $this->data['page'] = "/admin/calendars/add";
        $this->load->view("/admin/layout", $this->data);
    }   
        
    public function edit($id){
        $this->Scope->check_view_actions('3','calendars', 'edit','');
        $calendars1 = $this->db->query('SELECT * FROM calendars where id = ' . $id .'')->result(); 
        $calendars  = $this->data['calendars'] = $calendars1[0];
              
         /*
         echo "<pre>";
         print_r($calendars);
         echo "</pre>";
         */
        // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script> '
            . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
            . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
            . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
            . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.css">'
            .'<script src="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.js"></script>'
            //.'<script src="'.base_url().'data/admin/js/inputtags/js/app.js"></script>'
            //. '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
            . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
            . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
                . '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
               // .'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
                .'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
                .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        /////save side
        $data = $this->input->post();         
        if(!empty($data)){
            /*
             echo "<pre>";
             print_r($data);
             echo "<pre>";
             */
           
           
                $save_array['modified_date'] = date("Y-m-d H:i:s");
                $save_array['modified_user'] = $this->session->userdata('admin')->id;
                
                if (isset($data['calendardate']) && !empty($data['calendardate'])) {
                    $daterange = explode(' - ', $data['calendardate']);
                    //$start_date = date('Y-m-d H:i:s',strtotime($daterange['0']));
                    //$end_date = date('Y-m-d H:i:s',strtotime($daterange['1']));
                    $save_array['startdate'] = $daterange['0'];
                    $save_array['enddate'] = $daterange['1'];
                     
                }
                if(!isset($data['title'])){$save_array['title'] = '';}else{$save_array['title'] = $data['title'];}
                
                $this->Scope->update('calendars',$save_array,array('id'=>$id));                
                echo $this->db->last_query();
                $calendars_detail_data = array();
                $calendars_detail_data['calendar_id']  = $id;
    
                               
    
                $this->session->set_flashdata('good', 'Updated successfully');
                $this->session->keep_flashdata('good');
                //redirect(base_url().'admin/calendars');               
                	
                $data = array('images_watermark'=>$this->input->post('images_watermark'),'poster_watermark'=>$this->input->post('poster_watermark'),'title'=>$this->input->post('title'),'subtitle'=>$this->input->post('subtitle'),'slider'=>$this->input->post('slider'),'img_comment'=>$this->input->post('img_comment'),'content'=>$this->input->post('content'),'meta_keywords'=>$this->input->post('meta_keywords'),'iframe'=>$this->input->post('iframe'));
                $this->data['data'] = $data;
        }else{
            $data = array('title'=>'','poster_watermark'=>'','images_watermark'=>'','subtitle'=>'','slider'=>'','img_comment'=>'','content'=>'','meta_keywords'=>'','iframe'=>'');
            $this->data['data'] = $data;
        }
        $this->data['page'] = "/admin/calendars/edit";
        $this->load->view("/admin/layout", $this->data);
    }
 
    public function delete($id){
        if(!is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/calendars');
        }
        $calendar1 = $this->data['calendar'] = $this->db->query('SELECT * FROM calendars where id = ' . $id .'')->result();
        $calendar = $calendar1[0];
        if(empty($calendar)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/calendars');
        }
        if($this->Scope->check_view_actions('2','calendars','delete','') == 1){
            $this->Scope->delete_cond('calendars_detail', array('calendar_id'=>$id));
            $this->Scope->delete('calendars', $id);
            $this->session->set_flashdata('good', 'Delete Done');
            $this->session->keep_flashdata('good');
            redirect(base_url().'admin/calendars');
        }else{
            $this->session->set_flashdata('error', 'Error in deleting');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/calendars');
        }
    }
}