<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_builder');
        $this->original_path = realpath(APPPATH.'uploaded/news/large');
        $this->resized_path = realpath(APPPATH.'uploaded/news/thumb');
        $this->thumbs_path = realpath(APPPATH.'uploaded/news/thumb');        
    }
   
    public function index($perpage=null){
        $this->Scope->check_view_actions('3','news', 'view','');  
       
        if(isset($_GET['keywords']) && !empty($_GET['keywords'])){
        	$keyword = $_GET['keywords'];
        	$keywords = explode(' ', $keyword);
        	$other='';
        	foreach($keywords as $keyword) {
        		$keys = trim($keyword);
        		if(!empty($keys)){
        			$other .= "or news.title like '%$keys%'";
        		}
        	}
        	$where[] = '  '.substr($other, 2);
        	$this->data['keyword'] =  $_GET['keywords'];
        }else{
        	$this->data['keyword'] =  '';
        }
               
        if(isset($_GET['sel_id']) && is_numeric($_GET['sel_id']) && !empty($_GET['sel_id'])){
        	$id_id = $_GET['sel_id'];
        	$where[] = '  news.id='.$id_id;
        	$this->data['sel_id'] =  $id_id;
        }else{
        	$this->data['sel_id'] =  '';
        }
               
          
        if(!empty($where)){
        	$where = ' WHERE '.implode(' AND ', $where);
        }else{
        	$where = '';
        }
        
        // $this->data['clientdetails'] =  $this->db->query('SELECT language.*, news_detail.act_name FROM news_detail INNER JOIN language ON news_detail.lang=language.id where news.act_id=' . $id .'')->result();
        $sql='SELECT news.* FROM news '.$where.'  ORDER BY news.id DESC ';
        $searchresults1 = $this->db->query($sql)->result();;
        $this -> load -> library('pagination');
        
        if(isset($_GET['limit']) && is_numeric($_GET['limit']) && !empty($_GET['limit'])){
        	$perpage = $_GET['limit'];
        } else if($perpage != null){
        	$perpage = $perpage;        	
        }else{
        	$perpage = 50;
        }
        
        /*
        if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
        	$perpage = $_GET['perpage'];
        } else if($perpage != null){
        	$perpage = $perpage;
        } else{
        	$perpage = 20;
        }
        */
         
        if(isset($_GET['perpage'])){
        	$sel = $_GET['perpage'];
        }
        else if($perpage != null){
        	$sel = $perpage;
        }
        else{
        	$sel = -1;
        }
        
        $config['base_url'] = base_url() . 'admin/news/index/'.$perpage.'/';
        $config['total_rows'] = count($searchresults1);
        // $config['first_url'] = base_url() . 'admin/users/index';
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
        
        $config['full_tag_open'] = '<div id="paging">';
        $config['full_tag_close'] = '</div>';
        $config['cur_tag_open'] = '<b>';
        $config['cur_tag_close'] = '</b>';
        $config['first_link'] =  "";
        $config['last_link'] =  "";
        //$config['page_query_string'] = TRUE;
        //$config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['suffix'] = '?'.http_build_query($_GET, '', "&");
        // $config['query_string_segment'] = 'per_page'.$perpage;
        $this -> pagination -> initialize($config);
        
        if ($this -> uri -> segment(5)) {
        	$sql = $sql ." LIMIT ".$this -> uri -> segment(5).",".$config['per_page'] ;
        }else{
        	$sql = $sql ." LIMIT ".$config['per_page'];
        }
         
        // echo "hghgh".$this -> uri -> segment(5).$config['per_page'];
        //$this -> db -> limit($config['per_page'], $this -> uri -> segment(4));
        $query  = $this->db->query($sql)->result();
        
        
        
        
  
        $this->data['limit'] =  $perpage;
        //$query  = $this->db->query('SELECT * FROM news'.$where.'  ORDER BY news.id DESC LIMIT '.$limit.' ')->result();
        $this->data['news'] = $query;
        $this->data['page'] = "/admin/news/index";
        $this->load->view("/admin/layout", $this->data);
    }  
    
  
    public function add(){
		$this->Scope->check_view_actions('3','news', 'add','');       
      
       
       // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script> '
                . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
                . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
                . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
                . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.css">'
                .'<script src="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.js"></script>'
              // .'<script src="'.base_url().'data/admin/js/inputtags/js/app.js"></script>'
               // . '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
        . '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
            // .'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
        .'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
            .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        /////save side
        $data = $this->input->post();  
       
        if(!empty($data)){
            /*
            echo "<pre>";
            print_r($data);
            echo "<pre>";
            */
           // $save_array = array();
            
            if(isset($data['images_watermark']) && $data['images_watermark'] == '1'){$images_watermark = '1';}else{$images_watermark = '';}
            if(isset($data['poster_watermark']) && $data['poster_watermark'] == '1'){$poster_watermark = '1';}else{$poster_watermark = '';}
            $poster = $this->poster_upload($poster_watermark);   
            $images = json_encode($this->images_post($images_watermark));
            //if(!isset($data['img_url'])){$save_array['img_url'] = '';}else{$save_array['img_url'] = $data['img_url'];}
            if(!empty($poster)){
                $save_array['img_url'] = $poster['large'];
                 $save_array['thumb_url'] = $poster['thumb'];
            }
            if(!empty($images)){$save_array['images'] = $images;}
                // unset($save_array['poster_watermark']);
                // unset($save_array['images_watermark']);
           // if(!isset($data['schedules'])){$save_array['schedule'] = '';}else{
             //   $save_array['schedule'] = json_encode($data['schedules'], TRUE);}                      
            $save_array['creation_date'] = date("Y-m-d H:i:s");
            $save_array['creation_user'] = $this->session->userdata('admin')->id;
           //$groups  = $this->db->query('SELECT * FROM groups  where post_link !=""')->result();
            if(!isset($data['newdate'])){$save_array['newdate'] = '';}else{$save_array['newdate'] = date('Y-m-d',strtotime($data['newdate']));}
            if(!isset($data['title'])){$save_array['title'] = '';}else{$save_array['title'] = $data['title'];}
             if(!isset($data['desc'])){$save_array['desc'] = '';}else{$save_array['desc'] = $data['desc'];}
            
           
           
            $this->db->insert('news',$save_array);
            //echo $this->db->last_query();
            $news_detail_data = array();
            $news_detail_data['new_id']=$newid  = $this->db->insert_id();            
            
            $this->session->set_flashdata('good', 'Added successfully');
            $this->session->keep_flashdata('good');
           redirect(base_url().'admin/news');
           			
			$data = array('images_watermark'=>$this->input->post('images_watermark'),'poster_watermark'=>$this->input->post('poster_watermark'),'title'=>$this->input->post('title'),'subtitle'=>$this->input->post('subtitle'),'slider'=>$this->input->post('slider'),'img_comment'=>$this->input->post('img_comment'),'content'=>$this->input->post('content'),'meta_keywords'=>$this->input->post('meta_keywords'),'iframe'=>$this->input->post('iframe'));
            $this->data['data'] = $data;
        }else{
            $data = array('title'=>'','poster_watermark'=>'','images_watermark'=>'','subtitle'=>'','slider'=>'','img_comment'=>'','content'=>'','meta_keywords'=>'','iframe'=>'');
            $this->data['data'] = $data;
        }
        $this->data['page'] = "/admin/news/add";
        $this->load->view("/admin/layout", $this->data);
    }   
    private function images_post($watermark){   
        $images = array();
        $dataimg = $this->input->post();
        if(!empty($_FILES['images']['name'][0])) {
            $this->load->library('image_lib');
            $files = $_FILES;
            $cpt = count($_FILES['images']['name']);
            for($i=0; $i<$cpt; $i++){
                $_FILES['image']['name']= $files['images']['name'][$i];
                $_FILES['image']['type']= $files['images']['type'][$i];
                $_FILES['image']['tmp_name']= $files['images']['tmp_name'][$i];
                $_FILES['image']['error']= $files['images']['error'][$i];
                $_FILES['image']['size']= $files['images']['size'][$i];    
                $img_path = 'uploaded/news/large';
                $full_img_path = $img_path.'/'.date('Y').'/'.date('m').'/'.date('d');
                @mkdir($full_img_path, 0777, true);
                @mkdir(str_replace('large', 'thumb', $full_img_path), 0777, true);
                $config['upload_path'] = $full_img_path;
                $config['allowed_types'] = '*';
                /*                
                $config['max_size']      =   "0";
                $config['max_width']     =   "0";
                $config['max_height']    =   "0";
                */
                $config['encrypt_name']    =   TRUE;
                $this->load->library('upload', $config);
                $this->upload->do_upload('image');
                
                $fu_as_ad = $this->upload->data();
               // $img = $images[] = $full_img_path.'/'.$fu_as_ad['file_name'];
                $img = $images[$i]['image'] = $full_img_path.'/'.$fu_as_ad['file_name'];
                list($name, $ext) = explode(".", $_FILES['image']['name']);
               // echo "<br>".$name." ".$dataimg[$name]." ".$_FILES['image']['name'];
                $images[$i]['comment']=$dataimg[$name];
                
                if(!empty($img)){
                    if($watermark == 1){
                        $this->watermark($fu_as_ad['file_name'],$full_img_path.'/');
                    }
                }
               
            }
            /*
            echo "<pre>";
            print_r($_FILES['images']);
            echo "</pre>";
           
            echo "<pre>";
            print_r($dataimg['imgcomment']);
            echo "</pre>";
            */
            
        }
        //$data =    array('error' => $this->upload->display_errors());
        //print_r($data);
        return $images;
    }
    function poster_upload ($watermark){
        if($_FILES['img_url']) {
            $img_path = 'uploaded/news/large';
            $full_img_path = $img_path.'/'.date('Y').'/'.date('m').'/'.date('d');
            @mkdir($full_img_path, 0777, true);
            @mkdir(str_replace('large', 'thumb', $full_img_path), 0777, true);
            $config['upload_path'] = $full_img_path;
            $config['allowed_types'] = '*';
            /*
            $config['max_size']      =   "5000";
            $config['max_width']     =   "1907";
            $config['max_height']    =   "1280";
            */
            $config['encrypt_name']    =   TRUE;
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('img_url')){
                $this->load->library('image_lib');
                $data = array('upload_data' => $this->upload->data());

                $this->data['data'] = $data;
                if($watermark == 1){
                    $this->watermark($data['upload_data']['file_name'],$full_img_path.'/');
                }
                $thumb_path = $this->do_thumb($data['upload_data']['file_name'],$full_img_path.'/');
                $return = array('large' => $full_img_path.'/'.$data['upload_data']['file_name'],'thumb'=>$thumb_path);
                return $return;
            }else{

			     //$data =    array('error' => $this->upload->display_errors());
                 //print_r($data);
            }
        }
    }
    function watermark($filename,$path){
        $image_cfg = array();
        $image_cfg['image_library'] = 'GD2';
        $image_cfg['source_image'] = $path . $filename;
        $image_cfg['wm_overlay_path'] = 'data/logo_overlay.png';
        $image_cfg['new_image'] = $path.$filename;
        $image_cfg['wm_type'] = 'overlay';
        $image_cfg['wm_opacity'] = '5';
        $image_cfg['wm_vrt_alignment'] = 'top';
        $image_cfg['wm_hor_alignment'] = 'left';
        $image_cfg['create_thumb'] = FALSE;
        @$this->image_lib->initialize($image_cfg);
        @$this->image_lib->watermark();
        $this->image_lib->clear();
        $this->watermark2($filename,$path);
    }
    function watermark2($filename,$path){
        $config = array();
        $config['image_library'] = 'GD2';
        $config['source_image'] =  $path . $filename;
        $config['new_image'] = $path . $filename;
        $config['wm_text']          = 'www.sharmtoday.com';
        $config['wm_type']          = 'text';
        $config['wm_font_path']     = 'data/fonts/watermark/Lato-Light.ttf';
        $config['wm_font_size']     = 18;
        $config['wm_opacity']       = '50';
        $config['wm_font_color']    = 'f0f0f0';
        $config['wm_vrt_alignment'] = 'middle';
        $config['wm_hor_alignment'] = 'center';
        $config['wm_padding']       = '0';
        $this->image_lib->initialize($config);
        if (!$this->image_lib->watermark()) {
            echo $this->image_lib->display_errors();
        }
    }
    function do_thumb($filename,$path) {
        $image_cfg['image_library'] = 'GD2';
        $image_cfg['source_image'] =  $path. $filename;
        $image_cfg['create_thumb'] = TRUE;
        $image_cfg['maintain_ratio'] = TRUE;
        $image_cfg['width'] = '200';
        $image_cfg['height'] = '175';
        $image_cfg['new_image'] = str_replace('large', 'thumb', $path).'/'.$filename;
        $new_file_name = str_replace('large', 'thumb', $path).$filename;
        $ext = pathinfo($image_cfg['new_image'], PATHINFO_EXTENSION);
        $new_file_name = str_replace('.'.$ext, '_thumb.'.$ext, $new_file_name);
        $this->load->library('image_lib');
        @$this->image_lib->initialize($image_cfg);
        @$this->image_lib->resize();
        $this->image_lib->clear();
        return $new_file_name;
    }
    public function edit_img(){
        $image_del = $_GET['id'];
        $id = $_GET['news'];
        if(!is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        $news1 = $this->data['news'] = $this->db->query('SELECT * FROM news where id = ' . $id .'')->result();
        $news = $news1[0];
        if(empty($news)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
         
    
        //$news21 = $this->db->query('SELECT * FROM news where id = ' . $id .'')->result();$news2 = $news21[0];
        //$images= json_decode($news2->images);
        $images= json_decode($news->images);
        unset($images[$image_del]);
        $new_img = array();
        foreach($images as $image){
            $new_img[] = $image;
        }
        $images1= json_encode($new_img, FALSE);
        $this->Scope->update('news',array('images'=>$images1),array('id'=>$id));
        foreach($new_img as $x => $image){
            echo '<div class="col-sm-4 col-xs-4" data-tag="'.$x.'d">
                    <article class="image-thumb">
                            <a class="image">
                                <img src=" '.base_url().$image->image.'">
                                    <input type="text" class="form-control" id="oldcomment['.$x.']" name="oldcomment['.$x.']" value="'.$image->comment.'" style="width: 190px;">
                            </a>
                            <div class="image-options">
                                <a href="#" class="delete" id="del-sel" data-id="'.$x.'"><i class="entypo-cancel"></i></a>
                            </div>
                    </article>
                </div>';
        }
    }
        
    public function edit($id){
        $this->Scope->check_view_actions('3','news', 'edit','');
        $news1 = $this->db->query('SELECT * FROM news where id = ' . $id .'')->result(); 
        $news  = $this->data['news'] = $news1[0];
              
         /*
         echo "<pre>";
         print_r($news);
         echo "</pre>";
         */
        // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script> '
            . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
            . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
            . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
            . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.css">'
            .'<script src="'.base_url().'data/admin/js/inputtags/jquery.tagsinput.js"></script>'
            //.'<script src="'.base_url().'data/admin/js/inputtags/js/app.js"></script>'
            //. '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
            . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
            . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
            . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
                . '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
               // .'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
                .'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
                .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        /////save side
        $data = $this->input->post();         
        if(!empty($data)){
            /*
             echo "<pre>";
             print_r($data);
             echo "<pre>";
             */
           // $save_array = array();
           
            if(isset($data['images_watermark']) && $data['images_watermark'] == '1'){$images_watermark = '1';}else{$images_watermark = '';}
            if(isset($data['poster_watermark']) && $data['poster_watermark'] == '1'){$poster_watermark = '1';}else{$poster_watermark = '';}
            $poster = $this->poster_upload($poster_watermark);
            //$images = json_encode($this->images_post($images_watermark));
           // if(!isset($data['img_url'])){$save_array['img_url'] = '';}else{$save_array['img_url'] = $data['img_url'];}
            if(!empty($poster)){$save_array['img_url'] = $poster['large'];$save_array['thumb_url'] = $poster['thumb'];}
            //if(!empty($images)){$save_array['images'] = $images;}
                 
           // unset($save_array['poster_watermark']);
                
            $images_new = $this->images_post($images_watermark);
            $images = json_decode($news->images,NULL);
            foreach($images as $x => $image){
                $images[$x]->comment=$data['oldcomment'][$x];
            }
             
            if(!is_array($images_new)){
                $images_new = array();
            }
            if(!is_array($images)){
                $images = array();
            }
            
            $images = array_merge($images,$images_new);
            if(!empty($images)){$save_array['images'] = json_encode($images, TRUE);}
            
            unset($save_array['images_watermark']);
                //if(!isset($data['content'])){$save_array['topic'] = '';}else{$save_array['topic'] = $data['content'];}
                $save_array['modified_date'] = date("Y-m-d H:i:s");
                $save_array['modified_user'] = $this->session->userdata('admin')->id;
                //$groups  = $this->db->query('SELECT * FROM groups  where post_link !=""')->result();
                if(!isset($data['newdate'])){$save_array['newdate'] = '';}else{$save_array['newdate'] = date('Y-m-d',strtotime($data['newdate']));}
                if(!isset($data['title'])){$save_array['title'] = '';}else{$save_array['title'] = $data['title'];}
                if(!isset($data['desc'])){$save_array['desc'] = '';}else{$save_array['desc'] = $data['desc'];}
                
                $this->Scope->update('news',$save_array,array('id'=>$id));                
                //echo $this->db->last_query();
                $news_detail_data = array();
                $news_detail_data['new_id']  = $id;
    
                               
    
                $this->session->set_flashdata('good', 'Updated successfully');
                $this->session->keep_flashdata('good');
                redirect(base_url().'admin/news');               
                	
                $data = array('images_watermark'=>$this->input->post('images_watermark'),'poster_watermark'=>$this->input->post('poster_watermark'),'title'=>$this->input->post('title'),'subtitle'=>$this->input->post('subtitle'),'slider'=>$this->input->post('slider'),'img_comment'=>$this->input->post('img_comment'),'content'=>$this->input->post('content'),'meta_keywords'=>$this->input->post('meta_keywords'),'iframe'=>$this->input->post('iframe'));
                $this->data['data'] = $data;
        }else{
            $data = array('title'=>'','poster_watermark'=>'','images_watermark'=>'','subtitle'=>'','slider'=>'','img_comment'=>'','content'=>'','meta_keywords'=>'','iframe'=>'');
            $this->data['data'] = $data;
        }
        $this->data['page'] = "/admin/news/edit";
        $this->load->view("/admin/layout", $this->data);
    }
 
    public function listFolders($dir)
    {
    	$dh = scandir($dir);
    	$return = array();
    
    	foreach ($dh as $folder) {
    		if ($folder != '.' && $folder != '..') {
    			if (is_dir($dir . '/' . $folder)) {
    				$return[] = array($folder => listFolders($dir . '/' . $folder));
    			} else {
    				$return[] = $folder;
    			}
    		}
    	}
    	return $return;
    }
    public function delete($id){
        if(!is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/news');
        }
        $new1 = $this->data['new'] = $this->db->query('SELECT * FROM news where id = ' . $id .'')->result();
        $new = $new1[0];
        if(empty($new)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/news');
        }
        if($this->Scope->check_view_actions('2','news','delete','') == 1){
            $this->Scope->delete_cond('news_detail', array('new_id'=>$id));
            $this->Scope->delete('news', $id);
            $this->session->set_flashdata('good', 'Delete Done');
            $this->session->keep_flashdata('good');
            redirect(base_url().'admin/news');
        }else{
            $this->session->set_flashdata('error', 'Error in deleting');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/news');
        }
    }
}