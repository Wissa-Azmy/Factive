<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->helper('form','cookie');
        $this->load->library('form_builder');
    }
    public function index($perpage=null){
        $this->Scope->check_view_actions('3','users', 'view','');
      
        $sql='SELECT *  
                FROM users WHERE active=1 ORDER BY id DESC ';
        $searchresults1 = $this->db->query($sql)->result();
        $this -> load -> library('pagination');
        	
        if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
        	$perpage = $_GET['perpage'];
        } else if($perpage != null){
        	$perpage = $perpage;
        } else{
        	$perpage = 20;
        }
        
         
        if(isset($_GET['perpage'])){
        	$sel = $_GET['perpage'];
        }
        else if($perpage != null){
        	$sel = $perpage;
        }
        else{
        	$sel = -1;
        }
        
        $config['base_url'] = base_url() . 'admin/users/index/'.$perpage.'/';
        $config['total_rows'] = count($searchresults1);
       // $config['first_url'] = base_url() . 'admin/users/index';
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
      
        $config['full_tag_open'] = '<div id="paging">';
        $config['full_tag_close'] = '</div>';
        $config['cur_tag_open'] = '<b>';
        $config['cur_tag_close'] = '</b>';
        $config['first_link'] =  "";
        $config['last_link'] =  "";        
        //$config['page_query_string'] = TRUE;
        //$config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['suffix'] = '?'.http_build_query($_GET, '', "&");
       // $config['query_string_segment'] = 'per_page'.$perpage;
        $this -> pagination -> initialize($config);
        
        if ($this -> uri -> segment(5)) {
        	 $sql = $sql ." LIMIT ".$this -> uri -> segment(5).",".$config['per_page'] ;
        }else{
        	$sql = $sql ." LIMIT ".$config['per_page'];
        }
       
       // echo "hghgh".$this -> uri -> segment(5).$config['per_page'];
        //$this -> db -> limit($config['per_page'], $this -> uri -> segment(4));
        $query  = $this->db->query($sql)->result();
        //echo $this ->db -> last_query();
        $this->data['users'] = $query;
        $this->data['page'] = "/admin/users/index";
        $this->load->view("/admin/layout", $this->data);
    }  
    
    public function deactivedusers($perpage=null){
        $this->Scope->check_view_actions('3','users', 'view','');
    
        $sql='SELECT *
                FROM users WHERE active=0 ORDER BY id DESC ';
        $searchresults1 = $this->db->query($sql)->result();;
        $this -> load -> library('pagination');
         
        if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
            $perpage = $_GET['perpage'];
        } else if($perpage != null){
            $perpage = $perpage;
        } else{
            $perpage = 20;
        }
    
         
        if(isset($_GET['perpage'])){
            $sel = $_GET['perpage'];
        }
        else if($perpage != null){
            $sel = $perpage;
        }
        else{
            $sel = -1;
        }
    
        $config['base_url'] = base_url() . 'admin/users/deactivedusers/'.$perpage.'/';
        $config['total_rows'] = count($searchresults1);
        // $config['first_url'] = base_url() . 'admin/users/index';
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
    
        $config['full_tag_open'] = '<div id="paging">';
        $config['full_tag_close'] = '</div>';
        $config['cur_tag_open'] = '<b>';
        $config['cur_tag_close'] = '</b>';
        $config['first_link'] =  "";
        $config['last_link'] =  "";
        //$config['page_query_string'] = TRUE;
        //$config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['suffix'] = '?'.http_build_query($_GET, '', "&");
        // $config['query_string_segment'] = 'per_page'.$perpage;
        $this -> pagination -> initialize($config);
    
        if ($this -> uri -> segment(5)) {
            $sql = $sql ." LIMIT ".$this -> uri -> segment(5).",".$config['per_page'] ;
        }else{
            $sql = $sql ." LIMIT ".$config['per_page'];
        }
         
        // echo "hghgh".$this -> uri -> segment(5).$config['per_page'];
        //$this -> db -> limit($config['per_page'], $this -> uri -> segment(4));
        $query  = $this->db->query($sql)->result();
        //echo $this ->db -> last_query();
        $this->data['users'] = $query;
        $this->data['page'] = "/admin/users/deactived.php";
        $this->load->view("/admin/layout", $this->data);
    }  
    public function view($id=null){
        if(!isset($id) | !is_numeric($id)){
            redirect(base_url().'admin');
        }
        $query  = $this->db->query('SELECT *  
                FROM users   where users.id = '.$id)->result();
        if(empty($query)){
            redirect(base_url().'admin');
        }
        
        
        $country_id=$query[0]->country_id;
        $country  = $this->db->query('SELECT *
                FROM countries   where id = '.$country_id)->result();
        
        $this->data['country'] = $country[0]->desc_en;
        $this->data['users'] = $query;
        $this->data['page'] = "/admin/users/view";
        $this->load->view("/admin/layout", $this->data);
    }     
    public function edit($id=null){
        if($this->session->userdata('admin')->id != $id){
            $this->Scope->check_view_actions('3','users', 'edit','');
        }
        if(!isset($id) | !is_numeric($id)){
        	$this->session->set_flashdata('error', 'There is some thing wrong in this link..');
        	$this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        $query  = $this->db->query('SELECT *   
                FROM users where users.id = '.$id)->result();
        if(empty($query)){
        	$this->session->set_flashdata('error', 'There is some thing wrong in this link..');
        	$this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        $this->data['user'] = $user = $query[0];
        
       
        /////save side
        $user_new_info = $this->input->post();
        if(!empty($user_new_info)){
        
            //echo "active".$user_new_info['active'];
            if(isset($user_new_info['active']) && $user_new_info['active'] == 'on'){$user_new_info['active'] = '1';}else{$user_new_info['active'] = '0';}
            //$user_new_info['last_update'] = date("Y-m-d H:i:s");
            $pass = $this->input->post("password");
            if(!empty($pass)){
                $user_new_info['password'] = md5($pass);
            }else{
                unset($user_new_info['password']);
            }
            
            $this->Scope->update('users',$user_new_info,array('id'=>$user->id));
            $this->session->set_flashdata('good', 'Updated successfully');
            $this->session->keep_flashdata('good');
        }
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script>'
                . '<script src="'.base_url().'data/admin/js/ckeditor/ckeditor.js"></script>'
                . '<script src="'.base_url().'data/admin/js/ckeditor/adapters/jquery.js"></script>'
                . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
                . '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/bootstrap-tagsinput.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
                . '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
                . '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">'
                . '<script src="'.base_url().'data/admin/js/fileinput.js"></script>';
        $this->data['page'] = "/admin/users/edit";
        $this->load->view("/admin/layout", $this->data);
    }    
    public function activate($id=null){
        if($this->session->userdata('admin')->id != $id){
            $this->Scope->check_view_actions('3','users', 'edit','');
        }
        if(!isset($id) | !is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        $query  = $this->db->query('SELECT *
                FROM users where users.id = '.$id)->result();
        if(empty($query)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
         
            $user_new_info['active'] = '1';          
    
            $this->Scope->update('users',$user_new_info,array('id'=>$id));
           // echo $this->db->last_query();
            $this->session->set_flashdata('good', 'Activated successfully');
           redirect(base_url().'admin/users/deactivedusers');
        
    }
    public function deactivate($id=null){
        if($this->session->userdata('admin')->id != $id){
            $this->Scope->check_view_actions('3','users', 'edit','');
        }
        if(!isset($id) | !is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        $query  = $this->db->query('SELECT *
                FROM users where users.id = '.$id)->result();
        if(empty($query)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
         
        $user_new_info['active'] = '0';
    
        $this->Scope->update('users',$user_new_info,array('id'=>$id));
        // echo $this->db->last_query();
        $this->session->set_flashdata('good', 'Deactivated successfully');
        redirect(base_url().'admin/users');
    
    }
     
    public function delete($id){
        if(!is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/users');
        }
        $user1 = $this->data['user'] = $this->db->query('SELECT * FROM users where id = ' . $id .'')->result();$user = $user1[0];
        if(empty($user)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/users');
        }
        if($this->Scope->check_view_actions('2','users','delete','') == 1){
            $this->Scope->delete('users', $id);
            $this->session->set_flashdata('good', 'Delete Done');
            $this->session->keep_flashdata('good');
            redirect(base_url().'admin/users');
        }else{
            $this->session->set_flashdata('error', 'Error in deleting');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin/users');
        }
    }  
    
    public function userreportform(){
        // $this->data['sections']= $this->get_sections_ac();
        $this->data['send_to_footer'] =  '<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/moment.js"></script>'
.'<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">'
.'<script type="text/javascript" src="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.js"></script>'
 .'<link rel="stylesheet" type="text/css" href="'.base_url().'data/admin/js/daterangepickersingle/daterangepicker.css" /> ';
        $this->data['page'] = "/admin/users/reportform";
        $this->load->view("/admin/layout", $this->data);
    }

    public function userreport(){        
        $this->Scope->check_view_actions('3','users', 'view','');
       
        if (isset($_POST['daterange']) && !empty($_POST['daterange'])) {
            $daterange = explode('-', $_POST['daterange']);
            //$start_date = date('Y-m-d H:i:s',strtotime($daterange['0']));
            //$end_date = date('Y-m-d H:i:s',strtotime($daterange['1']));
            $start_date = date('Y-m-d',strtotime($daterange['0']));
            $end_date = date('Y-m-d',strtotime($daterange['1']));
           
        }
       
        $countarr=array();
        $file= fopen(FCPATH . "data/admin/js/reports/chart_user/Column3D.xml", "w");
        $_xml ="<chart caption='Users Chart' xAxisName='Date' yAxisName='number of Users subscribed' showValues='1' decimals='0' formatNumberScale='0.5'>\r\n";
       
        while ($start_date<=$end_date) {
            $sql='SELECT COUNT(*) as mycount FROM users INNER JOIN countries ON countries.id=users.country_id WHERE active=1 ';
            $sql .= ' AND users.register_date >=  "'.$start_date.' 00:00:00" AND users.register_date <=  "'.$start_date.' 23:59:59" ';
            //echo $sql."<br />";
            $usercount= $this->db->query($sql)->result();
           
            if ($usercount) {
                $countarr[$start_date]=$usercount[0]->mycount;
                $_xml .=" <set label='".$start_date."' value='".$usercount[0]->mycount."' />\r\n";
            }

            //$start_date=strtotime($start_date)+86400;
            $start_date=strtotime("+1 day", strtotime($start_date));
            $start_date=date('Y-m-d', $start_date);        
        }
        
        //echo " from ".$from;
        $_xml .=" </chart>";
        //echo $_xml;
        fwrite($file, $_xml);
        fclose($file);
        $this->data['tableArray'] = $countarr;
        
        $this->data['starting_date'] = $start_date;
        $this->data['ending_date'] = $end_date;
        $this->data['title'] = "Users subscribed Repot";
        
        $this->data['daterange'] = $_POST['daterange'];
        $this->data['page'] = "/admin/users/userreport";
        $this->load->view("/admin/layout", $this->data);
    }
    
    public function userreportdetail(){
        $this->Scope->check_view_actions('3','users', 'view','');        
        $sql='SELECT users.*, countries.desc_en FROM users INNER JOIN countries ON countries.id=users.country_id WHERE active=1 ';
        if (isset($_POST['daterange']) && !empty($_POST['daterange'])) {
            $daterange = explode('-', $_POST['daterange']);
            $start_date = date('Y-m-d H:i:s',strtotime($daterange['0']));
            $end_date = date('Y-m-d H:i:s',strtotime($daterange['1']));
            $sql .= ' AND users.register_date >=  "'.$start_date.'" AND  users.register_date <=  "'.$end_date.'"  ';
        }
        $sql .= ' ORDER BY id DESC ';
         
        $query  = $this->db->query($sql)->result();
        //echo $this ->db -> last_query();
        $this->data['users'] = $query;
        $this->data['daterange'] = $_POST['daterange'];
        $this->data['page'] = "/admin/users/reportdetail";
        $this->load->view("/admin/layout", $this->data);
    }
    
    public function printuserreportdetail(){
        $this->Scope->check_view_actions('3','users', 'view','');
        $this->load->helper(array('dompdf', 'file'));
        
        $sql='SELECT users.*, countries.desc_en FROM users INNER JOIN countries ON countries.id=users.country_id WHERE active=1 ';
        if (isset($_POST['daterange']) && !empty($_POST['daterange'])) {
            $daterange = explode('-', $_POST['daterange']);
            $start_date = date('Y-m-d H:i:s',strtotime($daterange['0']));
            $end_date = date('Y-m-d H:i:s',strtotime($daterange['1']));
            $sql .= ' AND users.register_date >=  "'.$start_date.'" AND  users.register_date <=  "'.$end_date.'"  ';
        }
        $sql .= ' ORDER BY id DESC ';
         
        $query  = $this->db->query($sql)->result();
        //echo $this ->db -> last_query();
        $this->data['users'] = $query;
        $this->data['daterange'] = $_POST['daterange'];
        //$this->data['page'] = "/admin/users/reportdetail";
        //$this->load->view("/admin/layout", $this->data);
        $html=$this->load->view('/admin/users/printreportdetail', $this->data, true);
        //echo $html;
        $data = pdf_create($html, '', false);
        // write_file(FCPATH . 'togger/third_party/payment.pdf', $data);
        
        file_put_contents(FCPATH . 'data/admin/js/reports/users.pdf', $data);
        //if you want to write it to disk and/or send it as an attachment
        $file = FCPATH . 'data/admin/js/reports/users.pdf';
        $filename = "users.pdf";
        
        header('Content-type: application/pdf');
        header('Content-Disposition: inline; filename="' . $filename . '"');
        header('Content-Transfer-Encoding: binary');
        header('Content-Length: ' . filesize($file));
        header('Accept-Ranges: bytes');        
        @readfile($file);
        
        exit();
    }
    
}