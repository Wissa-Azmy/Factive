<?php

/*
 * @filename category.php
 * @path togger/controllers/admin/category.php
 * @url BASEURL/index.php/admin/category
 * @description Let's you manage all categories from the backend.
*/

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Category extends CI_Controller {
    /*
    * construct
    *
    * class constructor
    *
    * @param no param
    */
	public function __construct() {
		parent::__construct();
		$this -> load -> model('category_model');
		
	}
    /*
    * index function
    *
    * list categories page
    *
    * @param int $perpage
    */
	public function index($perpage=null) {
	
		
		/* end of check view permission*/
        $name = null;$name_arabic = null;$name_french = null;$name_german = null;$p_id="-1";
         $newpage = false;
	    if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
            $perpage = $_GET['perpage'];
        }
        else if($perpage != null){
            $perpage = $perpage;
        }
        else{
            $perpage = 20;
            $newpage = true;
        }
        
        if (isset($_POST['name'])) { 
			$newpage = false;
			$name = $_POST['name'];
			$p_id = $_POST['p_id'];
            
			$this -> session -> set_userdata(array('name' => $_POST['name']
			,'p_id' => $_POST['p_id']));
		}
		else if($newpage == true){
		    $name ="";;$p_id="-1";

		   		    
		}else{
		    $name =$this -> session -> userdata('name');		   
		    $p_id =$this -> session -> userdata('p_id');
		}
        $like = "";
        if ($name != "" && $name != null) { 
			    $like = "name LIKE '%" . $this->db->escape_str($name) . "%' ";			    
			    
		}
	
		if ($p_id != "" && $p_id != null && $p_id != "-1") { 
		 		if($like != ""){
			        $like .= " and ";
		        }
			    $like .= "parent_id = " . $p_id;			    
			    
		}
       
        
        
        
		$sort = 'name';
		//load view
		if ($like != '') {
				 
            $searchresults1 = $this -> category_model -> get(null, $like, $sort, 'asc');
		}else{
            $searchresults1 = $this -> category_model -> get(null, null, $sort, 'asc');
        }
        $this -> load -> library('pagination');           
             if(isset($_GET['perpage'])){
                 $sel = $_GET['perpage'];
             }else if($perpage != null){
                 $sel = $perpage;
             }else{
                  $sel = -1;
             }
             
			$config['base_url'] = base_url() . '/admin/category/index/'.$perpage.'/';
			$config['total_rows'] = count($searchresults1);
			$config['per_page'] = $perpage;
			$config['uri_segment'] = 5;
			$config['full_tag_open'] = '<div id="paging">';
			$config['full_tag_close'] = '</div>';
			$config['cur_tag_open'] = '<b>';
			$config['cur_tag_close'] = '</b>';
			$config['first_link'] = 'First';
			$config['last_link'] = 'Last';
			$config['page_query_string'] = FALSE;
			$this -> pagination -> initialize($config);

		if ($like != '') {
				 
            $categories = $this -> category_model -> get(null, $like, $sort, 'asc' ,$config['per_page'], $this -> uri -> segment(5));
		}else{
            $categories = $this -> category_model -> get(null, null, $sort, 'asc', $config['per_page'], $this -> uri -> segment(5));
        }
		//$categories = $this -> category_model -> get(null, null, $sort, 'asc');
		foreach ($categories as $cat) {
			$par = array();
			$par = $this -> category_model -> get(null, array('id' => $cat -> parent_id));
			if (count($par) > 0) {
				$cat -> parent = $par[0] -> name;
			} else {
				$cat -> parent = '';
			}
		}
		$this->data['tableArray'] = $categories;
		$this->data['newpage'] = $newpage;
		$this->data['p_id'] = $p_id;
		
		$this->data['name'] = $name;
		$this->data['per_page'] = $perpage;
		$this->data['title'] = "Category";
		$this->data['page'] = "/admin/category";
		$this->load->view("/admin/layout", $this->data);
	}
    /*
    * add function
    *
    * add category page
    *
    * @param int id = category id
    */
	public function add($id = null) {
	
		
		/* end of check view permission*/
		$editCategory = array();
		if ($id != '-1' && $id != null) {
			$editCategory = $this -> category_model -> get(null, array('id' => $id));
		}
		//load view
		$this->data['editCategory'] = $editCategory;
		
		if (count($editCategory) > 0) {
			 $tit = 'Edit Category';$ditcatId = $editCategory[0]->parent_id;
		} else {
			$tit = 'Add Category';$ditcatId ='-1';
		}
		
			if (count($editCategory) > 0) {
			    $this->data['path'] = $this -> EditOldPath($id);
			    $catname ="";
					    $cate = $this -> category_model -> get(null,array('id'=>$editCategory[0] -> id));
					    if(count($cate)>0){
					        
					        $catname = $cate[0]->name;
                    		
					    }
					    $this->data['catname'] =$catname;
		    } else {
				$this->data['path'] = "";
			}
		
		//$this->data['selectCat']= $this->CategoryList($ditcatId);
		$this->data['title'] = $tit;
		
		$this->data['page'] = "/admin/addCategory";
		$this->load->view("/admin/layout", $this->data);
		
	}
    /*
    * hasChild function
    *
    * return number of childs in  parent id parameter
    *
    * @param int parent_id = parent id of category
    */
	function hasChild($parent_id) {
		return count($this -> category_model -> get(null, array('parent_id' => $parent_id)));
	}
	/*
    * CategoryTree function
    *
    * return drop down of all categories
    *
    * @param string list= it will be output drop down string  
    * @param int parent= parent id of category
    * @param string append= underscore determine category level
    * @param int selCatId = category id
    * @param int counter= counter of level to display only 4 level of category
    */
	function CategoryTree($list, $parent, $append, $selCatId, $counter = 0) {
	    
		$sel = '';
		if ($selCatId != '-1' && $selCatId == $parent -> id) { $sel = 'selected="selected"';
		}
		
		//Check lang
		
			$catname1 = $parent -> name;
		
		//
		$list = '<option value="' . $parent -> id . '" ' . $sel . '>' . $append . $catname1 . '</option>';
		if ($this -> hasChild($parent -> id))// check if the id has a child
		{
		    $counter++;
			$append .= "_ ";
			$red = $this -> category_model -> get(null, array('parent_id' => $parent -> id));
			if($counter < 4){
    			foreach ($red as $re) {
    				$list .= $this -> CategoryTree($list, $re, $append, $selCatId, $counter);
    			}
			}
			//$list .= "</ul>";
		}

		return $list;
	}
    /*
    * CategoryList function
    *
    * return category path for add and edit category page
    *
    * @param int selCatId = category id
    */
	function CategoryList($selCatId) {
		$list = "";

		$result = $this -> category_model -> get(null, 'parent_id IS NULL');
		$mainlist = "";
		foreach ($result as $re) {
			$mainlist .= $this -> CategoryTree($list, $re, $append = '', $selCatId);
		}
		$list .= "";
		return $mainlist;
	}
	/*
    * viewSubCategories function
    *
    * return category drop down list for add and edit category page
    *
    * @param bo param
    */
    public function viewSubCategories() {
		$conditions = array("parent_id" => $_POST['CatVal']);

		$parents = $this -> category_model -> get(null, $conditions);

		//echo '<label for="' . $_POST['controlID'] . '" class="addProduct">Sub Category</label>';
		
        echo '<select size="10" name="' . $_POST['controlID'] . '" class="mailform" id="' . $_POST['controlID'] . '" 
        style="width:160px;float:left">';
		foreach ($parents as $pa) {
			echo '
						<option value="' . $pa -> id . '">' . $pa -> name . '</option>';
		}
		echo '</select>';
		//$this->data['subcategories'] = $parents;
		//$this->data['controlID'] = $_POST['controlID'];
	}
    /*
    * insert function
    *
    * insert add  form data 
    *
    * @param no param
    */
	public function insert() {
		$arr = $_POST;
		//echo "parent: ".$arr['parent_id'] ;
		//exit();
		echo "<pre>";
		print_r($arr);
		echo "</pre>";
    	if (!empty($arr['data']['Product']['subCategory2'])) {
				$arr['parent_id'] = $arr['subCategory2'];
					      
		 } elseif (!empty($arr['data']['Product']['subCategory1'])) {
				$arr['parent_id'] = $arr['subCategory1'];
					       
		 } elseif (!empty($arr['parent_id'])) {
					  $arr['parent_id'] = $arr['parent_id'];
					      
		}
		       unset($arr['data']);
		       echo "<pre>";
		       print_r($arr);
		       echo "</pre>";
		      // unset($arr['subCategory2']);
		      // unset($arr['subCategory3']);
		
		if ($arr['id'] == '-1') {
			$id = $arr['id'];
			unset($arr['id']);
			if (count($this -> category_model -> get(null, array('name' => $arr['name']))) > 0) {
				$this->data['warning'] = 'The Category could not be saved. Because it exist';
			} else {
				$arr['creation_date'] = date('Y-m-d H:i:s');
				$arr['creation_user'] = $this -> session -> userdata('admin_userid');
				$arr['modified_date'] = date('Y-m-d H:i:s');
				$arr['modified_user'] = $this -> session -> userdata('admin_userid');
				if ($this -> category_model -> insert($arr)) {
					$this->data['success'] = 'The Category has been saved';
				} else {

					$this->data['error'] = 'Error in Add Category';

				}
				
			}
			
		} else {
			$id = $arr['id'];
			unset($arr['id']);
			//$catcount=$this -> category_model -> get(null, array('id =' => $id));
			if (count($this -> category_model -> get(null, array('name' => $arr['name'], 'id <>' => $id))) > 0) {
				$this->data['warning'] = 'The Category could not be edit. Because new data exist';
			} else {
				
				/*
				if (empty($arr['parent_id']))echo "parent empty";
						
				if (empty($arr['parent_id']) AND ($arr['parent_id']==$id)){
					$arr['parent_id']=Null;
				}
				*/
				if ($arr['parent_id']==0) {
					$arr['parent_id']=NULL;
				}
				
				$arr['modified_date'] = date('Y-m-d H:i:s');
				$arr['modified_user'] = $this -> session -> userdata('admin_userid');
				if ($this -> category_model -> update($arr, array('id' => $id))) {
					$this->data['success'] = 'The Category has been edit';
				} else {

					$this->data['error'] = 'Error in Edit Category';

				}
				//echo $this->db->last_query();
			}
		}
		$editCategory = array();
		if ($id != '-1' && $id != null) {
			$editCategory = $this -> category_model -> get(null, array('id' => $id));
		}

		if (count($editCategory) > 0) {
			 $tit = 'Edit Category';$ditcatId = $editCategory[0]->parent_id;
		} else {
			$tit = 'Add Category';$ditcatId ='-1';
		}
		
		if (count($editCategory) > 0) {
		     
			    $this->data['path'] = $this -> EditOldPath($id);
			    $catname ="";
					    $cate = $this -> category_model -> get(null,array('id'=>$editCategory[0] -> id));
					    if(count($cate)>0){
					        
					        $catname = $cate[0]->name;
                    		
					    }
					    $this->data['catname'] =$catname;
		    } else {
				$this->data['path'] = "";
			}
		//$this->data['selectCat']= $this->CategoryList($ditcatId);
		$this->data['editCategory'] = $editCategory;
		$this->data['title'] = $tit;
		$this->data['menuActive'] = 2;
		$this->data['page'] = "/admin/addCategory";
		$this->load->view("/admin/layout", $this->data);
	}
    /*
    * delete function
    *
    * delete category item
    *
    * @param int id = category id
    */
	public function delete($id) {
		/*$arr = $this -> product_model -> get(null, array('category_id' => $id));
		if (count($arr) > 0) {
			$this->data['error'] = 'Error in Delete Category, Becasue It used in other items';
		} else {
		    */
			$this -> category_model -> delete(array('id' => $id));
			$this->data['success'] = 'The Category has been deleted';
		//}
		//redirect('/admin/category/deleted');
		$name = null;
         $newpage = false;
	    
            $perpage = 20;
            $newpage = true;
        
        
        if (isset($_POST['name'])) { 
			$newpage = false;
			$name = $_POST['name'];
            
			$this -> session -> set_userdata(array('name' => $_POST['name']));
		}
		else if($newpage == true){
		    $username ="";
		   		    
		}else{
		    $name =$this -> session -> userdata('name');
		}
        $like = "";
        if ($name != "" && $name != null) { 
			    $like = "name LIKE '%" . $this->db->escape_str($name) . "%' OR name_arabic LIKE '%" . $this->db->escape_str($name) . "%' 
                OR name_french LIKE '%" . $this->db->escape_str($name) . "%' OR name_german LIKE '%" . $this->db->escape_str($name) . "%' ";			    
			    
		}
       
        
        
        
		$sort = 'name';
		//load view
		if ($like != '') {
				 
            $searchresults1 = $this -> category_model -> get(null, $like, $sort, 'asc');
		}else{
            $searchresults1 = $this -> category_model -> get(null, null, $sort, 'asc');
        }
        $this -> load -> library('pagination');           
             if(isset($_GET['perpage'])){
                 $sel = $_GET['perpage'];
             }else if($perpage != null){
                 $sel = $perpage;
             }else{
                  $sel = -1;
             }
             
			$config['base_url'] = base_url() . 'index.php/admin/category/index/'.$perpage.'/';
			$config['total_rows'] = count($searchresults1);
			$config['per_page'] = $perpage;
			$config['uri_segment'] = 5;
			$config['full_tag_open'] = '<div id="paging">';
			$config['full_tag_close'] = '</div>';
			$config['cur_tag_open'] = '<b>';
			$config['cur_tag_close'] = '</b>';
			$config['first_link'] = 'First';
			$config['last_link'] = 'Last';
			$config['page_query_string'] = FALSE;
			$this -> pagination -> initialize($config);

		if ($like != '') {
				 
            $categories = $this -> category_model -> get(null, $like, $sort, 'asc' ,$config['per_page'], $this -> uri -> segment(5));
		}else{
            $categories = $this -> category_model -> get(null, null, $sort, 'asc', $config['per_page'], $this -> uri -> segment(5));
        }
		//$categories = $this -> category_model -> get(null, null, $sort, 'asc');
		foreach ($categories as $cat) {
			$par = array();
			$par = $this -> category_model -> get(null, array('id' => $cat -> parent_id));
			if (count($par) > 0) {
				$cat -> parent = $par[0] -> name;
			} else {
				$cat -> parent = '';
			}
		}
		$this->data['tableArray'] = $categories;
		$this->data['newpage'] = $newpage;
		$this->data['name'] = $name;
		$this->data['per_page'] = $perpage;
		$this->data['p_id'] = '';
		$this->data['title'] = "Category";
		//$this->data['menuActive'] = 2;		
		$this->data['page'] = "/admin/category";
        $this->load->view("/admin/layout", $this->data);
	}


    /*
    * hasParent function
    *
    * return number of parent of parent id category
    *
    * @param int parent_id = parent id of category
    */
   function hasParent($parent_id) {
		return count($this -> category_model -> get(null, array('id' => $parent_id)));
	}

     /*
    * CategoryTreeEditPath function
    *
    * return category path for edit category page
    *
    * @param string list = string append old result with new output
    * @param object parent = parent id of category
    */
	function CategoryTreeEditPath($list, $parent) {
		$newlist = "";
	
		$list = $parent -> id . ',';
		if ($this -> hasParent($parent -> parent_id))// check if the id has a child
		{
			$red = $this -> category_model -> get(null, array('id' => $parent -> parent_id));
			//$qry = mysql_query($sql);
			foreach ($red as $re) {
				$newlist = "";
				$newlist = $this -> CategoryTreeEditPath($list, $re) . $list;
			}
		} else {
			$newlist = $newlist . $list;
		}
		return $newlist;
	}
    /*
    * EditOldPath function
    *
    * return old path of category id
    *
    * @param int id = category id
    */
	public function EditOldPath($id) {
	    $list = "";
		$mainlist = '';
		$result = $this -> category_model -> get(null, array('id' => $id));
		foreach ($result as $re) {
		    $mainlist .= $this -> CategoryTreeEditPath($list, $re);
		}
		return $mainlist;
	}
}	
?>