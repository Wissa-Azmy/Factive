<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menus extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_builder');
    }
    public function index($perpage=null){
        $this->Scope->check_view_actions('3','menus', 'view','');  
        //$where[] =' menus_detail.lang=1';
        if(isset($_GET['keywords']) && !empty($_GET['keywords'])){
        	$keyword = $_GET['keywords'];
        	$keywords = explode(' ', $keyword);
        	$other='';
        	foreach($keywords as $keyword) {
        		$keys = trim($keyword);
        		if(!empty($keys)){
        			$other .= "or menus.name like '%$keys%'";
        		}
        	}
        	$where[] = '  '.substr($other, 2);
        	$this->data['keyword'] =  $_GET['keywords'];
        }else{
        	$this->data['keyword'] =  '';
        }
               
        if(isset($_GET['sel_id']) && is_numeric($_GET['sel_id']) && !empty($_GET['sel_id'])){
        	$id_id = $_GET['sel_id'];
        	$where[] = '  menus.id='.$id_id;
        	$this->data['sel_id'] =  $id_id;
        }else{
        	$this->data['sel_id'] =  '';
        }
               
          
        if(!empty($where)){
        	$where = ' WHERE '.implode(' AND ', $where);
        }else{
        	$where = '';
        }
        
        // $this->data['menudetails'] =  $this->db->query('SELECT language.*, menus_detail.cat_name FROM menus_detail INNER JOIN language ON menus_detail.lang=language.id where menus.cat_id=' . $id .'')->result();
        $sql='SELECT menus.* FROM menus '.$where.'  ORDER BY menus.id';
        $searchresults1 = $this->db->query($sql)->result();;
        $this -> load -> library('pagination');
        
        if(isset($_GET['limit']) && is_numeric($_GET['limit']) && !empty($_GET['limit'])){
        	$perpage = $_GET['limit'];
        } else if($perpage != null){
        	$perpage = $perpage;        	
        }else{
        	$perpage = 50;
        }
        
        /*
        if(isset($_GET['perpage']) && $_GET['perpage'] != "-1"){
        	$perpage = $_GET['perpage'];
        } else if($perpage != null){
        	$perpage = $perpage;
        } else{
        	$perpage = 20;
        }
        */
         
        if(isset($_GET['perpage'])){
        	$sel = $_GET['perpage'];
        }
        else if($perpage != null){
        	$sel = $perpage;
        }
        else{
        	$sel = -1;
        }
        
        $config['base_url'] = base_url() . 'admin/menus/index/'.$perpage.'/';
        $config['total_rows'] = count($searchresults1);
        // $config['first_url'] = base_url() . 'admin/users/index';
        $config['per_page'] = $perpage;
        $config['uri_segment'] = 5;
        
        $config['full_tag_open'] = '<div id="paging">';
        $config['full_tag_close'] = '</div>';
        $config['cur_tag_open'] = '<b>';
        $config['cur_tag_close'] = '</b>';
        $config['first_link'] =  "";
        $config['last_link'] =  "";
        //$config['page_query_string'] = TRUE;
        //$config['use_page_numbers'] = TRUE;
        $config['reuse_query_string'] = TRUE;
        $config['suffix'] = '?'.http_build_query($_GET, '', "&");
        // $config['query_string_segment'] = 'per_page'.$perpage;
        $this -> pagination -> initialize($config);
        
        if ($this -> uri -> segment(5)) {
        	$sql = $sql ." LIMIT ".$this -> uri -> segment(5).",".$config['per_page'] ;
        }else{
        	$sql = $sql ." LIMIT ".$config['per_page'];
        }
         
        // echo "hghgh".$this -> uri -> segment(5).$config['per_page'];
        //$this -> db -> limit($config['per_page'], $this -> uri -> segment(4));
        $query  = $this->db->query($sql)->result();
        
        
        
        
  
        $this->data['limit'] =  $perpage;
        //$query  = $this->db->query('SELECT * FROM menus'.$where.'  ORDER BY menus.id DESC LIMIT '.$limit.' ')->result();
        $this->data['menus'] = $query;
        $this->data['page'] = "/admin/menus/index";
        $this->load->view("/admin/layout", $this->data);
    }    
    public function edit($id){
        $this->Scope->check_view_actions('3','menus', 'edit','');
        if(!is_numeric($id)){
             $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        
        $sel_sec1 = $this->db->query('SELECT * FROM menus where id = ' . $id .' ')->result();
        $sel_sec = $this->data['menu'] = $sel_sec1[0];
        if(empty($sel_sec)){
            $this->session->set_flashdata('error', 'There is something wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        
        if ($sel_sec->level==4) {
            $submenus4=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$sel_sec->parent_id)->result();
            $this->data['selmenu3'] =$sel_sec->parent_id;
            $this->data['submenus3']=  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$submenus4[0]->parent_id)->result();
            
            $submenus3=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$submenus4[0]->parent_id)->result();
            $this->data['selmenu2'] =$submenus3[0]->id;
            $this->data['submenus2'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$submenus3[0]->parent_id)->result();
            
            //$submenus2=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$submenus3[0]->parent_id)->result();
            $this->data['selmenu1'] =$submenus3[0]->parent_id;
            $this->data['submenus1'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id=0')->result();

        }elseif ($sel_sec->level==3){
           // $this->data['selmenu3'] =$sel_sec->id;
            $this->data['submenus3']=  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$sel_sec->parent_id)->result();
            
            $submenus3=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$sel_sec->parent_id)->result();
            $this->data['selmenu2'] =$submenus3[0]->id;
            $this->data['submenus2'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$submenus3[0]->parent_id)->result();
            
            $submenus2=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$submenus3[0]->parent_id)->result();
            $this->data['selmenu1'] =$submenus2[0]->id;
            $this->data['submenus1'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id=0')->result();
            
        }elseif ($sel_sec->level==2){
            //$this->data['selmenu3'] =$sel_sec->id;
            $this->data['submenus3']=  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$sel_sec->id)->result();
            // $submenus3=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$sel_sec->parent_id)->result();
            //$this->data['selmenu2'] =$sel_sec->id;
            $this->data['submenus2'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$sel_sec->parent_id)->result();
            
            $submenus2=  $this->db->query('SELECT menus.* FROM menus where menus.id='.$sel_sec->parent_id)->result();
            $this->data['selmenu1'] =$submenus2[0]->id;
            $this->data['submenus1'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id=0')->result();
            
        }elseif ($sel_sec->level==1){           
            //$this->data['submenus2'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$sel_sec->id)->result();            
            //
            //$this->data['selmenu1'] =$sel_sec->id;
            $this->data['submenus1'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id=0')->result();
        }        
               
        $save_array = $this->input->post();
        if(!empty($save_array)){
             //$this->Scope->update('menus',$save_array,array('id'=>$id));            
            //Edit menu main Info
            $save_array['modified_date'] = date("Y-m-d H:i:s");
            
             		
    		if ($save_array['submenu3']) {
    		    $save_array['parent_id'] = $save_array['submenu3'];
    		    $save_array['level'] =4;
    		}elseif ($save_array['submenu2']) {
    		    $save_array['parent_id'] = $save_array['submenu2'];
    		    $save_array['level'] =3;
    		}elseif ($save_array['submenu1']) {
    		    $save_array['parent_id'] = $save_array['submenu1'];
    		    $save_array['level'] =2;
    		}else{
    		    $save_array['parent_id'] =0;
    		    $save_array['level'] =1;
    		}
    		
    		unset($save_array['submenu3']);
    		unset($save_array['submenu2']);
    		unset($save_array['submenu1']);
    		
            
    		if($_FILES['img_url']) {
    		    $poster = $this->poster_upload($id,'');
    		    /* if(!isset($data['img_url'])){
    		     $edit_array['img_url'] = '';}else{
    		     $edit_array['img_url'] = $data['img_url'];
    		    }*/
    		    if(!empty($poster)){
    		        $save_array['img'] = $poster['large'];
    		        //$edit_array['thumb_url'] = $poster['thumb'];
    		    }
    		   // $this->Scope->update('menus',$edit_array,array('id'=>$id));
    		    
    		}
    		
           // $save_arraymain['parent_id'] = $parent;
            $this->Scope->update('menus',$save_array,array('id'=>$id));
            //echo $this->db->last_query();
          // $this-> updatealldeptschild();
            //$this->db->insert('menus',$save_arraymain);
                              
            $this->session->set_flashdata('good', 'Save Done');
            $this->session->keep_flashdata('good');
            //redirect(base_url().'admin/menus');
        }
        $this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script>'
    			. '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
    			. '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
    			. '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
		    	. '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
    			. '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
    			. '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">';
        $this->data['page'] = "/admin/menus/edit";
        $this->load->view("/admin/layout", $this->data);
    } 
    
    public function add() {
    	$this->Scope->check_view_actions('3','menus', 'add','');
        $this->data['submenus1'] =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id=0')->result();
    	$save_array = $this->input->post();
    	if(!empty($save_array)){
    		//Add menu main Info    	    
    		$save_array['creation_date'] = date("Y-m-d H:i:s");
    		$save_array['creation_user'] = $this->session->userdata('admin')->id;
    	
    		if ($save_array['submenu3']) {
    		    $save_array['parent_id'] = $save_array['submenu3'];
    		    $save_array['level'] =4;
    		}elseif ($save_array['submenu2']) {
    		    $save_array['parent_id'] = $save_array['submenu2'];
    		    $save_array['level'] =3;
    		}elseif ($save_array['submenu1']) {
    		    $save_array['parent_id'] = $save_array['submenu1'];
    		    $save_array['level'] =2;
    		}else{
    		    $save_array['parent_id'] =0;
    		    $save_array['level'] =1;
    		}
    		
    		unset($save_array['submenu3']);
    		unset($save_array['submenu2']);
    		unset($save_array['submenu1']);
    		
    		//$save_array['parent_id'] = $parent;
    		//if ($save_array['parent_id']) {

    		    
        		$this->db->insert('menus',$save_array);
        		//echo $this->db->last_query();
        		$id  = $this->db->insert_id();
        		//$this-> updatealldeptschild();
        		    		
        		if($_FILES['img_url']) {
        		    $poster = $this->poster_upload($id,'');
        		   /* if(!isset($data['img_url'])){
        		        $edit_array['img_url'] = '';}else{
        		            $edit_array['img_url'] = $data['img_url'];
        		        }*/
        		    if(!empty($poster)){
        		       $edit_array['img'] = $poster['large'];
        		      //$edit_array['thumb_url'] = $poster['thumb'];
        		    }
        		    $this->Scope->update('menus',$edit_array,array('id'=>$id));
        		    //echo $this->db->last_query();    		    	
        		}
        		
        		$this->session->set_flashdata('good', 'Saving done');
        		$this->session->keep_flashdata('good');
    		
    		/*}else{
    		    $this->session->set_flashdata('error', 'You didn\'t select the menu');
    		    $this->session->keep_flashdata('error');
    		}*/
    		//echo $this->db->last_query();
    		
    		
    		//redirect(base_url().'admin/menus');
    	}
    	
    	$this->data['send_to_footer'] =  '<script src="'.base_url().'data/admin/js/wysihtml5/bootstrap-wysihtml5.js"></script>'
    			. '<script src="'.base_url().'data/admin/js/bootstrap-switch.min.js"></script>'
    			. '<script src="'.base_url().'data/admin/js/jquery.validate.min.js"></script>'
    			. '<script src="'.base_url().'data/admin/js/fileinput.js"></script>'
		    	. '<script src="'.base_url().'data/admin/js/select2/select2.min.js"></script>'
    			. '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2-bootstrap.css">'
    			. '<link rel="stylesheet" href="'.base_url().'data/admin/js/select2/select2.css">';
    	$this->data['page'] = "/admin/menus/add";
    	$this->load->view("/admin/layout", $this->data);
    }
    function poster_upload ($id,$watermark){
        if($_FILES['img_url']) {
             $full_img_path=$img_path = 'uploaded/menus/'.$id;
           // $full_img_path = $img_path.'/'.date('Y').'/'.date('m').'/'.date('d');
            @mkdir($full_img_path, 0777, true);
            @mkdir(str_replace('large', 'thumb', $full_img_path), 0777, true);
            $config['upload_path'] = $full_img_path;
            $config['allowed_types'] = '*';
            $config['max_size']      =   "5000";
            $config['max_width']     =   "1907";
            $config['max_height']    =   "1280";
            $config['encrypt_name']    =   TRUE;
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('img_url')){
                $this->load->library('image_lib');
                $data = array('upload_data' => $this->upload->data());    
                $this->data['data'] = $data;
                if($watermark == 1){
                    $this->watermark($data['upload_data']['file_name'],$full_img_path.'/');
                }
               // $thumb_path = $this->do_thumb($data['upload_data']['file_name'],$full_img_path.'/');
                //$return = array('large' => $full_img_path.'/'.$data['upload_data']['file_name'],'thumb'=>$thumb_path);
                $return = array('large' => $full_img_path.'/'.$data['upload_data']['file_name']);
                return $return;
            }else{    
                $data =    array('error' => $this->upload->display_errors());
                //print_r($data);exit;
            }
        }
    }
    public function sub_menu_ajax(){
        if(isset($_GET['menueid']) && is_numeric($_GET['menueid'])){
             
            $menus=$this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$_GET['menueid'])->result();
            //var_dump($categories);
           // $value = '<select class="form-control" name="menu_id">';
            $value = ' <option value=""></option>';
            foreach($menus as $menu){
                $value .= ' <option value="'.$menu->id.'">'.$menu->name.'</option>';
            }
           // $value .= '
               //     </select>';
            echo $value;
        }
    }  
  public function delete($id){
        if(!is_numeric($id)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        $menu1 = $this->data['menu'] = $this->db->query('SELECT * FROM menus where id = ' . $id .'')->result();
        $menu = $menu1[0];
        if(empty($menu)){
            $this->session->set_flashdata('error', 'There is some thing wrong in this link..');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
        if($this->Scope->check_view_actions('2','menus','delete','') == 1){
        	//$this->Scope->delete_cond('menus_detail', array('cat_id'=>$id));
            $this->Scope->delete('menus', $id);
            $this->session->set_flashdata('good', 'Delete Done');
            $this->session->keep_flashdata('good');
            redirect(base_url().'admin/menus');
        }else{
            $this->session->set_flashdata('error', 'Error in deleting');
            $this->session->keep_flashdata('error');
            redirect(base_url().'admin');
        }
    } 
  public function updatealldeptschild(){
      $menus =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id=0')->result();
      foreach($menus as $menu){            
            $numofchild=$this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$menu->id)-> num_rows();
           // echo $numofchild;
            $this->Scope->update('menus',array('child'=>$numofchild),array('id'=>$menu->id));
       }
    }
    
}