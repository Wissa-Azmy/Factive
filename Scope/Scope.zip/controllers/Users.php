<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once (APPPATH . 'core/MY_main.php');
class Users extends MY_main {

	
    public function __construct() {
        parent::__construct();  
        // in case you did not autoload the library
        $this->load->library('auth');
        $this -> load -> model('users_model');
        if ($this->auth->loggedin()) {
            // get current user id
            $userid = $this->auth->userid();
            if ($userid) {
                $userinfo = $this -> users_model -> getUserProfile($userid);
                $username = ucfirst($userinfo[0]['fname'] . " " . $userinfo[0]['lname']);
                $this -> session -> set_userdata(array('userid' => $userid,'username' => $username));
                //print_r($this->session->userdata()) ;
            }
        
        }
        
        ///////////////////////////////////////////////////////////////////////////
        if ($this -> session -> userdata('username') == "") {
           // $this -> session -> unset_userdata('site_userid');            
            if ($this -> session -> userdata('site_lang') == "") {
                $this -> session -> set_userdata('site_lang', 'english');                
            }
        }
        
        //check language session to load the lang file
        $site_lang = $this -> session -> userdata('site_lang');
        if ($site_lang) {
            $this -> lang -> load('site', $site_lang);         
        } else {
            $this -> lang -> load('site', 'english');           
        }    
        
        $this -> load -> library('email');
        $this -> config -> load('email');
        $this -> load -> library('form_validation');        
        // $config['upload_path'] = base_url('/uploaded/profile/');      
        $this -> load -> library('upload');
    }
    public function index(){  
        /*       
        if (!$this->auth->loggedin()) {
            redirect('users/login');
        }else{            
            // get current user id
            $userid = $this->auth->userid();
            echo 'Welcome to the super secret section, ' . $userid;   
            $this -> session -> set_userdata(array('userid' => $userid));
            print_r($this->session->userdata()) ;
        }
        */
        //$data['commonMessages'] = $this->loadMessages();               	
        //$data['page'] = 'home-view';      
        //$this -> load -> view('template/main_template', $data);        
    }
    public function login(){            
        if($this -> session -> userdata('userid')){
            redirect('home/userhome');
        }else {
            $email = $this -> input -> post('email');
            $pass = $this -> input -> post('password');
            if (isset($email) && isset($pass)) {            
                $data = $this -> users_model -> loginEmail($email, $pass);
                if ($data) {
                
                    $username = ucfirst($data[0]['fname'] . " " . $data[0]['lname']);
                    $userid = $data[0]['id'];
                   // $forcoins = $data[0]['forcoins'];
                    $remember = $this->input->post('remember') ? TRUE : FALSE;
                    $this->auth->login($userid, $remember);
                    
                    $user = array('username' => $username);
                    //$forcoin = array('forcoins' => $forcoins);
                    $userid = array('userid' => $userid);
                    
                    /*
                    $new_expiration = 60;//15 Minutes
                    //$this->session->sess_expiration =   $new_expiration ;
                    $this->config->set_item('sess_expiration', $new_expiration);
                    $this->config->set_item('sess_expire_on_close', true);
                    */                  
                    
                    $this -> session -> set_userdata($user);
                    $this -> session -> set_userdata($userid);
                    //$this -> session -> set_userdata($forcoin);
                    /*
                    $cookie = array(
                        'name'   => 'user_id',
                        'value'  => $userid,
                        'expire' => '60',
                        'secure' => FALSE
                    );
                    $this->input->set_cookie($cookie);
                    $this->input->set_cookie($userid);
                    */
                   // $this -> users_model -> updatecoins($data[0]['id']);
                    $this -> users_model -> last_login($data[0]['id']);                    
                    redirect(base_url('/home/userhome'));
                } else {            
                    $data['not_exist'] = true;                
                }
            }
            
            $data['page'] = 'login';
            $this -> load -> view('template/main_template', $data);
        }
        
    }
    public function forget() {
        
        $data['page'] = 'forget-pass';
        $this -> load -> view('template/main_template', $data);
    }
    
    public function forgetPassword() {
        $email = $this -> input -> post('email');
        //$email ='gggggggggggggg@';
        $data = $this -> users_model -> checkEmail($email);

        if ($data) {
            if ($data=='notactive') {
                
            }else{
                $this -> email -> set_newline("\r\n");
                $this -> email -> from('webmaster@ne-port.com', "NE City Service");
                $this -> email -> to($email);
                $this -> email -> subject("Password Reset");
                $this -> email -> message("
    			<!doctype html>
    			<html lang='en'>
    			<head>
    				<meta charset='UTF-8' />
    				<title>Reset</title>
    			</head>
    			<body style='font-family:verdana; font-size:13px;'>
    				Dear NE Citizen,<br />
    				Your password has been reset.<br />
    				Your new password is <b>" . $data . "</b><br />
    				Use it to check in <a href='" . base_url('/login') . "'>www.ne-port.com</a> and enjoy!
    				<br /><br />   
    			</body>
    			</html>
    			");
                $this -> email -> send();
            }
            //$id = $this -> session -> userdata('userid');
            //$this -> users_model -> changePassword($id, $data);
        
            $data_['page'] = 'forget-pass';
            $data_['new_pass'] = $data;
            $data_['email'] = $email;
            $this -> load -> view('template/main_template', $data_);
           
        } else {
       
            
            $data_['page'] = 'forget-pass';
            $data_['new_pass'] = false;
            $data_['email'] = $email;
            $this -> load -> view('template/main_template', $data_);
            // echo "Not exist";
        }
    }
    public function register() {
        if($this -> session -> userdata('userid')){
            redirect('home/userhome');
        }
        $fname = $this -> input -> post('fname');
        $lname = $this -> input -> post('lname');
        $email = $this -> input -> post('email');
        $password = $this -> input -> post('password');
        $confPassword = $this -> input -> post('confPassword');
        $dob_m = $this -> input -> post('month');
        $dob_d = $this -> input -> post('day');
        $dob_y = $this -> input -> post('year');
        $gender = $this -> input -> post('gender');
        $country = $this -> input -> post('country');   
        
        /*
         * 
         * echo "<pre>";
        print_r($this -> input -> post());
        echo "</pre>";      
        $this -> load -> library('form_validation');
        $this -> form_validation -> set_rules('password', 'Password', 'trim|required');
        //$this -> form_validation -> set_rules('conf-password', 'Password Confirmation', 'trim|required|matches[password]');
        $this -> form_validation -> set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
        */
        if (!empty($fname) AND !empty($lname) AND !empty($email) AND !empty($password) AND !empty($dob_m) AND !empty($dob_d) AND !empty($dob_y) AND !empty($gender) AND !empty($country)){
             
             if($password != $confPassword) {
        
                // reload Form Data
               // $data = $this -> reloadFormData();
        
                $data['showMessage'] = true;
                $data['type'] = 'Error';
                // Error or Success
                $data['messageToBeShow'] = $this->lang -> line('Yourpasswordsdonotmatch');
                $data['countries'] = $this -> users_model -> getcountryList();
                
                $data['page'] = 'register';
                $this -> load -> view('template/main_template', $data);
        
            } else {
                // checkEmailExistInUser
                if (!$this -> users_model -> checkEmailExistInUser($email)) {
                    // Email NOT Exist In User ExistInStoredMails
                    // So we will check about
                    /*
                     * Any email from astrazeneca.com "any saved domains" domain won't need activation
                     */
                    /*
                    $domain = substr(strrchr($email, "@"), 1);                   
                    $saveddomains=$this -> users_model ->getsaveddomains();
                    foreach ($saveddomains as $domainarr){
                        $newsaveddomain[]=$domainarr['domain'];
                    }
                    */
                    if ($this -> users_model -> checkEmailExistInStoredMails($email)) {
                     //if (in_array($domain,$newsaveddomain)) {
                        // Email in saved domains
                        $active = '1';                  
                    } else {
                        // Email NOT in saved domains
                        $active = '0';
                    }
                       //echo "active".$active;
                    
                    // insert user without avetar
                    $data = $this -> users_model -> registerNew($fname, $lname, $email, $password, $dob_m, $dob_d, $dob_y, $gender, $country, $active);
                   // echo $this->db->last_query();
                    $profile_pic = 'usr_' . $data;
                    //echo "profile_pic ".$profile_pic;
                    // var_dump(is_dir('uploaded/profile')); die;
                    $config['upload_path'] = 'uploaded/profile';
                    $config['allowed_types'] = 'gif|jpg|png|bmp|jpeg';
                    $config['file_name'] = $profile_pic;
                    $config['max_size'] = '1024';
                    //$config['max_width'] = '1024';
                    //$config['max_height'] = '1024';
                    $this -> load -> library('upload', $config);
                    $this -> upload -> initialize($config);
                   
                    if (!$this -> upload -> do_upload()) {
                       
                        if (!empty($_FILES['image']['name'])) {
        
                            //if (!empty($_FILES['userfile']['name'])) {
                            // upload image failed
                            // So delete inserted record because upload his image failed
                            $id = $data;
                            $this -> users_model -> deleteProfile($id);
        
                            // show errors to user
                            $error = array('error' => $this -> upload -> display_errors());
                            // reload Form Data
                            //$data2 = $this -> reloadFormData();
        
                            // ASSUME (its wrong) : if upload error : permitted size
                            //$data2 = $this->reloadFormData();
                            //$data2['error'] = $this->lang->line('UploadPermittedSize');
        
                            $data2['showMessage'] = true;
                            $data2['type'] = 'Error';
                            // Error or Success
                            $data2['messageToBeShow'] = $this->lang -> line('UploadPermittedSize'); ;
                            $data2['countries'] = $this -> users_model -> getcountryList();
                            $data2['page'] = 'register';
                            $this -> load -> view('template/main_template', $data2);
                            //$this -> load -> view('content/index', $data2);
                            //	} else {
                            // No file selected - set default image
                            //$profile_pic = "default";
                            // $data['userfile'] = "http://ne-port.net/uploaded/profile/default.jpg"
                            //$id = $data;
                            //$this -> users_model -> saveAvatarByID($id, 'default.jpg');
        
                        }else {
                            $id = $data;
                            $this -> users_model -> saveAvatarByID($id, "default.jpg");
        
                           // if ($active == '1' || $active == '0') {
                                // Email NOT in StoredMails
        
                                // TODO : Admin Email that will be notify by new resisted users
                                // ------------------
                                $this -> sendNewUserMailToAdmin('jsparo30@gmail.com');
                                $this -> sendNewUserMailToAdmin('aliaad@scope-adv.com');
                               // $this -> sendNewUserMailToAdmin('nehalm@scope-adv.com');
                                $this -> sendNewUserMailToAdmin('Noha.Zannoun@astrazeneca.com');
                                $this -> sendNewUserMailToAdmin('Diana.Maher@astrazeneca.com ');
                                // ------------------
        
                                // reload Form Data
                               // $data5 = $this -> reloadFormData();
        
                                $data5['showMessage'] = true;
                                $data5['type'] = 'Success';
                                // Error or Success
                                $data5['messageToBeShow'] = "Your access to <a href='". base_url('/')."'>". base_url('/')."</a> is pending approval. <br> We will notify you via email.";
                                //$data['messageToBeShow'] = $this->lang -> line('pendingapprove');
                                $data5['page'] = 'register';
                                $data5['countries'] = $this -> users_model -> getcountryList();
                                //$this -> load -> view('content/index', $data5);
                                $this -> load -> view('template/main_template', $data5);
                                //}else{
                                // Email in StoredMails
        
                                // ------------------
                                // send Email to $email
                                $this -> load -> library('email', $config);
                                $this -> email -> set_newline("\r\n");
                                $this -> email -> from('webmaster@ne-port.com', "NE City Service");
                                $this -> email -> to($email);
                                $this -> email -> subject("NE City");
                                //Welcoming The User
                                
                                if ($active == '1' ) {
                                    //Active user email message
                                    $this -> email -> message("
            						<!doctype html>
            						<html lang='en'>
            						<head>
            							<meta charset='UTF-8' />
            							<title>Reset</title>
            						</head>
            						<body style='font-family:verdana; font-size:13px;'>
            							Dear User, <br />
            							Your request to access <a href='". base_url('/')."'>". base_url('/')."</a> is being approval.<br />
                                    
                                    
            						</body>
            						</html>
            						");
                                }else{
                                    //Inactive user email message
                                        $this -> email -> message("
            						<!doctype html>
            						<html lang='en'>
            						<head>
            							<meta charset='UTF-8' />
            							<title>Reset</title>
            						</head>
            						<body style='font-family:verdana; font-size:13px;'>
            							Dear User, <br />
            							Your request to access <a href='". base_url('/')."'>". base_url('/')."</a> is pending approval. An email notification will be sent to you once your request has been reviewed.<br />
                
                
            						</body>
            						</html>
            						");
                                }
                                $this -> email -> send();
                                // ------------------
        
                                /*$data3['email'] = $email;
                                 $data3['page'] = 'register-success-view';
                                $this -> load -> view('content/index', $data3);*/
                           // }
        
                        }
        
                    } else {
        
                        // upload image success
                        // So update avatar field in user table
                        $id = $data;
                        $fileInfo = $this -> upload -> data();
                        $this -> users_model -> saveAvatarByID($id, $fileInfo['file_name']);
        
                       // if ($active == '1' || $active == '0') {
                            // Email NOT in StoredMails
        
                            // TODO : Admin Email that will be notify by new resisted users
                            // ------------------
                            $this -> sendNewUserMailToAdmin('jsparo30@gmail.com');
                            $this -> sendNewUserMailToAdmin('aliaad@scope-adv.com');
                            $this -> sendNewUserMailToAdmin('nehalm@scope-adv.com');
                            $this -> sendNewUserMailToAdmin('Noha.Zannoun@astrazeneca.com');
                            $this -> sendNewUserMailToAdmin('Diana.Maher@astrazeneca.com ');
                            // ------------------
        
                            // reload Form Data
                            //$data5 = $this -> reloadFormData();
        
                            $data5['showMessage'] = true;
                            $data5['type'] = 'Success';
                            // Error or Success
                            $data5['messageToBeShow'] = "Your access to <a href='". base_url('/')."'>". base_url('/')."</a> is pending approval. <br> We will notify you via email.";
                            //$data['messageToBeShow'] = $this->lang -> line('pendingapprove');
                            $data5['page'] = 'register';
                            //$this -> load -> view('content/index', $data5);
                            $this -> load -> view('template/main_template', $data5);
                            //}else{
                            // Email in StoredMails
        
                            // ------------------
                            // send Email to $email
                            $this -> load -> library('email', $config);
                            $this -> email -> set_newline("\r\n");
                            $this -> email -> from('webmaster@ne-port.com', "NE City Service");
                            $this -> email -> to($email);
                            $this -> email -> subject("Welcoming The User");
                            if ($active == '1' ) {
                                //Active user email message
                                $this -> email -> message("
            						<!doctype html>
            						<html lang='en'>
            						<head>
            							<meta charset='UTF-8' />
            							<title>Reset</title>
            						</head>
            						<body style='font-family:verdana; font-size:13px;'>
            							Dear User, <br />
            							Your request to access <a href='". base_url('/')."'>". base_url('/')."</a> is being approval.<br />
                            
                            
            						</body>
            						</html>
            						");
                            }else{
                                $this -> email -> message("
        						<!doctype html>
        						<html lang='en'>
        						<head>
        							<meta charset='UTF-8' />
        							<title>Reset</title>
        						</head>
        						<body style='font-family:verdana; font-size:13px;'>
        							Dear User, <br />
        							Your request to access <a href='". base_url('/')."'>". base_url('/')."</a> is pending approval. An email notification will be sent to you once your request has been reviewed.<br />
        						</body>
        						</html>
        						");
                            }
                            $this -> email -> send();
                            // ------------------        
                            /*$data3['email'] = $email;
                             $data3['page'] = 'register-success-view';
                            $this -> load -> view('content/index', $data3);*/
                        //}
        
                    }
                } else {
                    // Email Is Already Exist (Approved or Pending)
                    // reload Form Data
                   // $data5 = $this -> reloadFormData();
        
                    $data5['showMessage'] = true;
                    $data5['type'] = 'Error';
                    // Error or Success
                    //$data5['messageToBeShow'] = "This Email Is Already Exist";
                    $data5['messageToBeShow'] = $this->lang -> line('ThisEmailIsAlreadyExist');
                    $data5['page'] = 'register';
                    $data5['countries'] = $this -> users_model -> getcountryList();
                    //$this -> load -> view('content/index', $data5);
                    $this -> load -> view('template/main_template', $data5);
                    // ------------------
                    // send Email to $email
                    //$this -> load -> library('email', $config);
                   // ------------------
        
                }
        
            }
        }else{
            
            $data['page'] = 'register';
            $data['countries'] = $this -> users_model -> getcountryList();
           
            $this -> load -> view('template/main_template', $data);
        }
    
    }
    
    public function sendNewUserMailToAdmin($admin) {
        // send Email to ADMIN
        // ------------------
        //$this -> load -> library('email', $config);
        //return ;
        $this -> email -> set_newline("\r\n");
        $this -> email -> from('webmaster@ne-port.com', "NE City Service");
        $this -> email -> to($admin);
        $this -> email -> subject("New User");
        $this -> email -> message("
		<!doctype html>
		<html lang='en'>
		<head>
			<meta charset='UTF-8' />
			<title>Reset</title>
		</head>
		<body style='font-family:verdana; font-size:13px;'>
			There is new Registration Request ... <a href='". base_url('/')."admin' >See Email Requests</a><br />
			Your quick response is preferable!
		</body>
		</html>
		");
        $this -> email -> send();
        // ------------------
    }
    public function updateProfile() {
    
        // TODO validations
        if(!$this -> session -> userdata('userid')){
            redirect('home');
        }
        $id = $this -> session -> userdata('userid');
               
        if ($this -> input -> post()) {
                      
            $firstName = $this -> input -> post('fname');
            $lastName = $this -> input -> post('lname');
            $email = $this -> input -> post('email');
            //$country = $this -> input -> post('country');
            $dob_d = $this -> input -> post('day');
            $dob_m_id = $this -> input -> post('month');
            $dob_year = $this -> input -> post('year');
            $gender = $this -> input -> post('gender');
        
            $datareturn = $this -> users_model -> updateProfile($id, $firstName, $lastName, $dob_m_id, $dob_d, $dob_year, $gender);
            //echo $this->db->last_query();
            // update user name in the session
            // ----------------------
            $username = ucfirst($firstName . " " . $lastName);
            $user = array('username' => $username);
            $this -> session -> set_userdata($user);
            // ----------------------
        
            // TODO : validations
            // update avatar [if image is uploaded]
            // ----------------------
            
            if (!empty($_FILES['userfile']['name'])) {
                // File was selected for upload               
                //echo 'userfile';
                $avatar = $this -> input -> post('avatar');
                //$id = $this -> session -> userdata('userid');
        
                $config['file_name'] = 'usr_' . $id;
                $config['upload_path'] = 'uploaded/profile';
                $config['allowed_types'] = 'gif|jpg|png|bmp|jpeg';
                $config['max_size'] = '1024';
                //$config['max_width'] = '1024';
                //$config['max_height'] = '1024';
                $this -> load -> library('upload', $config);
                $this -> upload -> initialize($config);
        
                if (!$this -> upload -> do_upload()) {
                    // upload image failed
        
                    // reloadFormData
                    //$data = $this -> reloadFormData();
        
                    // show errors to user
                    $data['showMessage'] = true;
                    $data['type'] = 'Error';
                    // Error or Success
                    $data['messageToBeShow'] = $this -> upload -> display_errors();
                     $data['countries'] = $this -> users_model -> getcountryList();
                    // $data['page'] = 'updateprofile';
                    //$this -> load -> view('template/main_template', $data);
                } else {
                    // upload image success
        
                    // delete old uploaded file
                    /*
                    if($cover!="default.jpg"){
                        $file = 'uploaded/profile/' . $avatar;
                        //unlink($file);
                    }
                    */
                    // upload new uploaded file
                    $fileInfo = $this -> upload -> data();        
                    // save new Avatar into userProfile
                    $this -> users_model -> saveAvatarByID($id, $fileInfo['file_name']);
        
                    // navigate to Home
                   // redirect(base_url('/home/userhome'));
        
                }
                // ----------------------
            } else {
                // No file was selected for upload
        
                // navigate to Home
               // redirect(base_url('/home/userhome'));
            }
        }
        $userinfo = $this -> users_model -> getUserProfile($id);         
        $data['fname'] = $userinfo[0]['fname'];
        $data['lname'] = $userinfo[0]['lname'];
        $data['email'] = $userinfo[0]['email'];
        $data['month'] = $userinfo[0]['dob_m'];
        $data['day'] = $userinfo[0]['dob_d'];
        $data['year'] = $userinfo[0]['dob_year'];
        $data['gender'] = $userinfo[0]['gender'];
        $data['avatar'] = $userinfo[0]['avatar'];
        $country_id = $userinfo[0]['country_id'];        
        $countrydata = $this -> users_model -> getcountryDetail($country_id);
        $data['country'] = $countrydata[0]['desc_en'];
       // $data['countries'] = $this -> users_model -> getcountryList();        
        $data['page'] = 'updateprofile';
        $this -> load -> view('template/main_template', $data);
    
    }
    public function changePassword() {
    
        // TODO validations
    
        // reloadFormData => [to reload the same page again = old req] & to access old pass
        //$data = $this -> reloadFormData();
        if ($this -> input -> post()) {
            $id = $this -> session -> userdata('userid');
            $rdata = $this -> users_model -> getUserProfile($id);
            $realOldHashedPassword = $rdata[0]['password'];
        
            $oldFromPassword = $this -> input -> post('oldFromPassword');
            $newPassword1 = $this -> input -> post('newPassword1');
            $newPassword2 = $this -> input -> post('newPassword2');
        
        
            if ($realOldHashedPassword != md5($oldFromPassword)) {
                $data['showMessage'] = true;
                $data['type'] = 'Error';
                // Error or Success
                $data['messageToBeShow'] = $this->lang -> line('YourOldPassworddoesnotcorrect');
        
            } else if ($newPassword1 != $newPassword2) {
                $data['showMessage'] = true;
                $data['type'] = 'Error';
                // Error or Success
                $data['messageToBeShow'] = $this->lang -> line('BothNewPasswordsIdentical');
        
            } else {
        
                // change password          
                $this -> users_model -> changePassword($id, $newPassword1);
                // TODO what about if DB Error Handling ....
                // Now => Assume Success
        
                $data['showMessage'] = true;
                $data['type'] = 'Success';
                // Error or Success
                $data['messageToBeShow'] = $this->lang -> line('PasswordSuccessfullyChanged');
        
                // ------------------
                // send Email to $email
        
                /*$rdata = $this -> users_model -> getUserProfile($userId);
                 $email = $rdata[0]['email'];
        
                 $this -> email -> set_newline("\r\n");
                 $this -> email -> from('webmaster@emm-port.net', "EMM City Service");
                 $this -> email -> to($email);
                 $this -> email -> subject("EMM City");
                 $this -> email -> message("
                 <!doctype html>
                 <html lang='en'>
                 <head>
                 <meta charset='UTF-8' />
                 <title>Reset</title>
                 </head>
                 <body style='font-family:verdana; font-size:13px;'>
                 Dear EMM Citizen, <br />
                 Your password has been reset. Your new password is $$newPassword1.<br/>
                 Use it to check in <a href='http://www.ne-port.net'>www.ne-port.net</a> and enjoy!
                 <br/><br/>
                 Cher EMM Citoyen,<br />
                 Votre mot de passe a été réinitialisé. Le nouveau mot de passe est  $$newPassword1.<br/>
                 Veuillez l’utiliser  pour l’enregistrement sur <a href='http://www.ne-port.net'>www.ne-port.net</a> et amusez-vous!
                 <br/><br/>
                 </body>
                 </html>
                 ");
                $this -> email -> send();*/
                // ------------------
        
            }
        }
        $data['page'] = 'change_password';
        $this -> load -> view('template/main_template', $data);
    }
    public function logout() {
       // $user = array('username' => '', 'userid' => '', 'password' => '');
       // $this -> session -> unset_userdata($user);        
        $this->auth->logout();
        $this -> session -> unset_userdata('username');
        $this -> session -> unset_userdata('userid');
       // $this -> session -> unset_userdata('password');
        redirect('home', 'refresh');
        
    }
    
  
}
