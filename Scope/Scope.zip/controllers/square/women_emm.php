<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Women_emm extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct() {
		parent::__construct();
		$this -> load -> library('form_validation');
		$this -> load -> library('upload');
                $id = $this -> session -> userdata('userid');
                if(!$id)redirect(base_url('/'));
	}
	public function index()
	{
		// i18n - loadMessages
		$data['commonMessages'] = $this->loadMessages();
		
		$data['page'] = 'square/women_emm-view';
		$this->load->view('content/soonIndex',$data);
	}
	
	public function loadMessages(){
		// *****************************
		// lang
		// ----------------------
		$lang = 'en'; // default lang
		// set lang if it evaluated before
		if ( $this -> session -> userdata('lang') ){
			$lang = $this -> session -> userdata('lang');
		}
		// ----------------------		
		
		// i18n : FE_RESOURCES - assets (imgs/pdfs/vids/...)
		$this-> lang-> load("commonMessages",$lang);		
		
		// pass Messages to view
		return $this->lang;
		// *****************************
	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */