<?php error_reporting(0);
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Astragram extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this -> load -> library('form_validation');
		$this -> load -> library('upload');
                $id = $this -> session -> userdata('userid');
                if(!$id)redirect(base_url('/'));
	}

	public function index() {
		// if ($this -> session -> userdata('userid') != null) {

		$this -> load -> model('square/astragram_model');
		$data['rows'] = $this -> astragram_model -> getPosts();
                $data['trends'] = $this -> astragram_model -> getTrends();
                $data['comps'] = $this -> astragram_model -> getcomp();
				$dos = $data['comps'];
					foreach ($dos as $do) {
			
					$yup= ltrim($do->hashtag,'#');
                $data['comprs'] = $this -> astragram_model -> getcompresult($yup);
				
				}
		$this -> load -> model('users_model');

		// i18n - loadMessages
		$data['commonMessages'] = $this -> loadMessages();
		$data['page'] = 'square/astagram-view';
                $data['loadmore'] = 'loadmore';
		//$this->load->view('content/index',$data);
		$this -> load -> view('square/astragram-view', $data);
		

	}


     
 public function hashview() {

		$hashstr = $this -> uri -> segment(4);
		$this -> load -> model('square/astragram_model');
		$data['rows'] = $this -> astragram_model -> getPostsbyhash($hashstr);
                $data['trends'] = $this -> astragram_model -> getTrends();
                $data['comps'] = $this -> astragram_model -> getcomp();
		$this -> load -> model('users_model');

		$data['commonMessages'] = $this -> loadMessages();
		$data['page'] = 'square/astagram-view';
                $data['loadmore'] = 'loadmorehash/'.$hashstr;
		$this -> load -> view('square/astragram-view', $data);

	}

	public function loadMessages() {
		// *****************************
		// lang
		// ----------------------
		$lang = 'en';
		// default lang
		// set lang if it evaluated before
		if ($this -> session -> userdata('lang')) {
			$lang = $this -> session -> userdata('lang');
		}
		// ----------------------

		// i18n : FE_RESOURCES - assets (imgs/pdfs/vids/...)
		$this -> lang -> load("commonMessages", $lang);

		// pass Messages to view
		return $this -> lang;
		// *****************************
	}

	public function reloadFormData() {
		// lang
		// ----------------------
		$lang = 'en';
		// default lang
		// set lang if it evaluated before
		if ($this -> session -> userdata('lang')) {
			$lang = $this -> session -> userdata('lang');
		}
		// ----------------------

		// pass $lang to view
		$data['lang'] = $lang;

		// i18n : FE_RESOURCES - assets (imgs/pdfs/vids/...)
		$this -> lang -> load("commonMessages", $lang);

		$data['commonMessages'] = $this -> lang;

		// ----------------------
		// fillFormData
		// ----------------------
		$data['astraWhat'] = $this -> input -> post('astraWhat');
		$data['astraWho'] = $this -> input -> post('astraWho');
		$data['astraWhere'] = $this -> input -> post('astraWhere');

		// ----------------------

		return $data;
		// *****************************
	}


	public function loadUploadView() {
		// *************************
		// load upload-view
		// -----------------------

		//$data['commonMessages'] = $this -> loadMessages();

		//$data['page'] = 'square/astagramUpload-view';
		$this -> load -> view('square/astragramUpload-view');

	}

	public function execute() {
		// i18n - loadMessages
		$commonMessages = $this -> loadMessages();

		$astrawhat = $this -> input -> post('astrawhat');
		$astraWho = $this -> input -> post('astraWho');
		$astraWhere = $this -> input -> post('astraWhere');
		//$imgfile = $this -> input -> post('astrimg');

		$this -> load -> library('form_validation');
		$this -> form_validation -> set_rules("astrawhat", "What", "required|xss_clean|trim");
		$this -> form_validation -> set_rules("astraWho", "Who", "required|xss_clean|trim");
		$this -> form_validation -> set_rules("astraWhere", "Where", "required|xss_clean|trim");

		
			$data2 = $this -> reloadFormData();

			// load the model
			$this -> load -> model('square/astragram_model');

			$data = $this -> astragram_model -> insertAstra($astrawhat, $astraWho, $astraWhere);
			$astraImage = $data;

			//var_dump(is_dir('assets/images/astragram')); die;
			$config['upload_path'] = 'assets/images/astragram';
			$config['allowed_types'] = 'gif|jpg|png|bmp|jpeg';
			$config['file_name'] = $astraImage;
			$config['max_size'] = '1024';
			//$config['max_width'] = '1024';
			//$config['max_height'] = '1024';

			$this -> load -> library('upload', $config);
			$this -> upload -> initialize($config);

			if (!$this -> upload -> do_upload('astrimg')) {
				// upload image failed
				// So delete inserted record because upload his image failed
				$id = $data;
				$this -> astragram_model -> deleteAstragram($id);

				// show errors to user
				$error = array('error' => $this -> upload -> display_errors());
				//print_r($error);

				//$this -> load -> view('square/astragramUpload-view', $error);
				// reload Form Data
				$data2 = $this -> reloadFormData();

				// ASSUME (its wrong) : if upload error : permitted size
				//$data2 = $this->reloadFormData();
				//$data2['error'] = $commonMessages->line('UploadPermittedSize');

				$data2['showMessage'] = true;
				$data2['type'] = 'Error';
				// Error or Success
				$data2['messageToBeShow'] = $commonMessages -> line('UploadPermittedSize');

				// $data2['page'] = 'astragramUpload-view';
				$this -> load -> view('square/astragram-view', $data2);
			} else {
				//redirect("http://www.google.com");
				// upload image success
				// So update avatar field in user table
				$id = $data;
				$fileInfo = $this -> upload -> data();
				$this -> astragram_model -> saveImageByID($id, $fileInfo['file_name']);
				//$this->index();
				redirect('square/astragram');
				//$this -> index();
				//$this -> load -> view('square/astragram-view');
				/*$data5['showMessage'] = true;
				 $data5['type'] = 'Success';
				 // Error or Success
				 $data5['messageToBeShow'] = "Your access to <a href='http://www.ne-port.net'>www.ne-port.net</a> is pending approval. <br> We will notify you via email.";
				 $data5['page'] = 'register-view';
				 $this -> load -> view('content/index', $data5);*/
			}
		

	}






	public function comments() {

		//TODO Call user profile avatar from db
		//print_r($this -> session -> all_userdata());
		//exit ;
		$postId = $this -> input -> get('postId');
		$comment = $this -> input -> get('comment');

		$this -> load -> model('square/astragram_model');
		$this -> astragram_model -> insertComments($postId, $comment, $this -> session -> userdata('userid'));
		$last_comment_id = $this -> db -> insert_id();

		$data = array();
		$this -> load -> model('users_model');
		$data['records'] = $this -> users_model -> getUserProfile($this -> session -> userdata('userid'));
		//echo $data['records'][0]['avatar'] ; exit;

		$msg = array('type' => "success", 'last_id' => $last_comment_id, 'name' => $this -> session -> userdata('username'), 'image' => $data['records'][0]['avatar'], 'comment' => $comment);
		echo json_encode($msg);
	}



          public function commentloadmore() {

		$this -> load -> model('square/astragram_model');
		$index = $this -> input -> get('index');
                $postid =$this -> uri -> segment(4);
		$data = array();
                $index=$index*10;

		$data['comments'] = $this -> astragram_model -> getCommentsModel($postid,$index);
		if ($data['comments']) 
			echo $this -> load -> view('square/astragram-postcomments.php', $data);
			
	}


    public function likesload() {

		$this -> load -> model('square/astragram_model');
		//$index = $this -> input -> get('index');
                $postid =$this -> uri -> segment(4);
		$data = array();
                $data['likes'] = $this -> astragram_model -> get_likes_tip($postid);
		if ($data['likes']) 
			echo $this -> load -> view('square/astragram-Postlikesdetailes.php', $data);
			
	}


	public function loadmore() {
		$this -> load -> model('square/astragram_model');
		$index = $this -> input -> get('index');
		$data = array();
		$data['rows'] = $this -> astragram_model -> getPosts($index);
                $data['commonMessages'] = $this -> loadMessages();
		if ($data['rows']) {
			echo $this -> load -> view('square/astragram-post.php', $data);
		}
		//$sql = "select * from infinitescroll order by id asc limit $start,$limit";
	}

        public function loadmorehash() {

                $hashstr = $this -> uri -> segment(4);
		$this -> load -> model('square/astragram_model');
		$index = $this -> input -> get('index');
		$data = array();
                $data['commonMessages'] = $this -> loadMessages();
                $data['rows'] = $this -> astragram_model -> getPostsbyhash($hashstr,$index);
		if ($data['rows']) {
			echo $this -> load -> view('square/astragram-post.php', $data);
		}
		
	}


	public function like() {

		$postId = $this -> input -> get('postId');
		$this -> load -> model('square/astragram_model');
		$this -> astragram_model -> insertLike($postId, $this -> session -> userdata('userid'));

                $data['likes']= $this ->astragram_model -> getLikes($postId);
                echo $postId."###";
                echo $this -> load -> view('square/astragramPostlikes',$data);

	}

	public function dislike() {
		$postId = $this -> input -> get('postId');
		$this -> load -> model('square/astragram_model');
		$this -> astragram_model -> dislike($postId, $this -> session -> userdata('userid'));
                $data['likes'] = $this ->astragram_model -> getLikes($postId);
                echo $postId."###";
                echo $this -> load -> view('square/astragramPostlikes',$data);
	}




	public function postView() {

		$post_id = $this -> uri -> segment(4);
		$this -> load -> model('square/astragram_model');
		$data['rows'] = $this -> astragram_model -> getPostModel($post_id);
		$this -> load -> model('users_model');
                $data['commonMessages'] = $this -> loadMessages();
		
		$this -> load -> view('square/astragramPostView', $data);
                $data['page'] = 'square/astragramPostView';
                $data['loadmore'] = 'commentloadmore/'.$post_id;
		$this -> load -> view('square/astragram-view', $data);

	}

	public function tooltip() {
		//$this->output->enable_profiler(false);
		// if($this->input->server('HTTP_X_REQUESTED_WITH') != 'XMLHttpRequest'){ echo "fail. try something else"; return; }
		$this -> load -> model('square/astragram_model');
		$idd = $this -> input -> post('id');

		$aircraft_j = array();
		$aircraft_j = $this -> astragram_model -> get_likes_tip($idd);
		echo json_encode($aircraft_j);
	}

	/////////////////////////////////////////////////Profile Menu/////////////////////////////////

	public function profile() {
		//echo $this -> session -> userdata('userid');
		//exit;
		$userId = $this -> uri -> segment(4);
		$this -> load -> model('square/astragram_model');
		$data['rows'] = $this -> astragram_model -> getUserProfile($userId);
		$this -> load -> model('users_model');
		$data['urows'] = $this -> users_model -> getUserProfile($userId);
                $data['ownerid']= $this -> session -> userdata('userid');
                $data['commonMessages'] = $this -> loadMessages();
		$this -> load -> view('square/astragram-profile', $data);
	}

    public function delmyimg() {

   $postId = $this -> input -> post('imgid');
   $this -> load -> model('square/astragram_model');
   $this -> astragram_model -> deleteAstragram($postId);
   //$postImg=$postId.".jpg";
  // $file = 'assets/images/astragram/' . $postImg;
  // unlink($file);
   $this ->profile();

     }



	///////////////////////////////////////////////////////SERch///////////////////////////////////////

	/*public function search() {    //////old search for posts
	 $keyword = $this -> input -> post('req');
	 $data['response'] = 'false';
	 //Set default response

	 $this -> load -> model('square/astragram_model');
	 $rows = $this -> astragram_model -> search($keyword);
	 if (!empty($rows)) {
	 foreach ($rows as $r) {
	 echo '<li><a href="http://ne-port.net/beta/square/astragram/results/' . $r -> post_id . '">' . $r -> hashtag . '</a></li>';
	 }
	 } else {
	 echo '<li>' . $keyword . '</li>';
	 }
	 }*/


	public function search() {////// search for users as whats'app
		$keyword = $this -> input -> post('req');
		$data['response'] = 'false';
		//Set default response

		$this -> load -> model('square/astragram_model');
		$rows = $this -> astragram_model -> search($keyword);
		if (!empty($rows)) {
			foreach ($rows as $r) {
    
	echo '<li style="margin-top:5px;width: 100%;"><a style="width: 100%;float: left;text-decoration:none" href="'.base_url('square/astragram/profile/' . $r -> id) . '">
				<img style="width:35px; height:35px;float: left; " src="'.base_url('assets/images/profile/' . $r -> avatar ). '"/><span style="margin-left:2px;width: 100%;">' . $r -> fname . ' ' . $r -> lname . '</span>
				</a></li>';
			
}
		} else {
			//echo '<li>' . $keyword . '</li>';
			echo "<li style='text-align:center; cursor:pointer;'>No Matches found</li>";
		}
	}

	
	public function search2() {////// search for users as whats'app
		$keyword = $this -> input -> post('req');
		$data['response'] = 'false';
		//Set default response

		$this -> load -> model('square/astragram_model');
		$rows = $this -> astragram_model -> search($keyword);
		if (!empty($rows)) {
			foreach ($rows as $r) {
            $vartext="'". $r -> fname ." " . $r -> lname. "'";
            $vartextid="'". $r -> id. "'";
	
	echo '<li style="margin-top:5px;"><a style="text-decoration:none" onclick="tarek('.$vartext.','.$vartextid.');">
				<img style="width:35px; height:35px; " src="'.base_url('assets/images/profile/' . $r -> avatar ). '"/><span style="margin-left:5px;">' . $r -> fname . ' ' . $r -> lname . '</span>
				</a></li>';
			
}
		} else {
			//echo '<li>' . $keyword . '</li>';
			echo "<li style='text-align:center; cursor:pointer;'>No Matches found</li>";
		}
	}
	public function usearch() {
		$data = array();
		$q = $_GET['term'];
		$q = $this -> input -> get('term');
		$this -> load -> model('square/astragram_model');
		$rows = $this -> astragram_model -> search($q);
		if (!empty($rows)) {
			foreach ($rows as $r) {
				$data[] = array('fname' => $r -> fname, 'lname' => $r -> lname, 'avatar' => $r -> avatar);
			}
		} else {
			//echo '<li>' . $keyword . '</li>';
			echo "<li style='text-align:center; cursor:pointer;'>No Matches found</li>";
		}

		echo json_encode($data);

		$data = array();
		$this -> load -> model('users_model');
		$data['records'] = $this -> users_model -> getUserProfile($this -> session -> userdata('userid'));
		//echo $data['records'][0]['avatar'] ; exit;

		$msg = array('type' => "success", 'last_id' => $last_comment_id, 'name' => $this -> session -> userdata('username'), 'image' => $data['records'][0]['avatar'], 'comment' => $comment);
		echo json_encode($msg);
	}

	public function results() {
		$post_id = $this -> uri -> segment(4);
		$this -> load -> model('square/astragram_model');
		$data['rows'] = $this -> astragram_model -> getSearchResult($post_id);
		$this -> load -> view('square/astragram-serachResults', $data);
	}

	public function delcomment() {
		$id = $this -> input -> post('id');
		$this -> load -> model('square/astragram_model');
		$this -> astragram_model -> delete_trend($id);
	}

	

	

}
