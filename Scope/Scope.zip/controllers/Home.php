<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once (APPPATH . 'core/MY_main.php');
class Home extends MY_main {

	
    public function __construct() {
        parent::__construct();  
        // in case you did not autoload the library
        $this->load->library('auth');
        $this -> load -> model('users_model');
        if ($this->auth->loggedin()) {
            // get current user id
            $userid = $this->auth->userid();
            if ($userid) {
                $userinfo = $this -> users_model -> getUserProfile($userid);
                $username = ucfirst($userinfo[0]['fname'] . " " . $userinfo[0]['lname']);
                $this -> session -> set_userdata(array('userid' => $userid,'username' => $username));
                //print_r($this->session->userdata()) ;
            }
        
        }
        
        ///////////////////////////////////////////////////////////////////////////
        
        if ($this -> session -> userdata('username') == "") {
           // $this -> session -> unset_userdata('site_userid');            
            if ($this -> session -> userdata('site_lang') == "") {
                $this -> session -> set_userdata('site_lang', 'english');                
            }
        }        
        //check language session to load the lang file
        $site_lang = $this -> session -> userdata('site_lang');
        if ($site_lang) {
            $this -> lang -> load('site', $site_lang);         
        } else {
            $this -> lang -> load('site', 'english');           
        }  

        
        
        
    }
    public function index(){ 
        //$data['commonMessages'] = $this->loadMessages();  
      /*   if (!$this->auth->loggedin()) {
            //redirect('login');
        }else{
            // get current user id
            $userid = $this->auth->userid();
            $this -> session -> set_userdata(array('userid' => $userid));  
            redirect('home/userhome');
        }
       */
        if($this->session->userdata('userid')){
            redirect('home/userhome');
        }   
        $sql='SELECT news.* FROM news  ORDER BY news.id DESC LIMIT 0,1';
        $news = $this->db->query($sql)->result();
        $data['new']=$news[0];
        $data['page'] = 'home-view';      
        $this -> load -> view('template/main_template', $data);
    }
    public function userhome(){
       /*  if (!$this->auth->loggedin()) {
            redirect('home');
        }else{
            // get current user id
            $userid = $this->auth->userid();
            $this -> session -> set_userdata(array('userid' => $userid));            
        }
       */
        if(!$this->session->userdata('userid')){
            redirect('home');
        }
        
        //$data['commonMessages'] = $this->loadMessages();
        $data['page'] = 'user_home';
        $this -> load -> view('template/main_template', $data);
    }
    public function content($id) {
        /*
        if (!$this->auth->loggedin()) {
            redirect('users/login');
        }else{
            // get current user id
            $userid = $this->auth->userid();
            $this -> session -> set_userdata(array('userid' => $userid));
           // print_r($this->session->userdata()) ;
        }
        */
        if(!$this->session->userdata('userid')){
            redirect('home');
        }
        $this->data['level1']=$level1 =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$id)->result();       
        $levels=array();   
            
        /*
        echo "level1<pre>";
        print_r($level1);
        echo "</pre>";
        */
        /* level 2*/        
         foreach ($level1 as $keym=>$level1r){
             //first level
            $levels[$keym]= (array) $level1r ;
            $levels[$keym]['files']=$this->db->query('SELECT files.* FROM files where files.menu_id='.$level1r->id)->result();
            $level2array =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$level1r->id)->result();
                   
                 /* level 3*/                          
                 foreach ($level2array as $key=>$level2r){
                     //second level
                     $levels[$keym][$level1r->id][$key]= (array) $level2r ;
                     $levels[$keym][$level1r->id][$key]['files']=$this->db->query('SELECT files.* FROM files where files.menu_id='.$level2r->id)->result();
                     // Third level
                     $level3 =  $this->db->query('SELECT menus.* FROM menus where menus.parent_id='.$level2r->id)->result();
                    
                    foreach ($level3 as $keyinner=>$level3r){                        
                        $levels[$keym][$level1r->id][$key][$level2r->id][$keyinner]= (array) $level3r;
                        $levels[$keym][$level1r->id][$key][$level2r->id][$keyinner]['files']=$this->db->query('SELECT files.* FROM files where files.menu_id='.$level3r->id)->result();
                    }
                 }         
         }
         
         $this->data['levels']=$levels;
        // $this->data['level3']=$level3;
         /*
         echo "ALL<pre>";
         print_r($levels);
         echo "</pre>";
         */         
         $this->data['id']=$id;
        $this->data['page'] = 'filecontent';
        $this -> load -> view('template/main_template', $this->data);
    }
    
    public function news(){
        /*  if (!$this->auth->loggedin()) {
         redirect('home');
         }else{
         // get current user id
         $userid = $this->auth->userid();
         $this -> session -> set_userdata(array('userid' => $userid));
         }
         */
        if(!$this->session->userdata('userid')){
            redirect('home');
        }
        $sql='SELECT news.* FROM news  ORDER BY news.id DESC ';
        $data['news']=$news = $this->db->query($sql)->result();        
        //$data['commonMessages'] = $this->loadMessages();
        $data['page'] = 'news';
        $this -> load -> view('template/main_template', $data);
    }
    public function newdetail($id){
        /*  if (!$this->auth->loggedin()) {
         redirect('home');
         }else{
         // get current user id
         $userid = $this->auth->userid();
         $this -> session -> set_userdata(array('userid' => $userid));
         }
         */
        if(!$this->session->userdata('userid')){
            redirect('home');
        }
        $news1 = $this->db->query('SELECT * FROM news where id = ' . $id .'')->result(); 
        $news  = $data['news'] = $news1[0];
        //$data['commonMessages'] = $this->loadMessages();
        $data['page'] = 'newdetail';
        $this -> load -> view('template/main_template', $data);
    }
    public function helpdesks(){
        /*  if (!$this->auth->loggedin()) {
         redirect('home');
         }else{
         // get current user id
         $userid = $this->auth->userid();
         $this -> session -> set_userdata(array('userid' => $userid));
         }
        
        if(!$this->session->userdata('userid')){
            redirect('home');
        } 
        */
        $sql='SELECT helpdesks.* FROM helpdesks  ORDER BY helpdesks.id DESC ';
        $data['helpdesks']=$helpdesks = $this->db->query($sql)->result();
        //$data['commonMessages'] = $this->loadMessages();
        $data['page'] = 'helpdesks';
        $this -> load -> view('template/main_template', $data);
    }
    public function contacts(){
           $data['page'] = 'contacts';
        $this -> load -> view('template/main_template', $data);
    }
    public function addcontact() {
        $this -> load -> library('email');
        $this -> config -> load('email');
        $data['arr']= $arr = $this->input->post();
        //$arr['company_established_year'] = $_POST['company_established_year'];
        $arr['regdate'] = date('Y-m-d H:i:s');
        //$arr['modified_date'] = date('Y-m-d H:i:s');
        // unset($arr['code']);
        // unset($arr['insertcode']);
        //unset($arr['confirmation']);
        //echo $this->session->userdata('captchaWord');
        // echo $arr['insertcode'];
        if ($arr['typeid']==1) {
            $page = 'helpdesks';
        }elseif ($arr['typeid']==2) {
            $page = 'contacts';
        }
        //echo $arr['typeid'];
        if ((!empty($arr['typeid'])) AND (!empty($arr['name'])) AND (!empty($arr['email'])) AND (!empty($arr['tel'])) AND (!empty($arr['msg']))) {
                /* Clear the session variable */               
                if ( $this -> db -> insert('feedbackmsg', $arr)) {
                    
                   /*
                    * Send Email
                    */
                   
                    $this -> email -> set_newline("\r\n");
                    $this -> email -> from('webmaster@ne-port.com', "NE City Service");
                    $this -> email -> to('ghada_nabeeh@yahoo.com');
                    //$this->email->to('jsparo30@gmail.com, aliaad@scope-adv.com, Noha.Zannoun@astrazeneca.com, Diana.Maher@astrazeneca.com');
                    if ($arr['typeid']==1) {                     
                        $this -> email -> subject("NE Inquery");
                    }elseif ($arr['typeid']==2) {                        
                        $this -> email -> subject("NE contacts");
                    }                    
                    
                    $this -> email -> message("
                		<!doctype html>
                		<html lang='en'>
                		<head>
                			<meta charset='UTF-8' />
                			<title>Inquery</title>
                		</head>
                		<body style='font-family:verdana; font-size:13px;'>
                			User:'".$arr['name']."<br />
                            Email:'".$arr['email']."<br />
                            Phone:'".$arr['tel']."<br />
                            Message:<br />".$arr['msg']."<br />                			
                		</body>
                		</html>
                		");
                    $this -> email -> send();
                    
                    
                    redirect('home/'.$page);
                    
                } else {
                    
                    redirect('home/'.$page);                    
                }
    
            } else {                
                redirect('home/'.$page);
            }
            //echo $this->db->last_query();
        //$this->user_model->insert($arr);
    }
    
    public function calendar($defaultdate=NULL){
        /*  if (!$this->auth->loggedin()) {
         redirect('home');
         }else{
         // get current user id
         $userid = $this->auth->userid();
         $this -> session -> set_userdata(array('userid' => $userid));
         }
         */
        if(!$this->session->userdata('userid')){
            redirect('home');
        }
        if ($defaultdate){
            $data['defaultdate']=$defaultdate;
        }else{
            $data['defaultdate']="";
        }
        $sql='SELECT calendars.* FROM calendars  ORDER BY calendars.id DESC ';
        $data['calendars']=$calendars = $this->db->query($sql)->result();
        $events = array();
        foreach($calendars as $x=> $calendar){
            $e = array();
            $e['id'] = $calendar->id;
            $e['title'] = $calendar->title;
            $e['start'] = $calendar->startdate;
            $e['end'] = $calendar->enddate;
            $allday = ($calendar->allDay == "true") ? true : false;
            $e['allDay'] = $allday;
            // $e['color'] = '#000';
            array_push($events, $e);
        }
        
        $sqluser='SELECT * FROM users WHERE active=1';
        $users = $this->db->query($sqluser)->result();        
        foreach($users as $x=> $user){
            $e = array();
            $e['id'] = $user->id;
            $e['title'] = $user->fname." ".$user->lname;
            $e['start'] = date("Y")."-".$user->dob_m."-".$user->dob_d;
            $e['end'] = date("Y")."-".$user->dob_m."-".$user->dob_d;
            $e['allDay'] = true;            
            $e['color'] = '#FFCA25';
            array_push($events, $e);
        }       
        
        $data['events']=json_encode($events);
        //$data['commonMessages'] = $this->loadMessages();
        $data['page'] = 'calendar';
        $this -> load -> view('template/main_template', $data);
    }
}
