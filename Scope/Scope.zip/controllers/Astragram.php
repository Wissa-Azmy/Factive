<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once (APPPATH . 'core/MY_main.php');
class Astragram extends MY_main {

	
    public function __construct() {
       parent::__construct();  
        // in case you did not autoload the library
        $this->load->library('auth');
        $this -> load -> model('users_model');
        if ($this->auth->loggedin()) {
            // get current user id
            $userid = $this->auth->userid();
            if ($userid) {
                $userinfo = $this -> users_model -> getUserProfile($userid);
                $username = ucfirst($userinfo[0]['fname'] . " " . $userinfo[0]['lname']);
                $this -> session -> set_userdata(array('userid' => $userid,'username' => $username));
                //print_r($this->session->userdata()) ;
            }
        
        }
        
        ///////////////////////////////////////////////////////////////////////////
        if ($this -> session -> userdata('username') == "") {
           // $this -> session -> unset_userdata('site_userid');            
            if ($this -> session -> userdata('site_lang') == "") {
                $this -> session -> set_userdata('site_lang', 'english');                
            }
        }
        
        //check language session to load the lang file
        $site_lang = $this -> session -> userdata('site_lang');
        if ($site_lang) {
            $this -> lang -> load('site', $site_lang);         
        } else {
            $this -> lang -> load('site', 'english');           
        }    
        
        $this -> load -> library('email');
        $this -> config -> load('email');
        $this -> load -> library('form_validation');        
        // $config['upload_path'] = base_url('/uploaded/profile/');      
        $this -> load -> library('upload');
        $this->load->model('astragram_model');
        
    }
    public function index(){ 
        if(!$this->session->userdata('userid')){
            redirect('home');
        }
        
       	
		$data['rows'] = $this->astragram_model->getPosts();
		/*
		echo "<pre>";
		print_r($data['rows']);
		echo "</pre>";
		*/
        $data['trends'] = $this->astragram_model->getTrends();
        $data['comps'] = $this->astragram_model->getcomp();
		$dos = $data['comps'];
		foreach ($dos as $do) {			
			$yup= ltrim($do->hashtag,'#');
            $data['comprs'] = $this -> astragram_model -> getcompresult($yup);				
		}				
		//$this -> load -> model('users_model');
		//i18n - loadMessages
		//$data['commonMessages'] = $this -> loadMessages();		
		$data['page'] = 'square/astragram-view';
        $data['loadmore'] = 'loadmore';
		//$this->load->view('content/index',$data);
        $this -> load -> view('template/main_template', $data);
		
    }
    public function loadmore() {
       // $this -> load -> model('square/astragram_model');
        $index = $this -> input -> get('index');
        $data = array();
        $data['rows'] = $this -> astragram_model -> getPosts($index);
        $data['commonMessages'] = $this -> loadMessages();
        if ($data['rows']) {
            $this -> load -> view('square/astragram-post.php', $data);
        }
        //$sql = "select * from infinitescroll order by id asc limit $start,$limit";
    }
    
    public function likesload() {    
       // $this -> load -> model('square/astragram_model');
        //$index = $this -> input -> get('index');
        //$postid =$this -> uri -> segment(4);
        $postid =$this -> uri -> segment(3);        
        $data = array();
        $data['likes'] = $this->astragram_model->get_likes_tip($postid);     
        if ($data['likes'])
            $this->load->view('square/astragram-postlikesdetailes.php', $data);
        	
    }

}
