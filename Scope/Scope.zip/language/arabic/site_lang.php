<?php

// TEST
// ----------------
$lang["msg_first_name"] = "First Name";
$lang["msg_last_name"] = "Last Name";
$lang["msg_dob"] = "Date of Birth";
$lang["msg_address"] = "Address";

$lang["WELCOME"] = "WELCOME TO EMM CITY";
$lang["CHECKINTO"] = "CHECK IN TO GET EMM PASS";
$lang["CheckIn"] = "Check in";
$lang["ClickHereToEMMCitizen"] = "Click here to become an NE citizen";
$lang["EMail"] = "Email";
$lang["Password"] = "Password";
$lang["ForgetPassword"] = "Forgot password";
$lang["ReTypePassword"] = "Your passwords do not match";
$lang["ViewEditProfile"] = "View/Edit Profile";
$lang["CheckOut"] = "Check out";
$lang["PoliciesAndGuidelines"] = "Policies and Guidelines";
$lang["People@EMM"] = "People@NE";
$lang["AZValues"] = "AZ Values";
$lang["EMMEvents"] = "Events";
$lang["EMMAnnouncement"] = "Announcements";
$lang["Finance"] = "Finance";
$lang["HR"] = "HR";
$lang["Compliance"] = "Compliance";
$lang["WelcomeToAstraZenecaMEA"] = "Welcome To AstraZeneca MEA";
$lang["CompensationAndBenefitsStrategy"] = "Compensation and Benefits Strategy";
$lang["EthicalInteraction"] = "Ethical Interaction";
$lang["CodeofConduct"] = "Code of Conduct";
$lang["Video"] = "Video";
$lang["Pdf"] = "Pdf";


$lang["ExpectationofThirdParties"] ="Expectation of Third Parties";
$lang["EMMCarPolicy"] ="EMM Car Policy";
$lang["EmploymentofRelatives"] ="Employment of Relatives";
$lang["EndofService"] ="End of Service";
$lang["ExitProcedure"] ="Exit Procedure";
$lang["IncentiveBonusPayment"] ="Incentive & Bonus Payment";
$lang["PerformanceManagement"] ="Performance  Management";
$lang["RecruitmentAndSelection"] ="Recruitment and Selection";
$lang["EMMEmployeeHandbook"] ="EMM  Employee Handbook";
$lang["EMMConference"] ="EMM 2014 Sales Conference";
$lang["EMMStandardOperatingProcedures"] ="EMM Standard Operating Procedures";

$lang["ComingSoon"] = "Coming Soon";
$lang["Astragram"] = "Astragram";
$lang["WomenEMM"] = "Women@NE";
$lang["LuckyMe"] = "Lucky Me";
$lang["BookOfTheMonth"] = "Book of the Month";
$lang["ValueInAction"] = "Value in Action";
$lang["SocialEvents"] = "Social Events";
$lang["EMMConnect"] = "Connect Magazine";
$lang["NewCitizen"] = "New Citizen";
$lang["Register"] = "Register";
$lang["UploadPicture"] = "Upload picture";
$lang["FirstName"] = "First name";
$lang["LastName"] = "Last name";
$lang["Birthday"] = "Birthdate";
$lang["Welcome"] = "Welcome";
$lang["Male"] = "Male";
$lang["Female"] = "Female";
$lang["Gender"] = "Gender";
$lang["Month"] = "Month";
$lang["Day"] = "Day";
$lang["Year"] = "Year";
$lang["Country"] = "Country";
$lang["TheDistrict"] = "The District";
$lang["TheBeacon"] = "The Beacon";
$lang["TheSquare"] = "The Square";
$lang["BusinessCommunication"] = "Business Communication";
$lang["LearningAndDevelopment"] = "Learning and Development";
$lang["SocialCommunication"] = "Social Communication";

$lang["Issue"] = "Issue";
$lang["Coins"] = "Coins";
$lang["Birthdate"] = "Birthdate";
$lang["ChangePassword"] = "Change Password";
$lang["AdminApprove"] = "Admin approve ";
$lang["Save"] = "Save";
$lang["Skip"] = "Skip";
$lang["Oldpassowrd"] = "Old passowrd";
$lang["Newpassword"] = "New password";
$lang["Typeyouremail"] = "Type your email";
$lang["Sendnewpassword"] = "Send new password";
$lang["UpdateCoverphoto"] = "Update Cover photo";

$lang["Invalidemailorpassword"] = "Invalid email or password";
$lang["ifyouforgetpasswordyoucan"] = "if you forget password you can ";
$lang["resetyourpassword"] = "reset your password";
$lang["hasnotbeenregisteredindatabase"] = "has not been registered in database";
$lang["isnotactivated"] = "does not activated yet";
$lang["ThisEmailIsAlreadyExist"] = "This email is already registered";
$lang["YourOldPassworddoesnotcorrect"] = "Your Old Password does not correct";
$lang["BothNewPasswordsIdentical"] = "Your Both New Passwords Fields MUST be identical";
$lang["Yourpasswordsdonotmatch"] = "Your passwords do not match. Please try again!";
$lang["PasswordSuccessfullyChanged"] = "Your Password Has Been Successfully Changed !";
$lang["APasswordHasBeenSentTo"] = "A New Password Has Been Sent To ";
$lang["YouHaveSuccessfullyRegistered"] = "You have successfully registered";
$lang["ErrorOccurred"] = "Error Occurred";
$lang["UploadPermittedSize"] = "The file you are attempting to upload is larger than the permitted size";



$lang["Writeacommentmsgg"] = "Write a comment ...";
$lang["Trendslabel"] = "Trends";
$lang["Upload"] = "Upload";
$lang["ViewMyphotos"] = "View My photos";
$lang["Home"] = "Home";


?>