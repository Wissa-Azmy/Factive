Code Snippet GeSHi Plugin
==================================================

For installation and configuration instructions go to the [Code Snippet GeSHi documentation](http://docs.ckeditor.com/#!/guide/dev_codesnippetgeshi) in the [CKEditor Developer's Guide](http://docs.ckeditor.com/#!/guide).
